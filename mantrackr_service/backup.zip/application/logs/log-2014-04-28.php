<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-04-28 14:02:12 --> Config Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Config Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Config Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:02:12 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:02:12 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:02:12 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:02:12 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:02:12 --> URI Class Initialized
DEBUG - 2014-04-28 14:02:12 --> URI Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Router Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Router Class Initialized
DEBUG - 2014-04-28 14:02:12 --> URI Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Router Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Output Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Output Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Output Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Security Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Security Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Security Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Input Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Input Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Input Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:02:12 --> Language Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Language Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Language Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Loader Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Loader Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Loader Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Controller Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Controller Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Controller Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:02:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:02:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:02:12 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:02:12 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:02:12 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:02:12 --> Model Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Model Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Model Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Model Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Model Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Model Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Database Driver Class Initialized
ERROR - 2014-04-28 14:02:12 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-04-28 14:02:12 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-04-28 14:02:12 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-04-28 14:02:12 --> Model Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Model Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:02:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:02:12 --> Model Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Session Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Session Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:02:12 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:02:12 --> A session cookie was not found.
DEBUG - 2014-04-28 14:02:12 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:02:12 --> Session routines successfully run
DEBUG - 2014-04-28 14:02:12 --> Session Class Initialized
DEBUG - 2014-04-28 14:02:12 --> A session cookie was not found.
DEBUG - 2014-04-28 14:02:12 --> Session routines successfully run
DEBUG - 2014-04-28 14:02:12 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:02:12 --> Model Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:02:12 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:02:12 --> A session cookie was not found.
DEBUG - 2014-04-28 14:02:12 --> Final output sent to browser
DEBUG - 2014-04-28 14:02:12 --> Total execution time: 0.0430
DEBUG - 2014-04-28 14:02:12 --> Session routines successfully run
DEBUG - 2014-04-28 14:02:12 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:02:12 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:02:12 --> Model Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:02:12 --> Model Class Initialized
DEBUG - 2014-04-28 14:02:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:02:12 --> Final output sent to browser
DEBUG - 2014-04-28 14:02:12 --> Total execution time: 0.0470
DEBUG - 2014-04-28 14:02:12 --> Final output sent to browser
DEBUG - 2014-04-28 14:02:12 --> Total execution time: 0.0480
DEBUG - 2014-04-28 14:17:14 --> Config Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Config Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Config Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:17:14 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:17:14 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:17:14 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:17:14 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:17:14 --> URI Class Initialized
DEBUG - 2014-04-28 14:17:14 --> URI Class Initialized
DEBUG - 2014-04-28 14:17:14 --> URI Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Router Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Router Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Router Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Output Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Output Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Security Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Security Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Output Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Security Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Input Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Input Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:17:14 --> Language Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Input Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Loader Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:17:14 --> Language Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Loader Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Language Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Controller Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:17:14 --> Loader Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Controller Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:17:14 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:17:14 --> Controller Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:17:14 --> Model Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Model Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Model Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Model Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Helper loaded: service_errorcodes_helper
ERROR - 2014-04-28 14:17:14 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-04-28 14:17:14 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:17:14 --> Model Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Model Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Model Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:17:14 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Session Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:17:14 --> A session cookie was not found.
DEBUG - 2014-04-28 14:17:14 --> Model Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Session routines successfully run
DEBUG - 2014-04-28 14:17:14 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:17:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:17:14 --> Model Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:17:14 --> Session Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Model Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Final output sent to browser
DEBUG - 2014-04-28 14:17:14 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:17:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:17:14 --> A session cookie was not found.
DEBUG - 2014-04-28 14:17:14 --> Session routines successfully run
DEBUG - 2014-04-28 14:17:14 --> Total execution time: 0.0150
DEBUG - 2014-04-28 14:17:14 --> Session Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:17:14 --> A session cookie was not found.
DEBUG - 2014-04-28 14:17:14 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:17:14 --> Session routines successfully run
DEBUG - 2014-04-28 14:17:14 --> Model Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:17:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:17:14 --> Model Class Initialized
DEBUG - 2014-04-28 14:17:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:17:14 --> Final output sent to browser
DEBUG - 2014-04-28 14:17:14 --> Total execution time: 0.0180
DEBUG - 2014-04-28 14:17:14 --> Final output sent to browser
DEBUG - 2014-04-28 14:17:14 --> Total execution time: 0.0190
DEBUG - 2014-04-28 14:23:36 --> Config Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Config Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:23:36 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:23:36 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:23:36 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:23:36 --> URI Class Initialized
DEBUG - 2014-04-28 14:23:36 --> URI Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Router Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Router Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Output Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Output Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Config Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Security Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Input Class Initialized
DEBUG - 2014-04-28 14:23:36 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:23:36 --> Security Class Initialized
DEBUG - 2014-04-28 14:23:36 --> URI Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:23:36 --> Router Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Language Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Output Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Loader Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Security Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Controller Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Input Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Input Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:23:36 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:23:36 --> Language Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Loader Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:23:36 --> Controller Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:23:36 --> Language Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:23:36 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Loader Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Controller Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:23:36 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:23:36 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:36 --> Session Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:23:36 --> A session cookie was not found.
DEBUG - 2014-04-28 14:23:36 --> Session routines successfully run
DEBUG - 2014-04-28 14:23:36 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:23:36 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:36 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:36 --> Session Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:23:36 --> A session cookie was not found.
DEBUG - 2014-04-28 14:23:36 --> Session routines successfully run
DEBUG - 2014-04-28 14:23:36 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:23:36 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:36 --> Final output sent to browser
DEBUG - 2014-04-28 14:23:36 --> Final output sent to browser
DEBUG - 2014-04-28 14:23:36 --> Total execution time: 0.0170
DEBUG - 2014-04-28 14:23:36 --> Total execution time: 0.0220
DEBUG - 2014-04-28 14:23:36 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:36 --> Session Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:23:36 --> A session cookie was not found.
DEBUG - 2014-04-28 14:23:36 --> Session routines successfully run
DEBUG - 2014-04-28 14:23:36 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:23:36 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:36 --> Final output sent to browser
DEBUG - 2014-04-28 14:23:36 --> Total execution time: 0.0230
DEBUG - 2014-04-28 14:23:38 --> Config Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Config Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:23:38 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:23:38 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:23:38 --> URI Class Initialized
DEBUG - 2014-04-28 14:23:38 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:23:38 --> Router Class Initialized
DEBUG - 2014-04-28 14:23:38 --> URI Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Router Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Output Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Security Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Config Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Output Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Input Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Security Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:23:38 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Input Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Language Class Initialized
DEBUG - 2014-04-28 14:23:38 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:23:38 --> URI Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Language Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Loader Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Router Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Controller Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Loader Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Controller Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Output Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:23:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:23:38 --> Security Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:23:38 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:23:38 --> Input Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:23:38 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Language Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Loader Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Controller Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:23:38 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:23:38 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:38 --> Session Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:23:38 --> A session cookie was not found.
DEBUG - 2014-04-28 14:23:38 --> Session routines successfully run
DEBUG - 2014-04-28 14:23:38 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:23:38 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:38 --> Final output sent to browser
DEBUG - 2014-04-28 14:23:38 --> Total execution time: 0.0160
DEBUG - 2014-04-28 14:23:38 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:38 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Session Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:38 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:23:38 --> A session cookie was not found.
DEBUG - 2014-04-28 14:23:38 --> Session Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:23:38 --> A session cookie was not found.
DEBUG - 2014-04-28 14:23:38 --> Session routines successfully run
DEBUG - 2014-04-28 14:23:38 --> Session routines successfully run
DEBUG - 2014-04-28 14:23:38 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:23:38 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:23:38 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:38 --> Final output sent to browser
DEBUG - 2014-04-28 14:23:38 --> Final output sent to browser
DEBUG - 2014-04-28 14:23:38 --> Total execution time: 0.0170
DEBUG - 2014-04-28 14:23:38 --> Total execution time: 0.0200
DEBUG - 2014-04-28 14:23:50 --> Config Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Config Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Config Class Initialized
DEBUG - 2014-04-28 14:23:50 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:23:50 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:23:50 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:23:50 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:23:50 --> URI Class Initialized
DEBUG - 2014-04-28 14:23:50 --> URI Class Initialized
DEBUG - 2014-04-28 14:23:50 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:23:50 --> Router Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Router Class Initialized
DEBUG - 2014-04-28 14:23:50 --> URI Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Router Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Output Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Output Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Output Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Security Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Security Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Security Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Input Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Input Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Input Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:23:50 --> Language Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:23:50 --> Language Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Language Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Loader Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Loader Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Controller Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Controller Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Loader Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Controller Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:23:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:23:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:23:50 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:23:50 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:23:50 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:23:50 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:50 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Session Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:23:50 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:23:50 --> A session cookie was not found.
DEBUG - 2014-04-28 14:23:50 --> Session routines successfully run
DEBUG - 2014-04-28 14:23:50 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:23:50 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:50 --> Session Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:23:50 --> Final output sent to browser
DEBUG - 2014-04-28 14:23:50 --> A session cookie was not found.
DEBUG - 2014-04-28 14:23:50 --> Total execution time: 0.0130
DEBUG - 2014-04-28 14:23:50 --> Session routines successfully run
DEBUG - 2014-04-28 14:23:50 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:23:50 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:50 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Final output sent to browser
DEBUG - 2014-04-28 14:23:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:50 --> Total execution time: 0.0150
DEBUG - 2014-04-28 14:23:50 --> Session Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:23:50 --> A session cookie was not found.
DEBUG - 2014-04-28 14:23:50 --> Session routines successfully run
DEBUG - 2014-04-28 14:23:50 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:23:50 --> Model Class Initialized
DEBUG - 2014-04-28 14:23:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:23:50 --> Final output sent to browser
DEBUG - 2014-04-28 14:23:50 --> Total execution time: 0.0190
DEBUG - 2014-04-28 14:24:16 --> Config Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Config Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Config Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:24:16 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:24:16 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:24:16 --> URI Class Initialized
DEBUG - 2014-04-28 14:24:16 --> URI Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Router Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Router Class Initialized
DEBUG - 2014-04-28 14:24:16 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:24:16 --> Output Class Initialized
DEBUG - 2014-04-28 14:24:16 --> URI Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Security Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Router Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Input Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Output Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Output Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:24:16 --> Security Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Security Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Language Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Input Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:24:16 --> Language Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Input Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:24:16 --> Loader Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Loader Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Language Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Controller Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Loader Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:24:16 --> Controller Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Controller Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:24:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:24:16 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:24:16 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:24:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:24:16 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:24:16 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Session Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:24:16 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:24:16 --> A session cookie was not found.
DEBUG - 2014-04-28 14:24:16 --> Session routines successfully run
DEBUG - 2014-04-28 14:24:16 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:24:16 --> Session Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:24:16 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:16 --> A session cookie was not found.
DEBUG - 2014-04-28 14:24:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:24:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:24:16 --> Session Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Session routines successfully run
DEBUG - 2014-04-28 14:24:16 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:24:16 --> A session cookie was not found.
DEBUG - 2014-04-28 14:24:16 --> Session routines successfully run
DEBUG - 2014-04-28 14:24:16 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:24:16 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:24:16 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:24:16 --> Final output sent to browser
DEBUG - 2014-04-28 14:24:16 --> Total execution time: 0.0160
DEBUG - 2014-04-28 14:24:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:24:16 --> Final output sent to browser
DEBUG - 2014-04-28 14:24:16 --> Total execution time: 0.0180
DEBUG - 2014-04-28 14:24:16 --> Final output sent to browser
DEBUG - 2014-04-28 14:24:16 --> Total execution time: 0.0190
DEBUG - 2014-04-28 14:24:17 --> Config Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Config Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:24:17 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:24:17 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:24:17 --> URI Class Initialized
DEBUG - 2014-04-28 14:24:17 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:24:17 --> URI Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Router Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Router Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Output Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Output Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Security Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Config Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Input Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:24:17 --> Security Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Language Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Input Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:24:17 --> Loader Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Language Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Controller Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Loader Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:24:17 --> Controller Class Initialized
DEBUG - 2014-04-28 14:24:17 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:24:17 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:24:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:24:17 --> URI Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:24:17 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Router Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Output Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Security Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Input Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:24:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:24:17 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Language Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:24:17 --> Session Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Loader Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Controller Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:24:17 --> Session Class Initialized
DEBUG - 2014-04-28 14:24:17 --> A session cookie was not found.
DEBUG - 2014-04-28 14:24:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:24:17 --> Session routines successfully run
DEBUG - 2014-04-28 14:24:17 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:24:17 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:24:17 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:24:17 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:17 --> A session cookie was not found.
DEBUG - 2014-04-28 14:24:17 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Session routines successfully run
DEBUG - 2014-04-28 14:24:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:24:17 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:24:17 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Final output sent to browser
DEBUG - 2014-04-28 14:24:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:24:17 --> Total execution time: 0.0120
DEBUG - 2014-04-28 14:24:17 --> Final output sent to browser
DEBUG - 2014-04-28 14:24:17 --> Total execution time: 0.0130
DEBUG - 2014-04-28 14:24:17 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:24:17 --> Session Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:24:17 --> A session cookie was not found.
DEBUG - 2014-04-28 14:24:17 --> Session routines successfully run
DEBUG - 2014-04-28 14:24:17 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:24:17 --> Model Class Initialized
DEBUG - 2014-04-28 14:24:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:24:17 --> Final output sent to browser
DEBUG - 2014-04-28 14:24:17 --> Total execution time: 0.0140
DEBUG - 2014-04-28 14:28:22 --> Config Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Config Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Config Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:28:22 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:28:22 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:28:22 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:28:22 --> URI Class Initialized
DEBUG - 2014-04-28 14:28:22 --> URI Class Initialized
DEBUG - 2014-04-28 14:28:22 --> URI Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Router Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Router Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Router Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Output Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Output Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Output Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Security Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Security Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Security Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Input Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Input Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:28:22 --> Language Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Input Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Language Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Loader Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Controller Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:28:22 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:28:22 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Loader Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Controller Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:28:22 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:28:22 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Language Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Loader Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Controller Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:28:22 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:28:22 --> Session Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:28:22 --> A session cookie was not found.
DEBUG - 2014-04-28 14:28:22 --> Session routines successfully run
DEBUG - 2014-04-28 14:28:22 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:28:22 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:28:22 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:28:22 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Final output sent to browser
DEBUG - 2014-04-28 14:28:22 --> Total execution time: 0.0150
DEBUG - 2014-04-28 14:28:22 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:28:22 --> Session Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:28:22 --> A session cookie was not found.
DEBUG - 2014-04-28 14:28:22 --> Session routines successfully run
DEBUG - 2014-04-28 14:28:22 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:28:22 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:28:22 --> Final output sent to browser
DEBUG - 2014-04-28 14:28:22 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Total execution time: 0.0200
DEBUG - 2014-04-28 14:28:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:28:22 --> Session Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:28:22 --> A session cookie was not found.
DEBUG - 2014-04-28 14:28:22 --> Session routines successfully run
DEBUG - 2014-04-28 14:28:22 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:28:22 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:28:22 --> Final output sent to browser
DEBUG - 2014-04-28 14:28:22 --> Total execution time: 0.0240
DEBUG - 2014-04-28 14:28:24 --> Config Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Config Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:28:24 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:28:24 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:28:24 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:28:24 --> URI Class Initialized
DEBUG - 2014-04-28 14:28:24 --> URI Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Router Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Router Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Output Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Output Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Security Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Input Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Security Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Input Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:28:24 --> Language Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Language Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Loader Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Loader Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Controller Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Controller Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Config Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:28:24 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:28:24 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:28:24 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:28:24 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:28:24 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:24 --> URI Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Router Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Output Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Security Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Input Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:28:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:28:24 --> Language Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Session Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Loader Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:28:24 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Controller Class Initialized
DEBUG - 2014-04-28 14:28:24 --> A session cookie was not found.
DEBUG - 2014-04-28 14:28:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:28:24 --> Session routines successfully run
DEBUG - 2014-04-28 14:28:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:28:24 --> Session Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:28:24 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:28:24 --> A session cookie was not found.
DEBUG - 2014-04-28 14:28:24 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Session routines successfully run
DEBUG - 2014-04-28 14:28:24 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:28:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:28:24 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:28:24 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:28:24 --> Final output sent to browser
DEBUG - 2014-04-28 14:28:24 --> Final output sent to browser
DEBUG - 2014-04-28 14:28:24 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Total execution time: 0.0130
DEBUG - 2014-04-28 14:28:24 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Total execution time: 0.0120
DEBUG - 2014-04-28 14:28:24 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:28:24 --> Session Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:28:24 --> A session cookie was not found.
DEBUG - 2014-04-28 14:28:24 --> Session routines successfully run
DEBUG - 2014-04-28 14:28:24 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:28:24 --> Model Class Initialized
DEBUG - 2014-04-28 14:28:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:28:24 --> Final output sent to browser
DEBUG - 2014-04-28 14:28:24 --> Total execution time: 0.0140
DEBUG - 2014-04-28 14:31:35 --> Config Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:31:35 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:31:35 --> URI Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Router Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Output Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Security Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Input Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:31:35 --> Config Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Language Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Config Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:31:35 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:31:35 --> Loader Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Controller Class Initialized
DEBUG - 2014-04-28 14:31:35 --> URI Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:31:35 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:31:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:31:35 --> Router Class Initialized
DEBUG - 2014-04-28 14:31:35 --> URI Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:31:35 --> Router Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Output Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Output Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Security Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Security Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Input Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:31:35 --> Input Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:31:35 --> Language Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Language Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Loader Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Loader Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Controller Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:31:35 --> Controller Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:31:35 --> Session Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:31:35 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:31:35 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:31:35 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:31:35 --> A session cookie was not found.
DEBUG - 2014-04-28 14:31:35 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Session routines successfully run
DEBUG - 2014-04-28 14:31:35 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:31:35 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:31:35 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Final output sent to browser
DEBUG - 2014-04-28 14:31:35 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:31:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:31:35 --> Total execution time: 0.0140
DEBUG - 2014-04-28 14:31:35 --> Session Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Session Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:31:35 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:31:35 --> A session cookie was not found.
DEBUG - 2014-04-28 14:31:35 --> A session cookie was not found.
DEBUG - 2014-04-28 14:31:35 --> Session routines successfully run
DEBUG - 2014-04-28 14:31:35 --> Session routines successfully run
DEBUG - 2014-04-28 14:31:35 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:31:35 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:31:35 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:31:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:31:35 --> Final output sent to browser
DEBUG - 2014-04-28 14:31:35 --> Final output sent to browser
DEBUG - 2014-04-28 14:31:35 --> Total execution time: 0.0140
DEBUG - 2014-04-28 14:31:35 --> Total execution time: 0.0140
DEBUG - 2014-04-28 14:31:37 --> Config Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:31:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:31:37 --> URI Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Router Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Output Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Security Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Input Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:31:37 --> Language Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Loader Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Config Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Controller Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:31:37 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Config Class Initialized
DEBUG - 2014-04-28 14:31:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:31:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:31:37 --> URI Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Router Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Output Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Security Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:31:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:31:37 --> Input Class Initialized
DEBUG - 2014-04-28 14:31:37 --> URI Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:31:37 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Router Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Language Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:31:37 --> Output Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Loader Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Security Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Controller Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:31:37 --> Input Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Session Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:31:37 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:31:37 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Language Class Initialized
DEBUG - 2014-04-28 14:31:37 --> A session cookie was not found.
DEBUG - 2014-04-28 14:31:37 --> Session routines successfully run
DEBUG - 2014-04-28 14:31:37 --> Loader Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:31:37 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:31:37 --> Controller Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Final output sent to browser
DEBUG - 2014-04-28 14:31:37 --> Total execution time: 0.0130
DEBUG - 2014-04-28 14:31:37 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:31:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:31:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:31:37 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Session Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:31:37 --> A session cookie was not found.
DEBUG - 2014-04-28 14:31:37 --> Session routines successfully run
DEBUG - 2014-04-28 14:31:37 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:31:37 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:31:37 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:31:37 --> Final output sent to browser
DEBUG - 2014-04-28 14:31:37 --> Session Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Total execution time: 0.0140
DEBUG - 2014-04-28 14:31:37 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:31:37 --> A session cookie was not found.
DEBUG - 2014-04-28 14:31:37 --> Session routines successfully run
DEBUG - 2014-04-28 14:31:37 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:31:37 --> Model Class Initialized
DEBUG - 2014-04-28 14:31:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:31:37 --> Final output sent to browser
DEBUG - 2014-04-28 14:31:37 --> Total execution time: 0.0160
DEBUG - 2014-04-28 14:39:30 --> Config Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Config Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:39:30 --> URI Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Config Class Initialized
DEBUG - 2014-04-28 14:39:30 --> URI Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Router Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Router Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:39:30 --> URI Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Output Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Output Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Router Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Security Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Input Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Output Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Security Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:39:30 --> Input Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Language Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:39:30 --> Security Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Language Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Input Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Loader Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:39:30 --> Controller Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Loader Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Language Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:39:30 --> Controller Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Loader Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:39:30 --> Controller Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:30 --> Session Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:39:30 --> A session cookie was not found.
DEBUG - 2014-04-28 14:39:30 --> Session routines successfully run
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Session Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:39:30 --> A session cookie was not found.
DEBUG - 2014-04-28 14:39:30 --> Session routines successfully run
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:30 --> Final output sent to browser
DEBUG - 2014-04-28 14:39:30 --> Total execution time: 0.0140
DEBUG - 2014-04-28 14:39:30 --> Final output sent to browser
DEBUG - 2014-04-28 14:39:30 --> Session Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Total execution time: 0.0140
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:39:30 --> A session cookie was not found.
DEBUG - 2014-04-28 14:39:30 --> Session routines successfully run
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:30 --> Final output sent to browser
DEBUG - 2014-04-28 14:39:30 --> Total execution time: 0.0160
DEBUG - 2014-04-28 14:39:30 --> Config Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Config Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:39:30 --> URI Class Initialized
DEBUG - 2014-04-28 14:39:30 --> URI Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Router Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Router Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Output Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Output Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Security Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Security Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Input Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:39:30 --> Input Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Config Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Language Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:39:30 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Language Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Loader Class Initialized
DEBUG - 2014-04-28 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:39:30 --> Controller Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Loader Class Initialized
DEBUG - 2014-04-28 14:39:30 --> URI Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Controller Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Router Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:39:30 --> Output Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Security Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Input Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:39:30 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Language Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Loader Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Controller Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:39:30 --> Session Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Session Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:39:30 --> A session cookie was not found.
DEBUG - 2014-04-28 14:39:30 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:39:30 --> A session cookie was not found.
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Session routines successfully run
DEBUG - 2014-04-28 14:39:30 --> Session routines successfully run
DEBUG - 2014-04-28 14:39:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:39:30 --> Session Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> A session cookie was not found.
DEBUG - 2014-04-28 14:39:30 --> Session routines successfully run
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:39:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:30 --> Final output sent to browser
DEBUG - 2014-04-28 14:39:30 --> Total execution time: 0.0140
DEBUG - 2014-04-28 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:30 --> Final output sent to browser
DEBUG - 2014-04-28 14:39:30 --> Total execution time: 0.0130
DEBUG - 2014-04-28 14:39:30 --> Final output sent to browser
DEBUG - 2014-04-28 14:39:30 --> Total execution time: 0.0170
DEBUG - 2014-04-28 14:39:32 --> Config Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Config Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Config Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:39:32 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:39:32 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:39:32 --> URI Class Initialized
DEBUG - 2014-04-28 14:39:32 --> URI Class Initialized
DEBUG - 2014-04-28 14:39:32 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:39:32 --> Router Class Initialized
DEBUG - 2014-04-28 14:39:32 --> URI Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Router Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Router Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Output Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Output Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Output Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Security Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Security Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Security Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Input Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Input Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Input Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:39:32 --> Language Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Language Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Language Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Loader Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Loader Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Loader Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Controller Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Controller Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Controller Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:39:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:39:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:39:32 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:39:32 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:39:32 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:39:32 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:32 --> Session Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Session Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:39:32 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:39:32 --> A session cookie was not found.
DEBUG - 2014-04-28 14:39:32 --> A session cookie was not found.
DEBUG - 2014-04-28 14:39:32 --> Session routines successfully run
DEBUG - 2014-04-28 14:39:32 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:39:32 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Session routines successfully run
DEBUG - 2014-04-28 14:39:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:32 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:39:32 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:32 --> Final output sent to browser
DEBUG - 2014-04-28 14:39:32 --> Total execution time: 0.0130
DEBUG - 2014-04-28 14:39:32 --> Session Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:39:32 --> A session cookie was not found.
DEBUG - 2014-04-28 14:39:32 --> Session routines successfully run
DEBUG - 2014-04-28 14:39:32 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:39:32 --> Model Class Initialized
DEBUG - 2014-04-28 14:39:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:39:32 --> Final output sent to browser
DEBUG - 2014-04-28 14:39:32 --> Total execution time: 0.0150
DEBUG - 2014-04-28 14:39:32 --> Final output sent to browser
DEBUG - 2014-04-28 14:39:32 --> Total execution time: 0.0170
DEBUG - 2014-04-28 14:43:55 --> Config Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Config Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Config Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:43:55 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:43:55 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:43:55 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:43:55 --> URI Class Initialized
DEBUG - 2014-04-28 14:43:55 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:43:55 --> URI Class Initialized
DEBUG - 2014-04-28 14:43:55 --> URI Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Router Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Router Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Router Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Output Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Output Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Output Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Security Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Security Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Security Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Input Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Input Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Input Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:43:55 --> Language Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Loader Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Controller Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:43:55 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:43:55 --> Language Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:43:55 --> Loader Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Language Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Controller Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Loader Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:43:55 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:43:55 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Controller Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:43:55 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:43:55 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:43:55 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Session Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:43:55 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:43:55 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:43:55 --> A session cookie was not found.
DEBUG - 2014-04-28 14:43:55 --> Session Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Session routines successfully run
DEBUG - 2014-04-28 14:43:55 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:43:55 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:43:55 --> A session cookie was not found.
DEBUG - 2014-04-28 14:43:55 --> Session routines successfully run
DEBUG - 2014-04-28 14:43:55 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:43:55 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:43:55 --> Final output sent to browser
DEBUG - 2014-04-28 14:43:55 --> Total execution time: 0.0140
DEBUG - 2014-04-28 14:43:55 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:43:55 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:43:55 --> Session Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Final output sent to browser
DEBUG - 2014-04-28 14:43:55 --> Total execution time: 0.0170
DEBUG - 2014-04-28 14:43:55 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:43:55 --> A session cookie was not found.
DEBUG - 2014-04-28 14:43:55 --> Session routines successfully run
DEBUG - 2014-04-28 14:43:55 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:43:55 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:43:55 --> Final output sent to browser
DEBUG - 2014-04-28 14:43:55 --> Total execution time: 0.0190
DEBUG - 2014-04-28 14:43:57 --> Config Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Config Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:43:57 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:43:57 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:43:57 --> URI Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Router Class Initialized
DEBUG - 2014-04-28 14:43:57 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:43:57 --> URI Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Router Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Output Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Output Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Security Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Security Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Input Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Input Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:43:57 --> Config Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Language Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Language Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Hooks Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Loader Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Loader Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Utf8 Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Controller Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Controller Class Initialized
DEBUG - 2014-04-28 14:43:57 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 14:43:57 --> URI Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:43:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:43:57 --> Router Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:43:57 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:43:57 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Output Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Security Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Input Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 14:43:57 --> Language Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Loader Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:43:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:43:57 --> Session Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Session Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Controller Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:43:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 14:43:57 --> A session cookie was not found.
DEBUG - 2014-04-28 14:43:57 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:43:57 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 14:43:57 --> Session routines successfully run
DEBUG - 2014-04-28 14:43:57 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:43:57 --> A session cookie was not found.
DEBUG - 2014-04-28 14:43:57 --> Session routines successfully run
DEBUG - 2014-04-28 14:43:57 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:43:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:43:57 --> Database Driver Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Final output sent to browser
DEBUG - 2014-04-28 14:43:57 --> Total execution time: 0.0130
DEBUG - 2014-04-28 14:43:57 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:43:57 --> Session Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Helper loaded: string_helper
DEBUG - 2014-04-28 14:43:57 --> A session cookie was not found.
DEBUG - 2014-04-28 14:43:57 --> Session routines successfully run
DEBUG - 2014-04-28 14:43:57 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Helper loaded: url_helper
DEBUG - 2014-04-28 14:43:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:43:57 --> Final output sent to browser
DEBUG - 2014-04-28 14:43:57 --> Total execution time: 0.0160
DEBUG - 2014-04-28 14:43:57 --> Model Class Initialized
DEBUG - 2014-04-28 14:43:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 14:43:57 --> Final output sent to browser
DEBUG - 2014-04-28 14:43:57 --> Total execution time: 0.0160
DEBUG - 2014-04-28 22:24:45 --> Config Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Config Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Config Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:24:45 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:24:45 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:24:45 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:24:45 --> URI Class Initialized
DEBUG - 2014-04-28 22:24:45 --> URI Class Initialized
DEBUG - 2014-04-28 22:24:45 --> URI Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Router Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Router Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Router Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Output Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Output Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Output Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Security Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Security Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Security Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Input Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Input Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Input Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:24:45 --> Language Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Language Class Initialized
DEBUG - 2014-04-28 22:24:45 --> Language Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Loader Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Loader Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Loader Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Controller Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Controller Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Controller Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:24:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:24:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:24:46 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:24:46 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:24:46 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:24:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:24:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:24:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:24:46 --> Session Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Session Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Session Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:24:46 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:24:46 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:24:46 --> A session cookie was not found.
DEBUG - 2014-04-28 22:24:46 --> A session cookie was not found.
DEBUG - 2014-04-28 22:24:46 --> A session cookie was not found.
DEBUG - 2014-04-28 22:24:46 --> Session routines successfully run
DEBUG - 2014-04-28 22:24:46 --> Session routines successfully run
DEBUG - 2014-04-28 22:24:46 --> Session routines successfully run
DEBUG - 2014-04-28 22:24:46 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:24:46 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:24:46 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:24:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:24:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:24:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:24:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:24:46 --> Final output sent to browser
DEBUG - 2014-04-28 22:24:46 --> Final output sent to browser
DEBUG - 2014-04-28 22:24:46 --> Final output sent to browser
DEBUG - 2014-04-28 22:24:46 --> Total execution time: 1.4931
DEBUG - 2014-04-28 22:24:46 --> Total execution time: 1.4931
DEBUG - 2014-04-28 22:24:46 --> Total execution time: 1.4931
DEBUG - 2014-04-28 22:29:40 --> Config Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:29:40 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:29:40 --> URI Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Router Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Output Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Security Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Input Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:29:40 --> Language Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Loader Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Controller Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:29:40 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:29:40 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Config Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:29:40 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:29:40 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:29:40 --> URI Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Router Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Output Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:29:40 --> Security Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Input Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:29:40 --> Session Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Language Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:29:40 --> A session cookie was not found.
DEBUG - 2014-04-28 22:29:40 --> Session routines successfully run
DEBUG - 2014-04-28 22:29:40 --> Loader Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Controller Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:29:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:29:40 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:29:40 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:29:40 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Final output sent to browser
DEBUG - 2014-04-28 22:29:40 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:29:40 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:29:40 --> Session Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:29:40 --> A session cookie was not found.
DEBUG - 2014-04-28 22:29:40 --> Session routines successfully run
DEBUG - 2014-04-28 22:29:40 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:29:40 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:29:40 --> Final output sent to browser
DEBUG - 2014-04-28 22:29:40 --> Total execution time: 0.0100
DEBUG - 2014-04-28 22:29:40 --> Config Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:29:40 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:29:40 --> URI Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Router Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Output Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Security Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Input Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:29:40 --> Language Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Loader Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Controller Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:29:40 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:29:40 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:29:40 --> Session Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:29:40 --> A session cookie was not found.
DEBUG - 2014-04-28 22:29:40 --> Session routines successfully run
DEBUG - 2014-04-28 22:29:40 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:29:40 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:29:40 --> Final output sent to browser
DEBUG - 2014-04-28 22:29:40 --> Total execution time: 0.0120
DEBUG - 2014-04-28 22:29:41 --> Config Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Config Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:29:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:29:41 --> Config Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:29:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:29:41 --> URI Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:29:41 --> URI Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Router Class Initialized
DEBUG - 2014-04-28 22:29:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:29:41 --> Router Class Initialized
DEBUG - 2014-04-28 22:29:41 --> URI Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Output Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Router Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Output Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Security Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Security Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Input Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Output Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Input Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:29:41 --> Security Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:29:41 --> Language Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Input Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Language Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Loader Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:29:41 --> Controller Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Loader Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Controller Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Language Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:29:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:29:41 --> Loader Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:29:41 --> Controller Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:29:41 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:29:41 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:29:41 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:29:41 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Session Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:29:41 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:29:41 --> Session Class Initialized
DEBUG - 2014-04-28 22:29:41 --> A session cookie was not found.
DEBUG - 2014-04-28 22:29:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:29:41 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:29:41 --> Session routines successfully run
DEBUG - 2014-04-28 22:29:41 --> Session Class Initialized
DEBUG - 2014-04-28 22:29:41 --> A session cookie was not found.
DEBUG - 2014-04-28 22:29:41 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:29:41 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:29:41 --> Session routines successfully run
DEBUG - 2014-04-28 22:29:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:29:41 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:29:41 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:41 --> A session cookie was not found.
DEBUG - 2014-04-28 22:29:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:29:41 --> Final output sent to browser
DEBUG - 2014-04-28 22:29:41 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:29:41 --> Session routines successfully run
DEBUG - 2014-04-28 22:29:41 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:29:41 --> Final output sent to browser
DEBUG - 2014-04-28 22:29:41 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:29:41 --> Model Class Initialized
DEBUG - 2014-04-28 22:29:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:29:41 --> Final output sent to browser
DEBUG - 2014-04-28 22:29:41 --> Total execution time: 0.0140
DEBUG - 2014-04-28 22:30:32 --> Config Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Config Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Config Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:30:32 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:30:32 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:30:32 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:30:32 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:30:32 --> URI Class Initialized
DEBUG - 2014-04-28 22:30:32 --> URI Class Initialized
DEBUG - 2014-04-28 22:30:32 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:30:32 --> Router Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Router Class Initialized
DEBUG - 2014-04-28 22:30:32 --> URI Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Router Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Output Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Output Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Output Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Security Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Security Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Security Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Input Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Input Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Input Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:30:32 --> Language Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Language Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Loader Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Loader Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:30:32 --> Controller Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Controller Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Language Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:30:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:30:32 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:30:32 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:30:32 --> Loader Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Controller Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:30:32 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:30:32 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:30:32 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Session Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:30:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:30:32 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:30:32 --> A session cookie was not found.
DEBUG - 2014-04-28 22:30:32 --> Session Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Session Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Session routines successfully run
DEBUG - 2014-04-28 22:30:32 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:30:32 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:30:32 --> A session cookie was not found.
DEBUG - 2014-04-28 22:30:32 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:30:32 --> A session cookie was not found.
DEBUG - 2014-04-28 22:30:32 --> Session routines successfully run
DEBUG - 2014-04-28 22:30:32 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Session routines successfully run
DEBUG - 2014-04-28 22:30:32 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:30:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:30:32 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:30:32 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:30:32 --> Final output sent to browser
DEBUG - 2014-04-28 22:30:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:30:32 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:30:32 --> Final output sent to browser
DEBUG - 2014-04-28 22:30:32 --> Total execution time: 0.0120
DEBUG - 2014-04-28 22:30:32 --> Final output sent to browser
DEBUG - 2014-04-28 22:30:32 --> Total execution time: 0.0140
DEBUG - 2014-04-28 22:30:34 --> Config Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Config Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:30:34 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:30:34 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:30:34 --> URI Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Router Class Initialized
DEBUG - 2014-04-28 22:30:34 --> URI Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Router Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Output Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Output Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Security Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Security Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Input Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:30:34 --> Language Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Config Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Input Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:30:34 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Loader Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Language Class Initialized
DEBUG - 2014-04-28 22:30:34 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:30:34 --> Controller Class Initialized
DEBUG - 2014-04-28 22:30:34 --> URI Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Loader Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:30:34 --> Router Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Controller Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:30:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:30:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Output Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:30:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Security Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Input Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:30:34 --> Language Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Loader Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Controller Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:30:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:30:34 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:30:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Session Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:30:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:30:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:34 --> A session cookie was not found.
DEBUG - 2014-04-28 22:30:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Session routines successfully run
DEBUG - 2014-04-28 22:30:34 --> Session Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:30:34 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:30:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:34 --> A session cookie was not found.
DEBUG - 2014-04-28 22:30:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:30:34 --> Session routines successfully run
DEBUG - 2014-04-28 22:30:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:30:34 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:30:34 --> Final output sent to browser
DEBUG - 2014-04-28 22:30:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Session Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Total execution time: 0.0120
DEBUG - 2014-04-28 22:30:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:30:34 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:30:34 --> A session cookie was not found.
DEBUG - 2014-04-28 22:30:34 --> Session routines successfully run
DEBUG - 2014-04-28 22:30:34 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:30:34 --> Final output sent to browser
DEBUG - 2014-04-28 22:30:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:30:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:30:34 --> Total execution time: 0.0140
DEBUG - 2014-04-28 22:30:34 --> Final output sent to browser
DEBUG - 2014-04-28 22:30:34 --> Total execution time: 0.0120
DEBUG - 2014-04-28 22:32:19 --> Config Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Config Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Config Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:32:19 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:32:19 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:32:19 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:32:19 --> URI Class Initialized
DEBUG - 2014-04-28 22:32:19 --> URI Class Initialized
DEBUG - 2014-04-28 22:32:19 --> URI Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Router Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Router Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Router Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Output Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Output Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Output Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Security Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Security Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Security Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Input Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Input Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:32:19 --> Language Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Language Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Input Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Loader Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Loader Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:32:19 --> Controller Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Language Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Controller Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:32:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:32:19 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:32:19 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:32:19 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Loader Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Controller Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:32:19 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:32:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:32:19 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Session Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:32:19 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:32:19 --> A session cookie was not found.
DEBUG - 2014-04-28 22:32:19 --> Session routines successfully run
DEBUG - 2014-04-28 22:32:19 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:32:19 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:32:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:32:19 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Session Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:32:19 --> Final output sent to browser
DEBUG - 2014-04-28 22:32:19 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:32:19 --> Total execution time: 0.0140
DEBUG - 2014-04-28 22:32:19 --> A session cookie was not found.
DEBUG - 2014-04-28 22:32:19 --> Session Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Session routines successfully run
DEBUG - 2014-04-28 22:32:19 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:32:19 --> A session cookie was not found.
DEBUG - 2014-04-28 22:32:19 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:32:19 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Session routines successfully run
DEBUG - 2014-04-28 22:32:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:32:19 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:32:19 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:32:19 --> Final output sent to browser
DEBUG - 2014-04-28 22:32:19 --> Total execution time: 0.0170
DEBUG - 2014-04-28 22:32:19 --> Final output sent to browser
DEBUG - 2014-04-28 22:32:19 --> Total execution time: 0.0170
DEBUG - 2014-04-28 22:32:21 --> Config Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Config Class Initialized
DEBUG - 2014-04-28 22:32:21 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:32:21 --> Config Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:32:21 --> URI Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Router Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:32:21 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:32:21 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:32:21 --> URI Class Initialized
DEBUG - 2014-04-28 22:32:21 --> URI Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Router Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Output Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Router Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Output Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Output Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Security Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Security Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Input Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Input Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Security Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:32:21 --> Input Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:32:21 --> Language Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:32:21 --> Language Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Loader Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Controller Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Language Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Loader Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:32:21 --> Controller Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:32:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:32:21 --> Loader Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Controller Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:32:21 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:32:21 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:32:21 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:32:21 --> Session Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:32:21 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:21 --> A session cookie was not found.
DEBUG - 2014-04-28 22:32:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:32:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:32:21 --> Session routines successfully run
DEBUG - 2014-04-28 22:32:21 --> Session Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:32:21 --> Session Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:32:21 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:21 --> A session cookie was not found.
DEBUG - 2014-04-28 22:32:21 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:32:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:32:21 --> Session routines successfully run
DEBUG - 2014-04-28 22:32:21 --> A session cookie was not found.
DEBUG - 2014-04-28 22:32:21 --> Session routines successfully run
DEBUG - 2014-04-28 22:32:21 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:32:21 --> Final output sent to browser
DEBUG - 2014-04-28 22:32:21 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:32:21 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:32:21 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Model Class Initialized
DEBUG - 2014-04-28 22:32:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:32:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:32:21 --> Final output sent to browser
DEBUG - 2014-04-28 22:32:21 --> Final output sent to browser
DEBUG - 2014-04-28 22:32:21 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:32:21 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:34:35 --> Config Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:34:35 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:34:35 --> URI Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Router Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Output Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Security Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Input Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Config Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:34:35 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Language Class Initialized
DEBUG - 2014-04-28 22:34:35 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:34:35 --> URI Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Loader Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Router Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Controller Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:34:35 --> Output Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:34:35 --> Security Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Model Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Input Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:34:35 --> Model Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Language Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Loader Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Controller Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:34:35 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:34:35 --> Model Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Model Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:34:35 --> Model Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Session Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:34:35 --> A session cookie was not found.
DEBUG - 2014-04-28 22:34:35 --> Session routines successfully run
DEBUG - 2014-04-28 22:34:35 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:34:35 --> Model Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Model Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:34:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:34:35 --> Session Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Final output sent to browser
DEBUG - 2014-04-28 22:34:35 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:34:35 --> Total execution time: 0.0230
DEBUG - 2014-04-28 22:34:35 --> A session cookie was not found.
DEBUG - 2014-04-28 22:34:35 --> Config Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Session routines successfully run
DEBUG - 2014-04-28 22:34:35 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:34:35 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:34:35 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:34:35 --> Model Class Initialized
DEBUG - 2014-04-28 22:34:35 --> URI Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:34:35 --> Router Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Final output sent to browser
DEBUG - 2014-04-28 22:34:35 --> Total execution time: 0.0200
DEBUG - 2014-04-28 22:34:35 --> Output Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Security Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Input Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:34:35 --> Language Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Loader Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Controller Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:34:35 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:34:35 --> Model Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Model Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Model Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:34:35 --> Session Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:34:35 --> A session cookie was not found.
DEBUG - 2014-04-28 22:34:35 --> Session routines successfully run
DEBUG - 2014-04-28 22:34:35 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:34:35 --> Model Class Initialized
DEBUG - 2014-04-28 22:34:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:34:35 --> Final output sent to browser
DEBUG - 2014-04-28 22:34:35 --> Total execution time: 0.0140
DEBUG - 2014-04-28 22:35:45 --> Config Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Config Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:35:45 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:35:45 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:35:45 --> URI Class Initialized
DEBUG - 2014-04-28 22:35:45 --> URI Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Router Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Router Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Output Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Output Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Security Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Security Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Input Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Input Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:35:45 --> Language Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Language Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Loader Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Loader Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Controller Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Controller Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:35:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:35:45 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:35:45 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:35:45 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:45 --> Session Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Session Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:35:45 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:35:45 --> A session cookie was not found.
DEBUG - 2014-04-28 22:35:45 --> A session cookie was not found.
DEBUG - 2014-04-28 22:35:45 --> Session routines successfully run
DEBUG - 2014-04-28 22:35:45 --> Session routines successfully run
DEBUG - 2014-04-28 22:35:45 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:35:45 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:35:45 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:45 --> Final output sent to browser
DEBUG - 2014-04-28 22:35:45 --> Final output sent to browser
DEBUG - 2014-04-28 22:35:45 --> Total execution time: 0.0140
DEBUG - 2014-04-28 22:35:45 --> Total execution time: 0.0140
DEBUG - 2014-04-28 22:35:45 --> Config Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:35:45 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:35:45 --> URI Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Router Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Output Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Security Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Input Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:35:45 --> Language Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Loader Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Controller Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:35:45 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:35:45 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:45 --> Session Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:35:45 --> A session cookie was not found.
DEBUG - 2014-04-28 22:35:45 --> Session routines successfully run
DEBUG - 2014-04-28 22:35:45 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:35:45 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:45 --> Final output sent to browser
DEBUG - 2014-04-28 22:35:45 --> Total execution time: 0.0110
DEBUG - 2014-04-28 22:35:46 --> Config Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Config Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:35:46 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:35:46 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:35:46 --> URI Class Initialized
DEBUG - 2014-04-28 22:35:46 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:35:46 --> Router Class Initialized
DEBUG - 2014-04-28 22:35:46 --> URI Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Config Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Router Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Output Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:35:46 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:35:46 --> Security Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Output Class Initialized
DEBUG - 2014-04-28 22:35:46 --> URI Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Input Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Security Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:35:46 --> Router Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Input Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:35:46 --> Language Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Output Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Language Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Loader Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Security Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Controller Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Loader Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Input Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Controller Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:35:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:35:46 --> Language Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:35:46 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:35:46 --> Loader Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Controller Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:35:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:35:46 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:46 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Session Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:46 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:35:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Session Class Initialized
DEBUG - 2014-04-28 22:35:46 --> A session cookie was not found.
DEBUG - 2014-04-28 22:35:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:46 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:35:46 --> Session routines successfully run
DEBUG - 2014-04-28 22:35:46 --> A session cookie was not found.
DEBUG - 2014-04-28 22:35:46 --> Session Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:35:46 --> Session routines successfully run
DEBUG - 2014-04-28 22:35:46 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:35:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:35:46 --> A session cookie was not found.
DEBUG - 2014-04-28 22:35:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:46 --> Session routines successfully run
DEBUG - 2014-04-28 22:35:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:46 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:35:46 --> Final output sent to browser
DEBUG - 2014-04-28 22:35:46 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:46 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:35:46 --> Final output sent to browser
DEBUG - 2014-04-28 22:35:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:46 --> Total execution time: 0.0120
DEBUG - 2014-04-28 22:35:46 --> Final output sent to browser
DEBUG - 2014-04-28 22:35:46 --> Total execution time: 0.0120
DEBUG - 2014-04-28 22:35:47 --> Config Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Config Class Initialized
DEBUG - 2014-04-28 22:35:47 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:35:47 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:35:47 --> URI Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Config Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Router Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:35:47 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:35:47 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:35:47 --> URI Class Initialized
DEBUG - 2014-04-28 22:35:47 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:35:47 --> Output Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Router Class Initialized
DEBUG - 2014-04-28 22:35:47 --> URI Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Security Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Router Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Input Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Output Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:35:47 --> Security Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Language Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Output Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Input Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:35:47 --> Loader Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Security Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Language Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Controller Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Input Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:35:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:35:47 --> Loader Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Language Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Controller Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:35:47 --> Loader Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:35:47 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Controller Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:35:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:35:47 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:35:47 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:47 --> Session Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Session Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:35:47 --> A session cookie was not found.
DEBUG - 2014-04-28 22:35:47 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:35:47 --> Session routines successfully run
DEBUG - 2014-04-28 22:35:47 --> A session cookie was not found.
DEBUG - 2014-04-28 22:35:47 --> Session routines successfully run
DEBUG - 2014-04-28 22:35:47 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:35:47 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:35:47 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:47 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Session Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Final output sent to browser
DEBUG - 2014-04-28 22:35:47 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:35:47 --> Total execution time: 0.0110
DEBUG - 2014-04-28 22:35:47 --> A session cookie was not found.
DEBUG - 2014-04-28 22:35:47 --> Session routines successfully run
DEBUG - 2014-04-28 22:35:47 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:35:47 --> Model Class Initialized
DEBUG - 2014-04-28 22:35:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:35:47 --> Final output sent to browser
DEBUG - 2014-04-28 22:35:47 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:35:47 --> Final output sent to browser
DEBUG - 2014-04-28 22:35:47 --> Total execution time: 0.0140
DEBUG - 2014-04-28 22:39:43 --> Config Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Config Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Config Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:39:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:39:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:39:43 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:39:43 --> URI Class Initialized
DEBUG - 2014-04-28 22:39:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:39:43 --> URI Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Router Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Router Class Initialized
DEBUG - 2014-04-28 22:39:43 --> URI Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Router Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Output Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Output Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Output Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Security Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Security Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Security Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Input Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Input Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:39:43 --> Input Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Language Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:39:43 --> Language Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Language Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Loader Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Loader Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Loader Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Controller Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Controller Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Controller Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:39:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:39:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:39:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:39:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:39:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:39:43 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:39:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:39:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:39:43 --> Session Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Session Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Session Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:39:43 --> A session cookie was not found.
DEBUG - 2014-04-28 22:39:43 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:39:43 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:39:43 --> A session cookie was not found.
DEBUG - 2014-04-28 22:39:43 --> Session routines successfully run
DEBUG - 2014-04-28 22:39:43 --> A session cookie was not found.
DEBUG - 2014-04-28 22:39:43 --> Session routines successfully run
DEBUG - 2014-04-28 22:39:43 --> Session routines successfully run
DEBUG - 2014-04-28 22:39:43 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:39:43 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:39:43 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:39:43 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:39:43 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:39:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:39:43 --> Final output sent to browser
DEBUG - 2014-04-28 22:39:43 --> Final output sent to browser
DEBUG - 2014-04-28 22:39:43 --> Final output sent to browser
DEBUG - 2014-04-28 22:39:43 --> Total execution time: 0.0150
DEBUG - 2014-04-28 22:39:43 --> Total execution time: 0.0140
DEBUG - 2014-04-28 22:39:43 --> Total execution time: 0.0150
DEBUG - 2014-04-28 22:39:51 --> Config Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:39:51 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:39:51 --> URI Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Router Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Output Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Security Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Input Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:39:51 --> Language Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Loader Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Controller Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:39:51 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:39:51 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Config Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Config Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:39:51 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:39:51 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:39:51 --> URI Class Initialized
DEBUG - 2014-04-28 22:39:51 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:39:51 --> Router Class Initialized
DEBUG - 2014-04-28 22:39:51 --> URI Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Router Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Output Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Security Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Output Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Input Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Security Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:39:51 --> Input Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Language Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:39:51 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Language Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Loader Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:39:51 --> Controller Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Loader Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Session Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:39:51 --> Controller Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:39:51 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:39:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:39:51 --> A session cookie was not found.
DEBUG - 2014-04-28 22:39:51 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:39:51 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Session routines successfully run
DEBUG - 2014-04-28 22:39:51 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:39:51 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:39:51 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Final output sent to browser
DEBUG - 2014-04-28 22:39:51 --> Total execution time: 0.0160
DEBUG - 2014-04-28 22:39:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:39:51 --> Session Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:39:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:39:51 --> A session cookie was not found.
DEBUG - 2014-04-28 22:39:51 --> Session routines successfully run
DEBUG - 2014-04-28 22:39:51 --> Session Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:39:51 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:39:51 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:51 --> A session cookie was not found.
DEBUG - 2014-04-28 22:39:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:39:51 --> Session routines successfully run
DEBUG - 2014-04-28 22:39:51 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:39:51 --> Model Class Initialized
DEBUG - 2014-04-28 22:39:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:39:51 --> Final output sent to browser
DEBUG - 2014-04-28 22:39:51 --> Total execution time: 0.0120
DEBUG - 2014-04-28 22:39:51 --> Final output sent to browser
DEBUG - 2014-04-28 22:39:51 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:41:09 --> Config Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Config Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Config Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:41:09 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:41:09 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:41:09 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:41:09 --> URI Class Initialized
DEBUG - 2014-04-28 22:41:09 --> URI Class Initialized
DEBUG - 2014-04-28 22:41:09 --> URI Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Router Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Router Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Router Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Output Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Output Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Output Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Security Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Security Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Security Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Input Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Input Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Input Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:41:09 --> Language Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Language Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Language Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Loader Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Loader Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Loader Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Controller Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Controller Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Controller Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:41:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:41:09 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:41:09 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:41:09 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:41:09 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:41:09 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:41:09 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Session Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:41:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:41:09 --> A session cookie was not found.
DEBUG - 2014-04-28 22:41:09 --> Session routines successfully run
DEBUG - 2014-04-28 22:41:09 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Session Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:41:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:41:09 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:41:09 --> A session cookie was not found.
DEBUG - 2014-04-28 22:41:09 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Session Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Session routines successfully run
DEBUG - 2014-04-28 22:41:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:41:09 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:41:09 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:41:09 --> A session cookie was not found.
DEBUG - 2014-04-28 22:41:09 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Session routines successfully run
DEBUG - 2014-04-28 22:41:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:41:09 --> Final output sent to browser
DEBUG - 2014-04-28 22:41:09 --> Total execution time: 0.0150
DEBUG - 2014-04-28 22:41:09 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:41:09 --> Final output sent to browser
DEBUG - 2014-04-28 22:41:09 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:09 --> Total execution time: 0.0160
DEBUG - 2014-04-28 22:41:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:41:09 --> Final output sent to browser
DEBUG - 2014-04-28 22:41:09 --> Total execution time: 0.0170
DEBUG - 2014-04-28 22:41:10 --> Config Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Config Class Initialized
DEBUG - 2014-04-28 22:41:10 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:41:10 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Config Class Initialized
DEBUG - 2014-04-28 22:41:10 --> URI Class Initialized
DEBUG - 2014-04-28 22:41:10 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:41:10 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Router Class Initialized
DEBUG - 2014-04-28 22:41:10 --> URI Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:41:10 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:41:10 --> Router Class Initialized
DEBUG - 2014-04-28 22:41:10 --> URI Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Output Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Router Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Output Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Security Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Security Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Input Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Output Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:41:10 --> Input Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Security Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Language Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:41:10 --> Input Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Language Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Loader Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:41:10 --> Controller Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Language Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Loader Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:41:10 --> Controller Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Loader Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:41:10 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:41:10 --> Controller Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:41:10 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:41:10 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:41:10 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:41:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:41:10 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:41:10 --> Session Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Session Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:41:10 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:41:10 --> Session Class Initialized
DEBUG - 2014-04-28 22:41:10 --> A session cookie was not found.
DEBUG - 2014-04-28 22:41:10 --> A session cookie was not found.
DEBUG - 2014-04-28 22:41:10 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:41:10 --> Session routines successfully run
DEBUG - 2014-04-28 22:41:10 --> Session routines successfully run
DEBUG - 2014-04-28 22:41:10 --> A session cookie was not found.
DEBUG - 2014-04-28 22:41:10 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:41:10 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:41:10 --> Session routines successfully run
DEBUG - 2014-04-28 22:41:10 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:41:10 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Model Class Initialized
DEBUG - 2014-04-28 22:41:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:41:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:41:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:41:10 --> Final output sent to browser
DEBUG - 2014-04-28 22:41:10 --> Final output sent to browser
DEBUG - 2014-04-28 22:41:10 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:41:10 --> Total execution time: 0.0140
DEBUG - 2014-04-28 22:41:10 --> Final output sent to browser
DEBUG - 2014-04-28 22:41:10 --> Total execution time: 0.0120
DEBUG - 2014-04-28 22:42:39 --> Config Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:42:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:42:39 --> URI Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Router Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Output Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Security Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Input Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:42:39 --> Language Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Loader Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Controller Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:42:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:42:39 --> Model Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Model Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Model Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:42:39 --> Session Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:42:39 --> Session routines successfully run
DEBUG - 2014-04-28 22:42:39 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:42:39 --> Model Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:42:39 --> Final output sent to browser
DEBUG - 2014-04-28 22:42:39 --> Total execution time: 0.0120
DEBUG - 2014-04-28 22:42:39 --> Config Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:42:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:42:39 --> URI Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Router Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Output Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Security Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Input Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:42:39 --> Language Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Loader Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Controller Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:42:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:42:39 --> Model Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Model Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Model Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:42:39 --> Session Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:42:39 --> Session routines successfully run
DEBUG - 2014-04-28 22:42:39 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:42:39 --> Model Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:42:39 --> Final output sent to browser
DEBUG - 2014-04-28 22:42:39 --> Total execution time: 0.0120
DEBUG - 2014-04-28 22:42:39 --> Config Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:42:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:42:39 --> URI Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Router Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Output Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Security Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Input Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:42:39 --> Language Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Loader Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Controller Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:42:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:42:39 --> Model Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Model Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Model Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:42:39 --> Session Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:42:39 --> Session routines successfully run
DEBUG - 2014-04-28 22:42:39 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:42:39 --> Model Class Initialized
DEBUG - 2014-04-28 22:42:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:42:39 --> Final output sent to browser
DEBUG - 2014-04-28 22:42:39 --> Total execution time: 0.0110
DEBUG - 2014-04-28 22:44:54 --> Config Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Config Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Config Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:44:54 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:44:54 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:44:54 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:44:54 --> URI Class Initialized
DEBUG - 2014-04-28 22:44:54 --> URI Class Initialized
DEBUG - 2014-04-28 22:44:54 --> URI Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Router Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Router Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Router Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Output Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Output Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Output Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Security Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Security Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Security Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Input Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Input Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Input Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:44:54 --> Language Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Language Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Language Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Loader Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Loader Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Loader Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Controller Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Controller Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Controller Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:44:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:44:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:44:54 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:44:54 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:44:54 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:44:54 --> Model Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Model Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Model Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Model Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Model Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Model Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Model Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Model Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:44:54 --> Model Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:44:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:44:54 --> Session Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Session Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Session Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:44:54 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:44:54 --> A session cookie was not found.
DEBUG - 2014-04-28 22:44:54 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:44:54 --> A session cookie was not found.
DEBUG - 2014-04-28 22:44:54 --> A session cookie was not found.
DEBUG - 2014-04-28 22:44:54 --> Session routines successfully run
DEBUG - 2014-04-28 22:44:54 --> Session routines successfully run
DEBUG - 2014-04-28 22:44:54 --> Session routines successfully run
DEBUG - 2014-04-28 22:44:54 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:44:54 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:44:54 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:44:54 --> Model Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Model Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:44:54 --> Model Class Initialized
DEBUG - 2014-04-28 22:44:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:44:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:44:54 --> Final output sent to browser
DEBUG - 2014-04-28 22:44:54 --> Final output sent to browser
DEBUG - 2014-04-28 22:44:54 --> Final output sent to browser
DEBUG - 2014-04-28 22:44:54 --> Total execution time: 0.0120
DEBUG - 2014-04-28 22:44:54 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:44:54 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:45:14 --> Config Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Config Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Config Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:45:14 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:45:14 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:45:14 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:45:14 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:45:14 --> URI Class Initialized
DEBUG - 2014-04-28 22:45:14 --> URI Class Initialized
DEBUG - 2014-04-28 22:45:14 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:45:14 --> Router Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Router Class Initialized
DEBUG - 2014-04-28 22:45:14 --> URI Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Router Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Output Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Output Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Output Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Security Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Security Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Security Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Input Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Input Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Input Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:45:14 --> Language Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Language Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Loader Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Loader Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Controller Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Controller Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:45:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:45:14 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:45:14 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:45:14 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Language Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:14 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Loader Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Session Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Controller Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:14 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:45:14 --> A session cookie was not found.
DEBUG - 2014-04-28 22:45:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:45:14 --> Session Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Session routines successfully run
DEBUG - 2014-04-28 22:45:14 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:45:14 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:45:14 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:45:14 --> A session cookie was not found.
DEBUG - 2014-04-28 22:45:14 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Session routines successfully run
DEBUG - 2014-04-28 22:45:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:14 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:45:14 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:14 --> Final output sent to browser
DEBUG - 2014-04-28 22:45:14 --> Total execution time: 0.0110
DEBUG - 2014-04-28 22:45:14 --> Final output sent to browser
DEBUG - 2014-04-28 22:45:14 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:45:14 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:14 --> Session Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:45:14 --> A session cookie was not found.
DEBUG - 2014-04-28 22:45:14 --> Session routines successfully run
DEBUG - 2014-04-28 22:45:14 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:45:14 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:14 --> Final output sent to browser
DEBUG - 2014-04-28 22:45:14 --> Total execution time: 0.0180
DEBUG - 2014-04-28 22:45:15 --> Config Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Config Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:45:15 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:45:15 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:45:15 --> URI Class Initialized
DEBUG - 2014-04-28 22:45:15 --> URI Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Router Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Router Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Output Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Output Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Security Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Security Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Config Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Input Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Input Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:45:15 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Language Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Language Class Initialized
DEBUG - 2014-04-28 22:45:15 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:45:15 --> Loader Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Loader Class Initialized
DEBUG - 2014-04-28 22:45:15 --> URI Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Controller Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Controller Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Router Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:45:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:45:15 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:45:15 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:45:15 --> Output Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Security Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Input Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:45:15 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Language Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Loader Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Controller Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:45:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:15 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:45:15 --> Session Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Session Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:45:15 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:45:15 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:15 --> A session cookie was not found.
DEBUG - 2014-04-28 22:45:15 --> A session cookie was not found.
DEBUG - 2014-04-28 22:45:15 --> Session routines successfully run
DEBUG - 2014-04-28 22:45:15 --> Session routines successfully run
DEBUG - 2014-04-28 22:45:15 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:45:15 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:45:15 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:15 --> Final output sent to browser
DEBUG - 2014-04-28 22:45:15 --> Final output sent to browser
DEBUG - 2014-04-28 22:45:15 --> Total execution time: 0.0120
DEBUG - 2014-04-28 22:45:15 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:45:15 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:15 --> Session Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:45:15 --> A session cookie was not found.
DEBUG - 2014-04-28 22:45:15 --> Session routines successfully run
DEBUG - 2014-04-28 22:45:15 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:45:15 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:15 --> Final output sent to browser
DEBUG - 2014-04-28 22:45:15 --> Total execution time: 0.0140
DEBUG - 2014-04-28 22:45:16 --> Config Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Config Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Config Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:45:16 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:45:16 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:45:16 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:45:16 --> URI Class Initialized
DEBUG - 2014-04-28 22:45:16 --> URI Class Initialized
DEBUG - 2014-04-28 22:45:16 --> URI Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Router Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Router Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Router Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Output Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Output Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Output Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Security Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Security Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Security Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Input Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Input Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Input Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:45:16 --> Language Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Language Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Language Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Loader Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Loader Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Loader Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Controller Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Controller Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:45:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:45:16 --> Controller Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:45:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:45:16 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:45:16 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:45:16 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:16 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:16 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Session Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Session Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:45:16 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:45:16 --> A session cookie was not found.
DEBUG - 2014-04-28 22:45:16 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:45:16 --> A session cookie was not found.
DEBUG - 2014-04-28 22:45:16 --> Session routines successfully run
DEBUG - 2014-04-28 22:45:16 --> Session routines successfully run
DEBUG - 2014-04-28 22:45:16 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:45:16 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:45:16 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:16 --> Final output sent to browser
DEBUG - 2014-04-28 22:45:16 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Total execution time: 0.0140
DEBUG - 2014-04-28 22:45:16 --> Final output sent to browser
DEBUG - 2014-04-28 22:45:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:16 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:45:16 --> Session Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:45:16 --> A session cookie was not found.
DEBUG - 2014-04-28 22:45:16 --> Session routines successfully run
DEBUG - 2014-04-28 22:45:16 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:45:16 --> Model Class Initialized
DEBUG - 2014-04-28 22:45:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:45:16 --> Final output sent to browser
DEBUG - 2014-04-28 22:45:16 --> Total execution time: 0.0170
DEBUG - 2014-04-28 22:46:20 --> Config Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:46:20 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:46:20 --> URI Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Router Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Output Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Security Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Input Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:46:20 --> Language Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Loader Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Controller Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:46:20 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:46:20 --> Model Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Model Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Config Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:46:20 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:46:20 --> URI Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Router Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Model Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:46:20 --> Output Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Security Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Session Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:46:20 --> Input Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Session routines successfully run
DEBUG - 2014-04-28 22:46:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:46:20 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:46:20 --> Language Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Model Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Loader Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:46:20 --> Controller Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:46:20 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:46:20 --> Final output sent to browser
DEBUG - 2014-04-28 22:46:20 --> Total execution time: 0.0200
DEBUG - 2014-04-28 22:46:20 --> Model Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Model Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Model Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:46:20 --> Session Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:46:20 --> Session routines successfully run
DEBUG - 2014-04-28 22:46:20 --> Config Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:46:20 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Model Class Initialized
DEBUG - 2014-04-28 22:46:20 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:46:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:46:20 --> URI Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Router Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Final output sent to browser
DEBUG - 2014-04-28 22:46:20 --> Total execution time: 0.0180
DEBUG - 2014-04-28 22:46:20 --> Output Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Security Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Input Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:46:20 --> Language Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Loader Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Controller Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:46:20 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:46:20 --> Model Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Model Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Model Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:46:20 --> Session Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:46:20 --> Session routines successfully run
DEBUG - 2014-04-28 22:46:20 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:46:20 --> Model Class Initialized
DEBUG - 2014-04-28 22:46:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:46:20 --> Final output sent to browser
DEBUG - 2014-04-28 22:46:20 --> Total execution time: 0.0150
DEBUG - 2014-04-28 22:47:34 --> Config Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Config Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:47:34 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:47:34 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:47:34 --> Config Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:47:34 --> URI Class Initialized
DEBUG - 2014-04-28 22:47:34 --> URI Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Router Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Router Class Initialized
DEBUG - 2014-04-28 22:47:34 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:47:34 --> URI Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Router Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Output Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Output Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Security Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Security Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Output Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Input Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Input Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Security Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:47:34 --> Input Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Language Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Language Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:47:34 --> Language Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Loader Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Loader Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Controller Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Loader Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Controller Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:47:34 --> Controller Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:47:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:47:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:47:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:47:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:47:34 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:47:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:47:34 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Session Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Session Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:47:34 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:47:34 --> A session cookie was not found.
DEBUG - 2014-04-28 22:47:34 --> A session cookie was not found.
DEBUG - 2014-04-28 22:47:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Session routines successfully run
DEBUG - 2014-04-28 22:47:34 --> Session routines successfully run
DEBUG - 2014-04-28 22:47:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:47:34 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:47:34 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:47:34 --> Session Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:34 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:47:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:47:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:47:34 --> A session cookie was not found.
DEBUG - 2014-04-28 22:47:34 --> Session routines successfully run
DEBUG - 2014-04-28 22:47:34 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:47:34 --> Final output sent to browser
DEBUG - 2014-04-28 22:47:34 --> Final output sent to browser
DEBUG - 2014-04-28 22:47:34 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:47:34 --> Total execution time: 0.0140
DEBUG - 2014-04-28 22:47:35 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:47:35 --> Final output sent to browser
DEBUG - 2014-04-28 22:47:35 --> Total execution time: 0.0170
DEBUG - 2014-04-28 22:47:36 --> Config Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Config Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Config Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:47:36 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:47:36 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:47:36 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:47:36 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:47:36 --> URI Class Initialized
DEBUG - 2014-04-28 22:47:36 --> URI Class Initialized
DEBUG - 2014-04-28 22:47:36 --> URI Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Router Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Router Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Router Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Output Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Output Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Security Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Security Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Input Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Input Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Output Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:47:36 --> Security Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Language Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Language Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Input Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:47:36 --> Loader Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Loader Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Language Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Controller Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Controller Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Loader Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:47:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:47:36 --> Controller Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:47:36 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:47:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:47:36 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:47:36 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:47:36 --> Session Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:47:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:47:36 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:36 --> A session cookie was not found.
DEBUG - 2014-04-28 22:47:36 --> Session Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:47:36 --> Session routines successfully run
DEBUG - 2014-04-28 22:47:36 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:47:36 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:47:36 --> Session Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:47:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:47:36 --> A session cookie was not found.
DEBUG - 2014-04-28 22:47:36 --> Session routines successfully run
DEBUG - 2014-04-28 22:47:36 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:47:36 --> Final output sent to browser
DEBUG - 2014-04-28 22:47:36 --> Total execution time: 0.0140
DEBUG - 2014-04-28 22:47:36 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:36 --> A session cookie was not found.
DEBUG - 2014-04-28 22:47:36 --> Session routines successfully run
DEBUG - 2014-04-28 22:47:36 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:47:36 --> Model Class Initialized
DEBUG - 2014-04-28 22:47:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:47:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:47:36 --> Final output sent to browser
DEBUG - 2014-04-28 22:47:36 --> Total execution time: 0.0170
DEBUG - 2014-04-28 22:47:36 --> Final output sent to browser
DEBUG - 2014-04-28 22:47:36 --> Total execution time: 0.0190
DEBUG - 2014-04-28 22:48:01 --> Config Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Config Class Initialized
DEBUG - 2014-04-28 22:48:01 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:48:01 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:48:01 --> URI Class Initialized
DEBUG - 2014-04-28 22:48:01 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:48:01 --> Router Class Initialized
DEBUG - 2014-04-28 22:48:01 --> URI Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Router Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Output Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Output Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Security Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Security Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Input Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Input Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:48:01 --> Language Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Language Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Loader Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Loader Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Controller Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Controller Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:48:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:48:01 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:48:01 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:48:01 --> Model Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Model Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Model Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Model Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Model Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Model Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:48:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:48:01 --> Session Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Session Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:48:01 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:48:01 --> Session routines successfully run
DEBUG - 2014-04-28 22:48:01 --> Session routines successfully run
DEBUG - 2014-04-28 22:48:01 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:48:01 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:48:01 --> Model Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Model Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:48:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:48:01 --> Final output sent to browser
DEBUG - 2014-04-28 22:48:01 --> Final output sent to browser
DEBUG - 2014-04-28 22:48:01 --> Total execution time: 0.0180
DEBUG - 2014-04-28 22:48:01 --> Total execution time: 0.0200
DEBUG - 2014-04-28 22:48:01 --> Config Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:48:01 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:48:01 --> URI Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Router Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Output Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Security Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Input Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:48:01 --> Language Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Loader Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Controller Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:48:01 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:48:01 --> Model Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Model Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Model Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:48:01 --> Session Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:48:01 --> Session routines successfully run
DEBUG - 2014-04-28 22:48:01 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:48:01 --> Model Class Initialized
DEBUG - 2014-04-28 22:48:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:48:01 --> Final output sent to browser
DEBUG - 2014-04-28 22:48:01 --> Total execution time: 0.0090
DEBUG - 2014-04-28 22:49:25 --> Config Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Config Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:49:25 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:49:25 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:49:25 --> URI Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Config Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Router Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:49:25 --> URI Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Router Class Initialized
DEBUG - 2014-04-28 22:49:25 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:49:25 --> Output Class Initialized
DEBUG - 2014-04-28 22:49:25 --> URI Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Output Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Router Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Security Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Security Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Input Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Output Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Input Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:49:25 --> Security Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Language Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Language Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Input Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:49:25 --> Language Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Loader Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Controller Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Loader Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Loader Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Controller Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Controller Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:49:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:49:25 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:49:25 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:49:25 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:49:25 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:49:25 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:49:25 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Session Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:49:25 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:49:25 --> A session cookie was not found.
DEBUG - 2014-04-28 22:49:25 --> Session Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Session routines successfully run
DEBUG - 2014-04-28 22:49:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:49:25 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:49:25 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:49:25 --> Session Class Initialized
DEBUG - 2014-04-28 22:49:25 --> A session cookie was not found.
DEBUG - 2014-04-28 22:49:25 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:49:25 --> Session routines successfully run
DEBUG - 2014-04-28 22:49:25 --> A session cookie was not found.
DEBUG - 2014-04-28 22:49:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:49:25 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:49:25 --> Session routines successfully run
DEBUG - 2014-04-28 22:49:25 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:49:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:49:25 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:49:25 --> Final output sent to browser
DEBUG - 2014-04-28 22:49:25 --> Final output sent to browser
DEBUG - 2014-04-28 22:49:25 --> Total execution time: 0.0170
DEBUG - 2014-04-28 22:49:25 --> Total execution time: 0.0160
DEBUG - 2014-04-28 22:49:25 --> Final output sent to browser
DEBUG - 2014-04-28 22:49:25 --> Total execution time: 0.0190
DEBUG - 2014-04-28 22:49:27 --> Config Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Config Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Config Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:49:27 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:49:27 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:49:27 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:49:27 --> URI Class Initialized
DEBUG - 2014-04-28 22:49:27 --> URI Class Initialized
DEBUG - 2014-04-28 22:49:27 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:49:27 --> Router Class Initialized
DEBUG - 2014-04-28 22:49:27 --> URI Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Router Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Router Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Output Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Output Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Security Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Output Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Security Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Input Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Security Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:49:27 --> Input Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Input Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:49:27 --> Language Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:49:27 --> Language Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Language Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Loader Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Loader Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Controller Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Controller Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Loader Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:49:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:49:27 --> Controller Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:49:27 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:49:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:49:27 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:49:27 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:49:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:49:27 --> Session Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Session Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:49:27 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:49:27 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:49:27 --> A session cookie was not found.
DEBUG - 2014-04-28 22:49:27 --> A session cookie was not found.
DEBUG - 2014-04-28 22:49:27 --> Session Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Session routines successfully run
DEBUG - 2014-04-28 22:49:27 --> Session routines successfully run
DEBUG - 2014-04-28 22:49:27 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:49:27 --> A session cookie was not found.
DEBUG - 2014-04-28 22:49:27 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:49:27 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:49:27 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Session routines successfully run
DEBUG - 2014-04-28 22:49:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:49:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:49:27 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:49:27 --> Model Class Initialized
DEBUG - 2014-04-28 22:49:27 --> Final output sent to browser
DEBUG - 2014-04-28 22:49:27 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:49:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:49:27 --> Final output sent to browser
DEBUG - 2014-04-28 22:49:27 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:49:27 --> Final output sent to browser
DEBUG - 2014-04-28 22:49:27 --> Total execution time: 0.0150
DEBUG - 2014-04-28 22:50:02 --> Config Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:50:02 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:50:02 --> URI Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Router Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Output Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Security Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Input Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:50:02 --> Language Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Loader Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Controller Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:50:02 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:50:02 --> Model Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Model Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Model Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:50:02 --> Session Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:50:02 --> Session routines successfully run
DEBUG - 2014-04-28 22:50:02 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:50:02 --> Model Class Initialized
DEBUG - 2014-04-28 22:50:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:50:02 --> Final output sent to browser
DEBUG - 2014-04-28 22:50:02 --> Total execution time: 0.0200
DEBUG - 2014-04-28 22:50:05 --> Config Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:50:05 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:50:05 --> URI Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Router Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Output Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Security Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Input Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:50:05 --> Language Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Loader Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Controller Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:50:05 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:50:05 --> Model Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Model Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Model Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:50:05 --> Session Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:50:05 --> Session routines successfully run
DEBUG - 2014-04-28 22:50:05 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:50:05 --> Model Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:50:05 --> Final output sent to browser
DEBUG - 2014-04-28 22:50:05 --> Total execution time: 0.0200
DEBUG - 2014-04-28 22:50:05 --> Config Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:50:05 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:50:05 --> URI Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Router Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Output Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Security Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Input Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:50:05 --> Language Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Loader Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Controller Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:50:05 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:50:05 --> Model Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Model Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Model Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:50:05 --> Session Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:50:05 --> Session routines successfully run
DEBUG - 2014-04-28 22:50:05 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:50:05 --> Model Class Initialized
DEBUG - 2014-04-28 22:50:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:50:05 --> Final output sent to browser
DEBUG - 2014-04-28 22:50:05 --> Total execution time: 0.0180
DEBUG - 2014-04-28 22:52:58 --> Config Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:52:58 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:52:58 --> URI Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Router Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Output Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Security Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Input Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:52:58 --> Language Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Loader Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Controller Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:52:58 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:52:58 --> Config Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Model Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Model Class Initialized
DEBUG - 2014-04-28 22:52:58 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:52:58 --> URI Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Router Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Output Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Security Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Model Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:52:58 --> Input Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:52:58 --> Session Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Language Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:52:58 --> Session routines successfully run
DEBUG - 2014-04-28 22:52:58 --> Loader Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:52:58 --> Controller Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:52:58 --> Model Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:52:58 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:52:58 --> Model Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Model Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Final output sent to browser
DEBUG - 2014-04-28 22:52:58 --> Total execution time: 0.0170
DEBUG - 2014-04-28 22:52:58 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Model Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:52:58 --> Session Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:52:58 --> Session routines successfully run
DEBUG - 2014-04-28 22:52:58 --> Config Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:52:58 --> Hooks Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Model Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Utf8 Class Initialized
DEBUG - 2014-04-28 22:52:58 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 22:52:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:52:58 --> URI Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Router Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Final output sent to browser
DEBUG - 2014-04-28 22:52:58 --> Total execution time: 0.0130
DEBUG - 2014-04-28 22:52:58 --> Output Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Security Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Input Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 22:52:58 --> Language Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Loader Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Controller Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 22:52:58 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 22:52:58 --> Model Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Model Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Database Driver Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Model Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:52:58 --> Session Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Helper loaded: string_helper
DEBUG - 2014-04-28 22:52:58 --> Session routines successfully run
DEBUG - 2014-04-28 22:52:58 --> Helper loaded: url_helper
DEBUG - 2014-04-28 22:52:58 --> Model Class Initialized
DEBUG - 2014-04-28 22:52:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 22:52:58 --> Final output sent to browser
DEBUG - 2014-04-28 22:52:58 --> Total execution time: 0.0110
DEBUG - 2014-04-28 23:17:04 --> Config Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Config Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Config Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:17:04 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:17:04 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:17:04 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:17:04 --> URI Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:17:04 --> URI Class Initialized
DEBUG - 2014-04-28 23:17:04 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:17:04 --> Router Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Router Class Initialized
DEBUG - 2014-04-28 23:17:04 --> URI Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Router Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Output Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Output Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Output Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Security Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Security Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Security Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Input Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Input Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Input Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:17:04 --> Language Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Language Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Language Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Loader Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Loader Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Loader Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Controller Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Controller Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Controller Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:17:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:17:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:17:04 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:17:04 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:17:04 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:17:04 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:17:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:17:04 --> Session Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Session Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:17:04 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:17:04 --> A session cookie was not found.
DEBUG - 2014-04-28 23:17:04 --> A session cookie was not found.
DEBUG - 2014-04-28 23:17:04 --> Session routines successfully run
DEBUG - 2014-04-28 23:17:04 --> Session routines successfully run
DEBUG - 2014-04-28 23:17:04 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:17:04 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:17:04 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:17:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:17:04 --> Final output sent to browser
DEBUG - 2014-04-28 23:17:04 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:17:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:17:04 --> Final output sent to browser
DEBUG - 2014-04-28 23:17:04 --> Total execution time: 0.0140
DEBUG - 2014-04-28 23:17:04 --> Session Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:17:04 --> A session cookie was not found.
DEBUG - 2014-04-28 23:17:04 --> Session routines successfully run
DEBUG - 2014-04-28 23:17:04 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:17:04 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:17:04 --> Final output sent to browser
DEBUG - 2014-04-28 23:17:04 --> Total execution time: 0.0170
DEBUG - 2014-04-28 23:17:06 --> Config Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Config Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Config Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:17:06 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:17:06 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:17:06 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:17:06 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:17:06 --> URI Class Initialized
DEBUG - 2014-04-28 23:17:06 --> URI Class Initialized
DEBUG - 2014-04-28 23:17:06 --> URI Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Router Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Router Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Output Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Output Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Security Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Router Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Input Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Security Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:17:06 --> Input Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Language Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Output Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Loader Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Security Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:17:06 --> Controller Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Input Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Language Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:17:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:17:06 --> Loader Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Language Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:17:06 --> Controller Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:17:06 --> Loader Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Controller Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:17:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:17:06 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:17:06 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:17:06 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Session Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:17:06 --> Session Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:17:06 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:17:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:17:06 --> A session cookie was not found.
DEBUG - 2014-04-28 23:17:06 --> A session cookie was not found.
DEBUG - 2014-04-28 23:17:06 --> Session routines successfully run
DEBUG - 2014-04-28 23:17:06 --> Session Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:17:06 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:17:06 --> Session routines successfully run
DEBUG - 2014-04-28 23:17:06 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:17:06 --> A session cookie was not found.
DEBUG - 2014-04-28 23:17:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:17:06 --> Session routines successfully run
DEBUG - 2014-04-28 23:17:06 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:17:06 --> Model Class Initialized
DEBUG - 2014-04-28 23:17:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:17:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:17:06 --> Final output sent to browser
DEBUG - 2014-04-28 23:17:06 --> Total execution time: 0.0190
DEBUG - 2014-04-28 23:17:06 --> Final output sent to browser
DEBUG - 2014-04-28 23:17:06 --> Total execution time: 0.0210
DEBUG - 2014-04-28 23:17:06 --> Final output sent to browser
DEBUG - 2014-04-28 23:17:06 --> Total execution time: 0.0230
DEBUG - 2014-04-28 23:20:07 --> Config Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Config Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:20:07 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:20:07 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:20:07 --> URI Class Initialized
DEBUG - 2014-04-28 23:20:07 --> URI Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Router Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Router Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Config Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Output Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Output Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Security Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Security Class Initialized
DEBUG - 2014-04-28 23:20:07 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:20:07 --> Input Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Input Class Initialized
DEBUG - 2014-04-28 23:20:07 --> URI Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:20:07 --> Router Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Language Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Language Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Output Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Loader Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Loader Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Security Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Controller Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Controller Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Input Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:20:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:20:07 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:20:07 --> Language Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:20:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Loader Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Controller Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:20:07 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:20:07 --> Session Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:20:07 --> A session cookie was not found.
DEBUG - 2014-04-28 23:20:07 --> Session routines successfully run
DEBUG - 2014-04-28 23:20:07 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:20:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:20:07 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:20:07 --> Final output sent to browser
DEBUG - 2014-04-28 23:20:07 --> Total execution time: 0.0140
DEBUG - 2014-04-28 23:20:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:20:07 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Session Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:20:07 --> A session cookie was not found.
DEBUG - 2014-04-28 23:20:07 --> Session routines successfully run
DEBUG - 2014-04-28 23:20:07 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:20:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:20:07 --> Final output sent to browser
DEBUG - 2014-04-28 23:20:07 --> Total execution time: 0.0200
DEBUG - 2014-04-28 23:20:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:20:07 --> Session Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:20:07 --> A session cookie was not found.
DEBUG - 2014-04-28 23:20:07 --> Session routines successfully run
DEBUG - 2014-04-28 23:20:07 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:20:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:20:07 --> Final output sent to browser
DEBUG - 2014-04-28 23:20:07 --> Total execution time: 0.0230
DEBUG - 2014-04-28 23:20:08 --> Config Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Config Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Config Class Initialized
DEBUG - 2014-04-28 23:20:08 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:20:08 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:20:08 --> URI Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:20:08 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:20:08 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:20:08 --> Router Class Initialized
DEBUG - 2014-04-28 23:20:08 --> URI Class Initialized
DEBUG - 2014-04-28 23:20:08 --> URI Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Router Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Router Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Output Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Output Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Security Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Output Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Security Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Input Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Security Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Input Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:20:08 --> Input Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:20:08 --> Language Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Language Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Language Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Loader Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Loader Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Loader Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Controller Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Controller Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Controller Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:20:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:20:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:20:08 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:20:08 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:20:08 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:20:08 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:20:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:20:08 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:20:08 --> Session Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Session Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:20:08 --> Session Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:20:08 --> A session cookie was not found.
DEBUG - 2014-04-28 23:20:08 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:20:08 --> A session cookie was not found.
DEBUG - 2014-04-28 23:20:08 --> Session routines successfully run
DEBUG - 2014-04-28 23:20:08 --> A session cookie was not found.
DEBUG - 2014-04-28 23:20:08 --> Session routines successfully run
DEBUG - 2014-04-28 23:20:08 --> Session routines successfully run
DEBUG - 2014-04-28 23:20:08 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:20:08 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:20:08 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:20:08 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:20:08 --> Model Class Initialized
DEBUG - 2014-04-28 23:20:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:20:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:20:08 --> Final output sent to browser
DEBUG - 2014-04-28 23:20:08 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:20:08 --> Final output sent to browser
DEBUG - 2014-04-28 23:20:08 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:20:08 --> Final output sent to browser
DEBUG - 2014-04-28 23:20:08 --> Total execution time: 0.0140
DEBUG - 2014-04-28 23:30:52 --> Config Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Config Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Config Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:30:52 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:30:52 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:30:52 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:30:52 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:30:52 --> URI Class Initialized
DEBUG - 2014-04-28 23:30:52 --> URI Class Initialized
DEBUG - 2014-04-28 23:30:52 --> URI Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Router Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Router Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Router Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Output Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Output Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Output Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Security Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Security Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Security Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Input Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Input Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Input Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:30:52 --> Language Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Language Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Language Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Loader Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Loader Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Loader Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Controller Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Controller Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Controller Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:30:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:30:52 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:30:52 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:30:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:30:52 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:30:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:30:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:30:52 --> Session Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Session Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:30:52 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:30:52 --> A session cookie was not found.
DEBUG - 2014-04-28 23:30:52 --> A session cookie was not found.
DEBUG - 2014-04-28 23:30:52 --> Session routines successfully run
DEBUG - 2014-04-28 23:30:52 --> Session routines successfully run
DEBUG - 2014-04-28 23:30:52 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:30:52 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:30:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:30:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:30:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:30:52 --> Session Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:30:52 --> A session cookie was not found.
DEBUG - 2014-04-28 23:30:52 --> Session routines successfully run
DEBUG - 2014-04-28 23:30:52 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:30:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:30:52 --> Final output sent to browser
DEBUG - 2014-04-28 23:30:52 --> Total execution time: 0.0190
DEBUG - 2014-04-28 23:30:52 --> Final output sent to browser
DEBUG - 2014-04-28 23:30:52 --> Total execution time: 0.0190
DEBUG - 2014-04-28 23:30:52 --> Final output sent to browser
DEBUG - 2014-04-28 23:30:52 --> Total execution time: 0.0210
DEBUG - 2014-04-28 23:30:53 --> Config Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:30:53 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:30:53 --> URI Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Router Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Config Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Config Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Output Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:30:53 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:30:53 --> Security Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:30:53 --> URI Class Initialized
DEBUG - 2014-04-28 23:30:53 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:30:53 --> Input Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Router Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:30:53 --> URI Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Language Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Router Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Output Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Loader Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Security Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Output Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Controller Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Input Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Security Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:30:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:30:53 --> Input Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Language Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:30:53 --> Loader Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Language Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Controller Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Loader Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:30:53 --> Controller Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:30:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:30:53 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:30:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:30:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Session Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:30:53 --> A session cookie was not found.
DEBUG - 2014-04-28 23:30:53 --> Session routines successfully run
DEBUG - 2014-04-28 23:30:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:30:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:30:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:30:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:30:53 --> Session Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Session Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:30:53 --> A session cookie was not found.
DEBUG - 2014-04-28 23:30:53 --> Final output sent to browser
DEBUG - 2014-04-28 23:30:53 --> Total execution time: 0.0120
DEBUG - 2014-04-28 23:30:53 --> Session routines successfully run
DEBUG - 2014-04-28 23:30:53 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:30:53 --> A session cookie was not found.
DEBUG - 2014-04-28 23:30:53 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:30:53 --> Session routines successfully run
DEBUG - 2014-04-28 23:30:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:30:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:30:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:30:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:30:53 --> Final output sent to browser
DEBUG - 2014-04-28 23:30:53 --> Total execution time: 0.0140
DEBUG - 2014-04-28 23:30:53 --> Final output sent to browser
DEBUG - 2014-04-28 23:30:53 --> Total execution time: 0.0140
DEBUG - 2014-04-28 23:31:41 --> Config Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Config Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:31:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:31:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:31:41 --> URI Class Initialized
DEBUG - 2014-04-28 23:31:41 --> URI Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Router Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Router Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Output Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Output Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Security Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Security Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Config Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Input Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Input Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:31:41 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:31:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:31:41 --> Language Class Initialized
DEBUG - 2014-04-28 23:31:41 --> URI Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Router Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Loader Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:31:41 --> Controller Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Output Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Language Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:31:41 --> Security Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Loader Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:31:41 --> Input Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Controller Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:31:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:31:41 --> Language Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:31:41 --> Loader Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Controller Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:31:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:31:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:31:41 --> Session Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:31:41 --> A session cookie was not found.
DEBUG - 2014-04-28 23:31:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:31:41 --> Session routines successfully run
DEBUG - 2014-04-28 23:31:41 --> Session Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:31:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:31:41 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:31:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:41 --> A session cookie was not found.
DEBUG - 2014-04-28 23:31:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:31:41 --> Session routines successfully run
DEBUG - 2014-04-28 23:31:41 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:31:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:31:41 --> Final output sent to browser
DEBUG - 2014-04-28 23:31:41 --> Final output sent to browser
DEBUG - 2014-04-28 23:31:41 --> Total execution time: 0.0140
DEBUG - 2014-04-28 23:31:41 --> Total execution time: 0.0140
DEBUG - 2014-04-28 23:31:41 --> Session Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:31:41 --> A session cookie was not found.
DEBUG - 2014-04-28 23:31:41 --> Session routines successfully run
DEBUG - 2014-04-28 23:31:41 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:31:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:31:41 --> Final output sent to browser
DEBUG - 2014-04-28 23:31:41 --> Total execution time: 0.0160
DEBUG - 2014-04-28 23:31:43 --> Config Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Config Class Initialized
DEBUG - 2014-04-28 23:31:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:31:43 --> Config Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:31:43 --> URI Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Router Class Initialized
DEBUG - 2014-04-28 23:31:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:31:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:31:43 --> URI Class Initialized
DEBUG - 2014-04-28 23:31:43 --> URI Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Output Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Router Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Router Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Security Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Input Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Output Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Output Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:31:43 --> Security Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Security Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Language Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Input Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Input Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:31:43 --> Loader Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:31:43 --> Language Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Controller Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Language Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:31:43 --> Loader Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Controller Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Loader Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:31:43 --> Controller Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:31:43 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:31:43 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:31:43 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:31:43 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:31:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:31:43 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Session Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Session Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:31:43 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:31:43 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:31:43 --> A session cookie was not found.
DEBUG - 2014-04-28 23:31:43 --> A session cookie was not found.
DEBUG - 2014-04-28 23:31:43 --> Session Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Session routines successfully run
DEBUG - 2014-04-28 23:31:43 --> Session routines successfully run
DEBUG - 2014-04-28 23:31:43 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:31:43 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:31:43 --> A session cookie was not found.
DEBUG - 2014-04-28 23:31:43 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:31:43 --> Session routines successfully run
DEBUG - 2014-04-28 23:31:43 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:31:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:31:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:31:43 --> Model Class Initialized
DEBUG - 2014-04-28 23:31:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:31:43 --> Final output sent to browser
DEBUG - 2014-04-28 23:31:43 --> Final output sent to browser
DEBUG - 2014-04-28 23:31:43 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:31:43 --> Final output sent to browser
DEBUG - 2014-04-28 23:31:43 --> Total execution time: 0.0120
DEBUG - 2014-04-28 23:31:43 --> Total execution time: 0.0120
DEBUG - 2014-04-28 23:32:00 --> Config Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Config Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:32:00 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:32:00 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Config Class Initialized
DEBUG - 2014-04-28 23:32:00 --> URI Class Initialized
DEBUG - 2014-04-28 23:32:00 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:32:00 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:32:00 --> URI Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Router Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:32:00 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:32:00 --> Router Class Initialized
DEBUG - 2014-04-28 23:32:00 --> URI Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Output Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Router Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Output Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Security Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Security Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Output Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Input Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Input Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:32:00 --> Security Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Language Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Input Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Language Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:32:00 --> Language Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Loader Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Loader Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Controller Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Controller Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Loader Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:32:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:32:00 --> Controller Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:32:00 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:32:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:32:00 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:32:00 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:32:00 --> Session Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:32:00 --> A session cookie was not found.
DEBUG - 2014-04-28 23:32:00 --> Session routines successfully run
DEBUG - 2014-04-28 23:32:00 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:32:00 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:32:00 --> Final output sent to browser
DEBUG - 2014-04-28 23:32:00 --> Total execution time: 0.0110
DEBUG - 2014-04-28 23:32:00 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:32:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:32:00 --> Session Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Session Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:32:00 --> A session cookie was not found.
DEBUG - 2014-04-28 23:32:00 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:32:00 --> Session routines successfully run
DEBUG - 2014-04-28 23:32:00 --> A session cookie was not found.
DEBUG - 2014-04-28 23:32:00 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:32:00 --> Session routines successfully run
DEBUG - 2014-04-28 23:32:00 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:32:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:32:00 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:32:00 --> Final output sent to browser
DEBUG - 2014-04-28 23:32:00 --> Total execution time: 0.0170
DEBUG - 2014-04-28 23:32:00 --> Final output sent to browser
DEBUG - 2014-04-28 23:32:00 --> Total execution time: 0.0190
DEBUG - 2014-04-28 23:32:02 --> Config Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Config Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Config Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:32:02 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:32:02 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:32:02 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:32:02 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:32:02 --> URI Class Initialized
DEBUG - 2014-04-28 23:32:02 --> URI Class Initialized
DEBUG - 2014-04-28 23:32:02 --> URI Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Router Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Router Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Router Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Output Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Output Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Output Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Security Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Security Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Security Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Input Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Input Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Input Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:32:02 --> Language Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Language Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:32:02 --> Language Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Loader Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Loader Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Controller Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Controller Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Loader Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:32:02 --> Controller Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:32:02 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:32:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:32:02 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:32:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:32:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:32:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:32:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:32:02 --> Session Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Session Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:32:02 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:32:02 --> Session Class Initialized
DEBUG - 2014-04-28 23:32:02 --> A session cookie was not found.
DEBUG - 2014-04-28 23:32:02 --> A session cookie was not found.
DEBUG - 2014-04-28 23:32:02 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:32:02 --> Session routines successfully run
DEBUG - 2014-04-28 23:32:02 --> Session routines successfully run
DEBUG - 2014-04-28 23:32:02 --> A session cookie was not found.
DEBUG - 2014-04-28 23:32:02 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:32:02 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:32:02 --> Session routines successfully run
DEBUG - 2014-04-28 23:32:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:32:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:32:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:32:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:32:02 --> Final output sent to browser
DEBUG - 2014-04-28 23:32:02 --> Final output sent to browser
DEBUG - 2014-04-28 23:32:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:32:02 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:32:02 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:32:02 --> Final output sent to browser
DEBUG - 2014-04-28 23:32:02 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:34:27 --> Config Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Config Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Config Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:34:27 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:34:27 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:34:27 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:34:27 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:34:27 --> URI Class Initialized
DEBUG - 2014-04-28 23:34:27 --> URI Class Initialized
DEBUG - 2014-04-28 23:34:27 --> URI Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Router Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Router Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Router Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Output Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Output Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Output Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Security Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Security Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Security Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Input Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Input Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Input Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:34:27 --> Language Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Language Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Language Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Loader Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Loader Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Loader Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Controller Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Controller Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Controller Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:34:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:34:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:34:27 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:34:27 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:34:27 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:34:27 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:34:27 --> Session Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:34:27 --> A session cookie was not found.
DEBUG - 2014-04-28 23:34:27 --> Session routines successfully run
DEBUG - 2014-04-28 23:34:27 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:34:27 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:34:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:34:27 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Session Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:34:27 --> Final output sent to browser
DEBUG - 2014-04-28 23:34:27 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:34:27 --> Total execution time: 0.0140
DEBUG - 2014-04-28 23:34:27 --> A session cookie was not found.
DEBUG - 2014-04-28 23:34:27 --> Session Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Session routines successfully run
DEBUG - 2014-04-28 23:34:27 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:34:27 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:34:27 --> A session cookie was not found.
DEBUG - 2014-04-28 23:34:27 --> Session routines successfully run
DEBUG - 2014-04-28 23:34:27 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:34:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:34:27 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:34:27 --> Final output sent to browser
DEBUG - 2014-04-28 23:34:27 --> Total execution time: 0.0170
DEBUG - 2014-04-28 23:34:27 --> Final output sent to browser
DEBUG - 2014-04-28 23:34:27 --> Total execution time: 0.0170
DEBUG - 2014-04-28 23:34:29 --> Config Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Config Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:34:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:34:29 --> URI Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Router Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Output Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Security Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Config Class Initialized
DEBUG - 2014-04-28 23:34:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:34:29 --> Input Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:34:29 --> URI Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:34:29 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Router Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Language Class Initialized
DEBUG - 2014-04-28 23:34:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:34:29 --> URI Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Loader Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Output Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Router Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Controller Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Security Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:34:29 --> Input Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:34:29 --> Output Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:34:29 --> Language Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Security Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Input Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Loader Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:34:29 --> Controller Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Language Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:34:29 --> Loader Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:34:29 --> Controller Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:34:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:34:29 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:34:29 --> Session Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:34:29 --> A session cookie was not found.
DEBUG - 2014-04-28 23:34:29 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Session routines successfully run
DEBUG - 2014-04-28 23:34:29 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:34:29 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:34:29 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Session Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:34:29 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:34:29 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:29 --> A session cookie was not found.
DEBUG - 2014-04-28 23:34:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:34:29 --> Session routines successfully run
DEBUG - 2014-04-28 23:34:29 --> Final output sent to browser
DEBUG - 2014-04-28 23:34:29 --> Session Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Total execution time: 0.0120
DEBUG - 2014-04-28 23:34:29 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:34:29 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:34:29 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:29 --> A session cookie was not found.
DEBUG - 2014-04-28 23:34:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:34:29 --> Session routines successfully run
DEBUG - 2014-04-28 23:34:29 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:34:29 --> Model Class Initialized
DEBUG - 2014-04-28 23:34:29 --> Final output sent to browser
DEBUG - 2014-04-28 23:34:29 --> Total execution time: 0.0140
DEBUG - 2014-04-28 23:34:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:34:29 --> Final output sent to browser
DEBUG - 2014-04-28 23:34:29 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:36:56 --> Config Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Config Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Config Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:36:56 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:36:56 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:36:56 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:36:56 --> URI Class Initialized
DEBUG - 2014-04-28 23:36:56 --> URI Class Initialized
DEBUG - 2014-04-28 23:36:56 --> URI Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Router Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Router Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Router Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Output Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Output Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Output Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Security Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Security Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Security Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Input Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Input Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Input Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:36:56 --> Language Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Language Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Language Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Loader Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Loader Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Loader Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Controller Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Controller Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Controller Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:36:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:36:56 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:36:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:36:56 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:36:56 --> Model Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Model Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Model Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:36:56 --> Model Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Model Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Model Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Model Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Model Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Model Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:36:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:36:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:36:56 --> Session Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Session Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Session Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:36:56 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:36:56 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:36:56 --> A session cookie was not found.
DEBUG - 2014-04-28 23:36:56 --> A session cookie was not found.
DEBUG - 2014-04-28 23:36:56 --> A session cookie was not found.
DEBUG - 2014-04-28 23:36:56 --> Session routines successfully run
DEBUG - 2014-04-28 23:36:56 --> Session routines successfully run
DEBUG - 2014-04-28 23:36:56 --> Session routines successfully run
DEBUG - 2014-04-28 23:36:56 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:36:56 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:36:56 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:36:56 --> Model Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Model Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:36:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:36:56 --> Model Class Initialized
DEBUG - 2014-04-28 23:36:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:36:56 --> Final output sent to browser
DEBUG - 2014-04-28 23:36:56 --> Total execution time: 0.0160
DEBUG - 2014-04-28 23:36:56 --> Final output sent to browser
DEBUG - 2014-04-28 23:36:56 --> Total execution time: 0.0160
DEBUG - 2014-04-28 23:36:56 --> Final output sent to browser
DEBUG - 2014-04-28 23:36:56 --> Total execution time: 0.0170
DEBUG - 2014-04-28 23:37:01 --> Config Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Config Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Config Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:37:01 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:37:01 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:37:01 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:37:01 --> URI Class Initialized
DEBUG - 2014-04-28 23:37:01 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:37:01 --> URI Class Initialized
DEBUG - 2014-04-28 23:37:01 --> URI Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Router Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Router Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Router Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Output Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Output Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Output Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Security Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Security Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Security Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Input Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Input Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Input Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:37:01 --> Language Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Language Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Language Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Loader Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Loader Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Loader Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Controller Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Controller Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:37:01 --> Controller Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:37:01 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:37:01 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:37:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:37:01 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:37:01 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:01 --> Session Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:01 --> Session Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:37:01 --> Session Class Initialized
DEBUG - 2014-04-28 23:37:01 --> A session cookie was not found.
DEBUG - 2014-04-28 23:37:01 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:37:01 --> Session routines successfully run
DEBUG - 2014-04-28 23:37:01 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:37:01 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:37:01 --> A session cookie was not found.
DEBUG - 2014-04-28 23:37:01 --> Session routines successfully run
DEBUG - 2014-04-28 23:37:01 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:01 --> A session cookie was not found.
DEBUG - 2014-04-28 23:37:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:01 --> Session routines successfully run
DEBUG - 2014-04-28 23:37:01 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:37:01 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:37:01 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:01 --> Final output sent to browser
DEBUG - 2014-04-28 23:37:01 --> Total execution time: 0.0150
DEBUG - 2014-04-28 23:37:01 --> Final output sent to browser
DEBUG - 2014-04-28 23:37:01 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:01 --> Total execution time: 0.0150
DEBUG - 2014-04-28 23:37:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:01 --> Final output sent to browser
DEBUG - 2014-04-28 23:37:01 --> Total execution time: 0.0160
DEBUG - 2014-04-28 23:37:02 --> Config Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Config Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Config Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:37:02 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:37:02 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:37:02 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:37:02 --> URI Class Initialized
DEBUG - 2014-04-28 23:37:02 --> URI Class Initialized
DEBUG - 2014-04-28 23:37:02 --> URI Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Router Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Router Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Router Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Output Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Output Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Output Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Security Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Security Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Security Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Input Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Input Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Input Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:37:02 --> Language Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Language Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Language Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Loader Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Loader Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Loader Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Controller Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Controller Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Controller Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:37:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:37:02 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:37:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:37:02 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:37:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:37:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:02 --> Session Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:02 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:37:02 --> Session Class Initialized
DEBUG - 2014-04-28 23:37:02 --> A session cookie was not found.
DEBUG - 2014-04-28 23:37:02 --> Session Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Session routines successfully run
DEBUG - 2014-04-28 23:37:02 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:37:02 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:37:02 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:37:02 --> A session cookie was not found.
DEBUG - 2014-04-28 23:37:02 --> A session cookie was not found.
DEBUG - 2014-04-28 23:37:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Session routines successfully run
DEBUG - 2014-04-28 23:37:02 --> Session routines successfully run
DEBUG - 2014-04-28 23:37:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:02 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:37:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:02 --> Final output sent to browser
DEBUG - 2014-04-28 23:37:02 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:37:02 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:37:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:02 --> Final output sent to browser
DEBUG - 2014-04-28 23:37:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:02 --> Total execution time: 0.0140
DEBUG - 2014-04-28 23:37:02 --> Final output sent to browser
DEBUG - 2014-04-28 23:37:02 --> Total execution time: 0.0150
DEBUG - 2014-04-28 23:37:35 --> Config Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Config Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Config Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:37:35 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:37:35 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:37:35 --> URI Class Initialized
DEBUG - 2014-04-28 23:37:35 --> URI Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Router Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Router Class Initialized
DEBUG - 2014-04-28 23:37:35 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:37:35 --> URI Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Output Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Router Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Output Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Security Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Security Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Output Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Input Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Input Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Security Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:37:35 --> Input Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Language Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:37:35 --> Language Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Language Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Loader Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Loader Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Controller Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Loader Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Controller Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Controller Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:37:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:37:35 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:37:35 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:37:35 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:37:35 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:37:35 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:35 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:35 --> Session Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:37:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:35 --> Session Class Initialized
DEBUG - 2014-04-28 23:37:35 --> A session cookie was not found.
DEBUG - 2014-04-28 23:37:35 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:37:35 --> Session routines successfully run
DEBUG - 2014-04-28 23:37:35 --> Session Class Initialized
DEBUG - 2014-04-28 23:37:35 --> A session cookie was not found.
DEBUG - 2014-04-28 23:37:35 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:37:35 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:37:35 --> Session routines successfully run
DEBUG - 2014-04-28 23:37:35 --> A session cookie was not found.
DEBUG - 2014-04-28 23:37:35 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:37:35 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Session routines successfully run
DEBUG - 2014-04-28 23:37:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:35 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:37:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:35 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:35 --> Final output sent to browser
DEBUG - 2014-04-28 23:37:35 --> Total execution time: 0.0150
DEBUG - 2014-04-28 23:37:35 --> Final output sent to browser
DEBUG - 2014-04-28 23:37:35 --> Total execution time: 0.0150
DEBUG - 2014-04-28 23:37:35 --> Final output sent to browser
DEBUG - 2014-04-28 23:37:35 --> Total execution time: 0.0150
DEBUG - 2014-04-28 23:37:41 --> Config Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Config Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:37:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:37:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:37:41 --> URI Class Initialized
DEBUG - 2014-04-28 23:37:41 --> URI Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Router Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Router Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Config Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Output Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Output Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Security Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Security Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:37:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:37:41 --> Input Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:37:41 --> URI Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Input Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Router Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Language Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:37:41 --> Language Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Output Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Loader Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Loader Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Controller Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Security Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Controller Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Input Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:37:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:37:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:37:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:37:41 --> Language Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Loader Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Controller Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:37:41 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:37:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:41 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:41 --> Session Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Session Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:37:41 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:37:41 --> A session cookie was not found.
DEBUG - 2014-04-28 23:37:41 --> A session cookie was not found.
DEBUG - 2014-04-28 23:37:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:41 --> Session routines successfully run
DEBUG - 2014-04-28 23:37:41 --> Session routines successfully run
DEBUG - 2014-04-28 23:37:41 --> Session Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:37:41 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:37:41 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:37:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:41 --> A session cookie was not found.
DEBUG - 2014-04-28 23:37:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:41 --> Session routines successfully run
DEBUG - 2014-04-28 23:37:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:41 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:37:41 --> Model Class Initialized
DEBUG - 2014-04-28 23:37:41 --> Final output sent to browser
DEBUG - 2014-04-28 23:37:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:37:41 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:37:41 --> Final output sent to browser
DEBUG - 2014-04-28 23:37:41 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:37:41 --> Final output sent to browser
DEBUG - 2014-04-28 23:37:41 --> Total execution time: 0.0110
DEBUG - 2014-04-28 23:39:03 --> Config Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Config Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Config Class Initialized
DEBUG - 2014-04-28 23:39:03 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:39:03 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:39:03 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:39:03 --> URI Class Initialized
DEBUG - 2014-04-28 23:39:03 --> URI Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Router Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Router Class Initialized
DEBUG - 2014-04-28 23:39:03 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:39:03 --> URI Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Output Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Output Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Router Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Security Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Security Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Output Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Input Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Input Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:39:03 --> Security Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Language Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Language Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Input Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:39:03 --> Language Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Loader Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Loader Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Controller Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Controller Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Loader Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:39:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:39:03 --> Controller Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:39:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:39:03 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:39:03 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:39:03 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:39:03 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:39:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:39:03 --> Session Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Session Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:39:03 --> A session cookie was not found.
DEBUG - 2014-04-28 23:39:03 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:39:03 --> Session Class Initialized
DEBUG - 2014-04-28 23:39:03 --> A session cookie was not found.
DEBUG - 2014-04-28 23:39:03 --> Session routines successfully run
DEBUG - 2014-04-28 23:39:03 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:39:03 --> Session routines successfully run
DEBUG - 2014-04-28 23:39:03 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:39:03 --> A session cookie was not found.
DEBUG - 2014-04-28 23:39:03 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:39:03 --> Session routines successfully run
DEBUG - 2014-04-28 23:39:03 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:39:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:39:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:39:03 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:39:03 --> Final output sent to browser
DEBUG - 2014-04-28 23:39:03 --> Total execution time: 0.0140
DEBUG - 2014-04-28 23:39:03 --> Final output sent to browser
DEBUG - 2014-04-28 23:39:03 --> Total execution time: 0.0140
DEBUG - 2014-04-28 23:39:03 --> Final output sent to browser
DEBUG - 2014-04-28 23:39:03 --> Total execution time: 0.0150
DEBUG - 2014-04-28 23:39:11 --> Config Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:39:11 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:39:11 --> URI Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Router Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Output Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Security Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Input Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:39:11 --> Language Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Loader Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Controller Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:39:11 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:39:11 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:39:11 --> Session Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:39:11 --> Session routines successfully run
DEBUG - 2014-04-28 23:39:11 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:39:11 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:39:11 --> Final output sent to browser
DEBUG - 2014-04-28 23:39:11 --> Total execution time: 0.0190
DEBUG - 2014-04-28 23:39:11 --> Config Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:39:11 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:39:11 --> URI Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Router Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Output Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Security Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Input Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:39:11 --> Language Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Loader Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Controller Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:39:11 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:39:11 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:39:11 --> Session Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:39:11 --> Session routines successfully run
DEBUG - 2014-04-28 23:39:11 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:39:11 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:39:11 --> Final output sent to browser
DEBUG - 2014-04-28 23:39:11 --> Total execution time: 0.0200
DEBUG - 2014-04-28 23:39:11 --> Config Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:39:11 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:39:11 --> URI Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Router Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Output Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Security Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Input Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:39:11 --> Language Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Loader Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Controller Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:39:11 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:39:11 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:39:11 --> Session Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:39:11 --> Session routines successfully run
DEBUG - 2014-04-28 23:39:11 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:39:11 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:39:11 --> Final output sent to browser
DEBUG - 2014-04-28 23:39:11 --> Total execution time: 0.0110
DEBUG - 2014-04-28 23:39:12 --> Config Class Initialized
DEBUG - 2014-04-28 23:39:12 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:39:12 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:39:12 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:39:12 --> URI Class Initialized
DEBUG - 2014-04-28 23:39:12 --> Router Class Initialized
DEBUG - 2014-04-28 23:39:12 --> Output Class Initialized
DEBUG - 2014-04-28 23:39:12 --> Security Class Initialized
DEBUG - 2014-04-28 23:39:12 --> Input Class Initialized
DEBUG - 2014-04-28 23:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:39:12 --> Language Class Initialized
DEBUG - 2014-04-28 23:39:12 --> Loader Class Initialized
DEBUG - 2014-04-28 23:39:12 --> Controller Class Initialized
DEBUG - 2014-04-28 23:39:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:39:12 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:39:12 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:12 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:12 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:39:12 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:39:14 --> Final output sent to browser
DEBUG - 2014-04-28 23:39:14 --> Total execution time: 1.8841
DEBUG - 2014-04-28 23:39:51 --> Config Class Initialized
DEBUG - 2014-04-28 23:39:51 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:39:51 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:39:51 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:39:51 --> URI Class Initialized
DEBUG - 2014-04-28 23:39:51 --> Router Class Initialized
DEBUG - 2014-04-28 23:39:51 --> Output Class Initialized
DEBUG - 2014-04-28 23:39:51 --> Security Class Initialized
DEBUG - 2014-04-28 23:39:51 --> Input Class Initialized
DEBUG - 2014-04-28 23:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:39:51 --> Language Class Initialized
DEBUG - 2014-04-28 23:39:51 --> Loader Class Initialized
DEBUG - 2014-04-28 23:39:51 --> Controller Class Initialized
DEBUG - 2014-04-28 23:39:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:39:51 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:39:51 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:51 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:51 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:39:51 --> Model Class Initialized
DEBUG - 2014-04-28 23:39:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:39:52 --> Final output sent to browser
DEBUG - 2014-04-28 23:39:52 --> Total execution time: 0.9061
DEBUG - 2014-04-28 23:48:37 --> Config Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Config Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Config Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:48:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:48:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:48:37 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:48:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:48:37 --> URI Class Initialized
DEBUG - 2014-04-28 23:48:37 --> URI Class Initialized
DEBUG - 2014-04-28 23:48:37 --> URI Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Router Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Router Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Router Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Output Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Output Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Output Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Security Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Security Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Security Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Input Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Input Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Input Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:48:37 --> Language Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Language Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Language Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Loader Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Loader Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Loader Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Controller Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Controller Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Controller Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:48:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:48:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:48:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:48:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:48:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:48:37 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:48:37 --> Session Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:48:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:48:37 --> A session cookie was not found.
DEBUG - 2014-04-28 23:48:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:48:37 --> Session routines successfully run
DEBUG - 2014-04-28 23:48:37 --> Session Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:48:37 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:48:37 --> Session Class Initialized
DEBUG - 2014-04-28 23:48:37 --> A session cookie was not found.
DEBUG - 2014-04-28 23:48:37 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:48:37 --> Session routines successfully run
DEBUG - 2014-04-28 23:48:37 --> A session cookie was not found.
DEBUG - 2014-04-28 23:48:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:48:37 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:48:37 --> Session routines successfully run
DEBUG - 2014-04-28 23:48:37 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:48:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:48:37 --> Final output sent to browser
DEBUG - 2014-04-28 23:48:37 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:37 --> Total execution time: 0.0150
DEBUG - 2014-04-28 23:48:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:48:37 --> Final output sent to browser
DEBUG - 2014-04-28 23:48:37 --> Total execution time: 0.0150
DEBUG - 2014-04-28 23:48:37 --> Final output sent to browser
DEBUG - 2014-04-28 23:48:37 --> Total execution time: 0.0160
DEBUG - 2014-04-28 23:48:38 --> Config Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Config Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Config Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:48:38 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:48:38 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:48:38 --> URI Class Initialized
DEBUG - 2014-04-28 23:48:38 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:48:38 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Router Class Initialized
DEBUG - 2014-04-28 23:48:38 --> URI Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Router Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Output Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Output Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Security Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Security Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Input Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:48:38 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:48:38 --> Input Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Language Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:48:38 --> URI Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Language Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Loader Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Router Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Controller Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:48:38 --> Output Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Loader Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:48:38 --> Security Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Controller Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Input Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:48:38 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:48:38 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:48:38 --> Language Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Loader Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Controller Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:48:38 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:48:38 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:48:38 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Session Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:48:38 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:48:38 --> A session cookie was not found.
DEBUG - 2014-04-28 23:48:38 --> Session Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Session routines successfully run
DEBUG - 2014-04-28 23:48:38 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:48:38 --> A session cookie was not found.
DEBUG - 2014-04-28 23:48:38 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:48:38 --> Session routines successfully run
DEBUG - 2014-04-28 23:48:38 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:48:38 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:48:38 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:48:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:48:38 --> Session Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Final output sent to browser
DEBUG - 2014-04-28 23:48:38 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:48:38 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:48:38 --> A session cookie was not found.
DEBUG - 2014-04-28 23:48:38 --> Final output sent to browser
DEBUG - 2014-04-28 23:48:38 --> Total execution time: 0.0140
DEBUG - 2014-04-28 23:48:38 --> Session routines successfully run
DEBUG - 2014-04-28 23:48:38 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:48:38 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:48:38 --> Final output sent to browser
DEBUG - 2014-04-28 23:48:38 --> Total execution time: 0.0150
DEBUG - 2014-04-28 23:48:47 --> Config Class Initialized
DEBUG - 2014-04-28 23:48:47 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:48:47 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:48:47 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:48:47 --> URI Class Initialized
DEBUG - 2014-04-28 23:48:47 --> Router Class Initialized
DEBUG - 2014-04-28 23:48:47 --> Output Class Initialized
DEBUG - 2014-04-28 23:48:47 --> Security Class Initialized
DEBUG - 2014-04-28 23:48:47 --> Input Class Initialized
DEBUG - 2014-04-28 23:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:48:47 --> Language Class Initialized
DEBUG - 2014-04-28 23:48:47 --> Loader Class Initialized
DEBUG - 2014-04-28 23:48:47 --> Controller Class Initialized
DEBUG - 2014-04-28 23:48:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:48:47 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:48:47 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:47 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:47 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:48:47 --> Model Class Initialized
DEBUG - 2014-04-28 23:48:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:48:48 --> Final output sent to browser
DEBUG - 2014-04-28 23:48:48 --> Total execution time: 0.9101
DEBUG - 2014-04-28 23:50:14 --> Config Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:50:14 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:50:14 --> URI Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Router Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Output Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Security Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Input Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:50:14 --> Language Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Loader Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Controller Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:50:14 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:50:14 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:50:14 --> Session Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:50:14 --> A session cookie was not found.
DEBUG - 2014-04-28 23:50:14 --> Session routines successfully run
DEBUG - 2014-04-28 23:50:14 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:50:14 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:50:14 --> Final output sent to browser
DEBUG - 2014-04-28 23:50:14 --> Total execution time: 0.0120
DEBUG - 2014-04-28 23:50:14 --> Config Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:50:14 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:50:14 --> URI Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Router Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Output Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Security Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Input Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:50:14 --> Language Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Loader Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Controller Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:50:14 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:50:14 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:50:14 --> Session Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:50:14 --> A session cookie was not found.
DEBUG - 2014-04-28 23:50:14 --> Session routines successfully run
DEBUG - 2014-04-28 23:50:14 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:50:14 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:50:14 --> Final output sent to browser
DEBUG - 2014-04-28 23:50:14 --> Total execution time: 0.0120
DEBUG - 2014-04-28 23:50:14 --> Config Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:50:14 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:50:14 --> URI Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Router Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Output Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Security Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Input Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:50:14 --> Language Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Loader Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Controller Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:50:14 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:50:14 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:50:14 --> Session Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:50:14 --> A session cookie was not found.
DEBUG - 2014-04-28 23:50:14 --> Session routines successfully run
DEBUG - 2014-04-28 23:50:14 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:50:14 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:50:14 --> Final output sent to browser
DEBUG - 2014-04-28 23:50:14 --> Total execution time: 0.0120
DEBUG - 2014-04-28 23:50:15 --> Config Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Config Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Config Class Initialized
DEBUG - 2014-04-28 23:50:15 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:50:15 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:50:15 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:50:15 --> URI Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:50:15 --> URI Class Initialized
DEBUG - 2014-04-28 23:50:15 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:50:15 --> Router Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Router Class Initialized
DEBUG - 2014-04-28 23:50:15 --> URI Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Router Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Output Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Output Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Output Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Security Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Security Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Security Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Input Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Input Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Input Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:50:15 --> Language Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Language Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Language Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Loader Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Loader Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Loader Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Controller Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Controller Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Controller Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:50:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:50:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:50:15 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:50:15 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:50:15 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:50:15 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:50:15 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Session Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:50:15 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:50:15 --> A session cookie was not found.
DEBUG - 2014-04-28 23:50:15 --> Session Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:50:15 --> A session cookie was not found.
DEBUG - 2014-04-28 23:50:15 --> Session routines successfully run
DEBUG - 2014-04-28 23:50:15 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:50:15 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:50:15 --> Session routines successfully run
DEBUG - 2014-04-28 23:50:15 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:50:15 --> Final output sent to browser
DEBUG - 2014-04-28 23:50:15 --> Total execution time: 0.0150
DEBUG - 2014-04-28 23:50:15 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:50:15 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Final output sent to browser
DEBUG - 2014-04-28 23:50:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:50:15 --> Total execution time: 0.0160
DEBUG - 2014-04-28 23:50:15 --> Session Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:50:15 --> A session cookie was not found.
DEBUG - 2014-04-28 23:50:15 --> Session routines successfully run
DEBUG - 2014-04-28 23:50:15 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:50:15 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:50:15 --> Final output sent to browser
DEBUG - 2014-04-28 23:50:15 --> Total execution time: 0.0200
DEBUG - 2014-04-28 23:50:24 --> Config Class Initialized
DEBUG - 2014-04-28 23:50:24 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:50:24 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:50:24 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:50:24 --> URI Class Initialized
DEBUG - 2014-04-28 23:50:24 --> Router Class Initialized
DEBUG - 2014-04-28 23:50:24 --> Output Class Initialized
DEBUG - 2014-04-28 23:50:24 --> Security Class Initialized
DEBUG - 2014-04-28 23:50:24 --> Input Class Initialized
DEBUG - 2014-04-28 23:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:50:24 --> Language Class Initialized
DEBUG - 2014-04-28 23:50:24 --> Loader Class Initialized
DEBUG - 2014-04-28 23:50:24 --> Controller Class Initialized
DEBUG - 2014-04-28 23:50:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:50:24 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:50:24 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:24 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:24 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:50:24 --> Model Class Initialized
DEBUG - 2014-04-28 23:50:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:50:25 --> Final output sent to browser
DEBUG - 2014-04-28 23:50:25 --> Total execution time: 1.3741
DEBUG - 2014-04-28 23:51:05 --> Config Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Config Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Config Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:51:05 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:51:05 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:51:05 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:51:05 --> URI Class Initialized
DEBUG - 2014-04-28 23:51:05 --> URI Class Initialized
DEBUG - 2014-04-28 23:51:05 --> URI Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Router Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Router Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Router Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Output Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Security Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Input Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:51:05 --> Language Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Output Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Output Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Loader Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Controller Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Security Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Security Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Input Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Input Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:51:05 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:51:05 --> Language Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Language Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Loader Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Loader Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Controller Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Controller Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:51:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:51:05 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:51:05 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:51:05 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:51:05 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Session Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:51:05 --> A session cookie was not found.
DEBUG - 2014-04-28 23:51:05 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Session routines successfully run
DEBUG - 2014-04-28 23:51:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:51:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:51:05 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:51:05 --> Session Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Session Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:51:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:51:05 --> A session cookie was not found.
DEBUG - 2014-04-28 23:51:05 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:51:05 --> A session cookie was not found.
DEBUG - 2014-04-28 23:51:05 --> Session routines successfully run
DEBUG - 2014-04-28 23:51:05 --> Session routines successfully run
DEBUG - 2014-04-28 23:51:05 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:51:05 --> Final output sent to browser
DEBUG - 2014-04-28 23:51:05 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:51:05 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Total execution time: 0.0140
DEBUG - 2014-04-28 23:51:05 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:51:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:51:05 --> Final output sent to browser
DEBUG - 2014-04-28 23:51:05 --> Final output sent to browser
DEBUG - 2014-04-28 23:51:05 --> Total execution time: 0.0150
DEBUG - 2014-04-28 23:51:05 --> Total execution time: 0.0160
DEBUG - 2014-04-28 23:51:07 --> Config Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Config Class Initialized
DEBUG - 2014-04-28 23:51:07 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:51:07 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:51:07 --> URI Class Initialized
DEBUG - 2014-04-28 23:51:07 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:51:07 --> Router Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Config Class Initialized
DEBUG - 2014-04-28 23:51:07 --> URI Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Router Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Output Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:51:07 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:51:07 --> Security Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Input Class Initialized
DEBUG - 2014-04-28 23:51:07 --> URI Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:51:07 --> Output Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Router Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Language Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Security Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Loader Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Input Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Output Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:51:07 --> Controller Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Language Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Security Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:51:07 --> Loader Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Input Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:51:07 --> Controller Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:51:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Language Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:51:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:51:07 --> Loader Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Controller Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:51:07 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:51:07 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:51:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Session Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:51:07 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:51:07 --> A session cookie was not found.
DEBUG - 2014-04-28 23:51:07 --> Session routines successfully run
DEBUG - 2014-04-28 23:51:07 --> Session Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:51:07 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:51:07 --> A session cookie was not found.
DEBUG - 2014-04-28 23:51:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Session routines successfully run
DEBUG - 2014-04-28 23:51:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:51:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:51:07 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:51:07 --> Session Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:51:07 --> Final output sent to browser
DEBUG - 2014-04-28 23:51:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:51:07 --> A session cookie was not found.
DEBUG - 2014-04-28 23:51:07 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:51:07 --> Session routines successfully run
DEBUG - 2014-04-28 23:51:07 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:51:07 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:51:07 --> Final output sent to browser
DEBUG - 2014-04-28 23:51:07 --> Total execution time: 0.0150
DEBUG - 2014-04-28 23:51:07 --> Final output sent to browser
DEBUG - 2014-04-28 23:51:07 --> Total execution time: 0.0160
DEBUG - 2014-04-28 23:51:13 --> Config Class Initialized
DEBUG - 2014-04-28 23:51:13 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:51:13 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:51:13 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:51:13 --> URI Class Initialized
DEBUG - 2014-04-28 23:51:13 --> Router Class Initialized
DEBUG - 2014-04-28 23:51:13 --> Output Class Initialized
DEBUG - 2014-04-28 23:51:13 --> Security Class Initialized
DEBUG - 2014-04-28 23:51:13 --> Input Class Initialized
DEBUG - 2014-04-28 23:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:51:13 --> Language Class Initialized
DEBUG - 2014-04-28 23:51:13 --> Loader Class Initialized
DEBUG - 2014-04-28 23:51:13 --> Controller Class Initialized
DEBUG - 2014-04-28 23:51:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:51:13 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:51:13 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:13 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:13 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:51:13 --> Model Class Initialized
DEBUG - 2014-04-28 23:51:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:51:14 --> Final output sent to browser
DEBUG - 2014-04-28 23:51:14 --> Total execution time: 0.9171
DEBUG - 2014-04-28 23:52:24 --> Config Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Config Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Config Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:52:24 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:52:24 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:52:24 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:52:24 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:52:24 --> URI Class Initialized
DEBUG - 2014-04-28 23:52:24 --> URI Class Initialized
DEBUG - 2014-04-28 23:52:24 --> URI Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Router Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Router Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Router Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Output Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Output Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Security Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Security Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Input Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Input Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:52:24 --> Language Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Language Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Loader Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Loader Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Controller Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Output Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Controller Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:52:24 --> Security Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:52:24 --> Input Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:52:24 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:52:24 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Language Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Loader Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Controller Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:52:24 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:52:24 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:52:24 --> Session Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:52:24 --> A session cookie was not found.
DEBUG - 2014-04-28 23:52:24 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Session routines successfully run
DEBUG - 2014-04-28 23:52:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:52:24 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:52:24 --> Session Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:52:24 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:52:24 --> A session cookie was not found.
DEBUG - 2014-04-28 23:52:24 --> Session routines successfully run
DEBUG - 2014-04-28 23:52:24 --> Final output sent to browser
DEBUG - 2014-04-28 23:52:24 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:52:24 --> Total execution time: 0.0120
DEBUG - 2014-04-28 23:52:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:52:24 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Session Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:52:24 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:52:24 --> A session cookie was not found.
DEBUG - 2014-04-28 23:52:24 --> Session routines successfully run
DEBUG - 2014-04-28 23:52:24 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:52:24 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:52:24 --> Final output sent to browser
DEBUG - 2014-04-28 23:52:24 --> Total execution time: 0.0170
DEBUG - 2014-04-28 23:52:24 --> Final output sent to browser
DEBUG - 2014-04-28 23:52:24 --> Total execution time: 0.0190
DEBUG - 2014-04-28 23:52:26 --> Config Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Config Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Config Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:52:26 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:52:26 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:52:26 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:52:26 --> URI Class Initialized
DEBUG - 2014-04-28 23:52:26 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:52:26 --> URI Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Router Class Initialized
DEBUG - 2014-04-28 23:52:26 --> URI Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Router Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Router Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Output Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Output Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Security Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Security Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Output Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Input Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Input Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:52:26 --> Security Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:52:26 --> Language Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Input Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Language Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:52:26 --> Language Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Loader Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Loader Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Controller Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Controller Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Loader Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:52:26 --> Controller Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:52:26 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:52:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:52:26 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:52:26 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:52:26 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:52:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:52:26 --> Session Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Session Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:52:26 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:52:26 --> A session cookie was not found.
DEBUG - 2014-04-28 23:52:26 --> A session cookie was not found.
DEBUG - 2014-04-28 23:52:26 --> Session routines successfully run
DEBUG - 2014-04-28 23:52:26 --> Session routines successfully run
DEBUG - 2014-04-28 23:52:26 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:52:26 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:52:26 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:52:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:52:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:52:26 --> Session Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:52:26 --> A session cookie was not found.
DEBUG - 2014-04-28 23:52:26 --> Session routines successfully run
DEBUG - 2014-04-28 23:52:26 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:52:26 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:52:26 --> Final output sent to browser
DEBUG - 2014-04-28 23:52:26 --> Final output sent to browser
DEBUG - 2014-04-28 23:52:26 --> Total execution time: 0.0150
DEBUG - 2014-04-28 23:52:26 --> Total execution time: 0.0150
DEBUG - 2014-04-28 23:52:26 --> Final output sent to browser
DEBUG - 2014-04-28 23:52:26 --> Total execution time: 0.0170
DEBUG - 2014-04-28 23:52:33 --> Config Class Initialized
DEBUG - 2014-04-28 23:52:33 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:52:33 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:52:33 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:52:33 --> URI Class Initialized
DEBUG - 2014-04-28 23:52:33 --> Router Class Initialized
DEBUG - 2014-04-28 23:52:33 --> Output Class Initialized
DEBUG - 2014-04-28 23:52:33 --> Security Class Initialized
DEBUG - 2014-04-28 23:52:33 --> Input Class Initialized
DEBUG - 2014-04-28 23:52:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:52:33 --> Language Class Initialized
DEBUG - 2014-04-28 23:52:33 --> Loader Class Initialized
DEBUG - 2014-04-28 23:52:33 --> Controller Class Initialized
DEBUG - 2014-04-28 23:52:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:52:33 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:52:33 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:33 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:33 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:52:33 --> Model Class Initialized
DEBUG - 2014-04-28 23:52:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:52:33 --> Final output sent to browser
DEBUG - 2014-04-28 23:52:33 --> Total execution time: 0.9391
DEBUG - 2014-04-28 23:53:47 --> Config Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:53:47 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:53:47 --> URI Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Router Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Output Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Security Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Input Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:53:47 --> Language Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Loader Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Controller Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:53:47 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:53:47 --> Model Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Model Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Model Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:53:47 --> Session Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:53:47 --> Session routines successfully run
DEBUG - 2014-04-28 23:53:47 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:53:47 --> Model Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:53:47 --> Final output sent to browser
DEBUG - 2014-04-28 23:53:47 --> Total execution time: 0.0190
DEBUG - 2014-04-28 23:53:47 --> Config Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:53:47 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:53:47 --> URI Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Router Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Output Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Security Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Input Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:53:47 --> Language Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Loader Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Controller Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:53:47 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:53:47 --> Model Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Model Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Model Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:53:47 --> Session Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:53:47 --> Session routines successfully run
DEBUG - 2014-04-28 23:53:47 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:53:47 --> Model Class Initialized
DEBUG - 2014-04-28 23:53:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:53:47 --> Final output sent to browser
DEBUG - 2014-04-28 23:53:47 --> Total execution time: 0.0100
DEBUG - 2014-04-28 23:53:48 --> Config Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:53:48 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:53:48 --> URI Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Router Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Output Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Security Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Input Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:53:48 --> Language Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Loader Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Controller Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:53:48 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:53:48 --> Model Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Model Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Model Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:53:48 --> Session Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:53:48 --> Session routines successfully run
DEBUG - 2014-04-28 23:53:48 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:53:48 --> Model Class Initialized
DEBUG - 2014-04-28 23:53:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:53:48 --> Final output sent to browser
DEBUG - 2014-04-28 23:53:48 --> Total execution time: 0.0100
DEBUG - 2014-04-28 23:54:12 --> Config Class Initialized
DEBUG - 2014-04-28 23:54:12 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:54:12 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:54:12 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:54:12 --> URI Class Initialized
DEBUG - 2014-04-28 23:54:12 --> Router Class Initialized
DEBUG - 2014-04-28 23:54:12 --> Output Class Initialized
DEBUG - 2014-04-28 23:54:12 --> Security Class Initialized
DEBUG - 2014-04-28 23:54:12 --> Input Class Initialized
DEBUG - 2014-04-28 23:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:54:12 --> Language Class Initialized
DEBUG - 2014-04-28 23:54:12 --> Loader Class Initialized
DEBUG - 2014-04-28 23:54:12 --> Controller Class Initialized
DEBUG - 2014-04-28 23:54:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:54:12 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:54:12 --> Model Class Initialized
DEBUG - 2014-04-28 23:54:12 --> Model Class Initialized
DEBUG - 2014-04-28 23:54:12 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:54:12 --> Model Class Initialized
DEBUG - 2014-04-28 23:54:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:54:13 --> Final output sent to browser
DEBUG - 2014-04-28 23:54:13 --> Total execution time: 0.9041
DEBUG - 2014-04-28 23:56:52 --> Config Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Config Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Config Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:56:52 --> URI Class Initialized
DEBUG - 2014-04-28 23:56:52 --> URI Class Initialized
DEBUG - 2014-04-28 23:56:52 --> URI Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Router Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Router Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Router Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Output Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Output Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Output Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Security Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Security Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Security Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Input Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Input Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Input Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:56:52 --> Language Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Language Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Loader Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Loader Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:56:52 --> Controller Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Controller Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Language Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:56:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:56:52 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:56:52 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:56:52 --> Loader Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Controller Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:56:52 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:56:52 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:56:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Session Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:56:52 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:56:52 --> A session cookie was not found.
DEBUG - 2014-04-28 23:56:52 --> Session Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Session routines successfully run
DEBUG - 2014-04-28 23:56:52 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:56:52 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:56:52 --> A session cookie was not found.
DEBUG - 2014-04-28 23:56:52 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Session routines successfully run
DEBUG - 2014-04-28 23:56:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:56:52 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:56:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:56:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:56:52 --> Session Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:56:52 --> A session cookie was not found.
DEBUG - 2014-04-28 23:56:52 --> Session routines successfully run
DEBUG - 2014-04-28 23:56:52 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:56:52 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:56:52 --> Final output sent to browser
DEBUG - 2014-04-28 23:56:52 --> Final output sent to browser
DEBUG - 2014-04-28 23:56:52 --> Final output sent to browser
DEBUG - 2014-04-28 23:56:52 --> Total execution time: 0.0180
DEBUG - 2014-04-28 23:56:52 --> Total execution time: 0.0180
DEBUG - 2014-04-28 23:56:52 --> Total execution time: 0.0180
DEBUG - 2014-04-28 23:56:54 --> Config Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:56:54 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:56:54 --> Config Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Config Class Initialized
DEBUG - 2014-04-28 23:56:54 --> URI Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Router Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:56:54 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:56:54 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:56:54 --> Output Class Initialized
DEBUG - 2014-04-28 23:56:54 --> URI Class Initialized
DEBUG - 2014-04-28 23:56:54 --> URI Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Router Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Security Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Router Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Input Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:56:54 --> Output Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Output Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Language Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Security Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Security Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Input Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Loader Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Input Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:56:54 --> Controller Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Language Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Language Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:56:54 --> Loader Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:56:54 --> Loader Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Controller Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Controller Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:56:54 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:56:54 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:56:54 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:56:54 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:56:54 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:56:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:56:54 --> Session Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Session Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:56:54 --> A session cookie was not found.
DEBUG - 2014-04-28 23:56:54 --> Session Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:56:54 --> Session routines successfully run
DEBUG - 2014-04-28 23:56:54 --> A session cookie was not found.
DEBUG - 2014-04-28 23:56:54 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:56:54 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:56:54 --> Session routines successfully run
DEBUG - 2014-04-28 23:56:54 --> A session cookie was not found.
DEBUG - 2014-04-28 23:56:54 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:56:54 --> Session routines successfully run
DEBUG - 2014-04-28 23:56:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:56:54 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:56:54 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:56:54 --> Model Class Initialized
DEBUG - 2014-04-28 23:56:54 --> Final output sent to browser
DEBUG - 2014-04-28 23:56:54 --> Total execution time: 0.0110
DEBUG - 2014-04-28 23:56:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:56:54 --> Final output sent to browser
DEBUG - 2014-04-28 23:56:54 --> Total execution time: 0.0120
DEBUG - 2014-04-28 23:56:54 --> Final output sent to browser
DEBUG - 2014-04-28 23:56:54 --> Total execution time: 0.0140
DEBUG - 2014-04-28 23:57:16 --> Config Class Initialized
DEBUG - 2014-04-28 23:57:16 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:57:16 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:57:16 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:57:16 --> URI Class Initialized
DEBUG - 2014-04-28 23:57:16 --> Router Class Initialized
DEBUG - 2014-04-28 23:57:16 --> Output Class Initialized
DEBUG - 2014-04-28 23:57:16 --> Security Class Initialized
DEBUG - 2014-04-28 23:57:16 --> Input Class Initialized
DEBUG - 2014-04-28 23:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:57:16 --> Language Class Initialized
DEBUG - 2014-04-28 23:57:16 --> Loader Class Initialized
DEBUG - 2014-04-28 23:57:16 --> Controller Class Initialized
DEBUG - 2014-04-28 23:57:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:57:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:57:16 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:16 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:16 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:57:16 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:57:16 --> Final output sent to browser
DEBUG - 2014-04-28 23:57:16 --> Total execution time: 0.9261
DEBUG - 2014-04-28 23:57:53 --> Config Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Config Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Config Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:57:53 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:57:53 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:57:53 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:57:53 --> URI Class Initialized
DEBUG - 2014-04-28 23:57:53 --> URI Class Initialized
DEBUG - 2014-04-28 23:57:53 --> URI Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Router Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Router Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Router Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Output Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Output Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Output Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Security Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Security Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Security Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Input Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Input Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Input Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:57:53 --> Language Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Language Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Language Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Loader Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Loader Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Loader Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Controller Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Controller Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Controller Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:57:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:57:53 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:57:53 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:57:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:57:53 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:57:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:57:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Session Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:57:53 --> A session cookie was not found.
DEBUG - 2014-04-28 23:57:53 --> Session routines successfully run
DEBUG - 2014-04-28 23:57:53 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:57:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:57:53 --> Final output sent to browser
DEBUG - 2014-04-28 23:57:53 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:57:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:57:53 --> Session Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:57:53 --> A session cookie was not found.
DEBUG - 2014-04-28 23:57:53 --> Session routines successfully run
DEBUG - 2014-04-28 23:57:53 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:57:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:57:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:57:53 --> Session Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:57:53 --> A session cookie was not found.
DEBUG - 2014-04-28 23:57:53 --> Session routines successfully run
DEBUG - 2014-04-28 23:57:53 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:57:53 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:57:53 --> Final output sent to browser
DEBUG - 2014-04-28 23:57:53 --> Total execution time: 0.0200
DEBUG - 2014-04-28 23:57:53 --> Final output sent to browser
DEBUG - 2014-04-28 23:57:53 --> Total execution time: 0.0210
DEBUG - 2014-04-28 23:57:55 --> Config Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Config Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Config Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:57:55 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:57:55 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:57:55 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:57:55 --> URI Class Initialized
DEBUG - 2014-04-28 23:57:55 --> URI Class Initialized
DEBUG - 2014-04-28 23:57:55 --> URI Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Router Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Router Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Router Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Output Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Output Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Output Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Security Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Security Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Security Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Input Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Input Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Input Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:57:55 --> Language Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Language Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Language Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Loader Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Loader Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Loader Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Controller Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Controller Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Controller Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:57:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:57:55 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:57:55 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:57:55 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:57:55 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:57:55 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:57:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:57:55 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:57:55 --> Session Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Session Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:57:55 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:57:55 --> A session cookie was not found.
DEBUG - 2014-04-28 23:57:55 --> A session cookie was not found.
DEBUG - 2014-04-28 23:57:55 --> Session routines successfully run
DEBUG - 2014-04-28 23:57:55 --> Session routines successfully run
DEBUG - 2014-04-28 23:57:55 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:57:55 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:57:55 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:57:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:57:55 --> Final output sent to browser
DEBUG - 2014-04-28 23:57:55 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:57:55 --> Session Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Final output sent to browser
DEBUG - 2014-04-28 23:57:55 --> Total execution time: 0.0130
DEBUG - 2014-04-28 23:57:55 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:57:55 --> A session cookie was not found.
DEBUG - 2014-04-28 23:57:55 --> Session routines successfully run
DEBUG - 2014-04-28 23:57:55 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:57:55 --> Model Class Initialized
DEBUG - 2014-04-28 23:57:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:57:55 --> Final output sent to browser
DEBUG - 2014-04-28 23:57:55 --> Total execution time: 0.0160
DEBUG - 2014-04-28 23:58:02 --> Config Class Initialized
DEBUG - 2014-04-28 23:58:02 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:58:02 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:58:02 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:58:02 --> URI Class Initialized
DEBUG - 2014-04-28 23:58:02 --> Router Class Initialized
DEBUG - 2014-04-28 23:58:02 --> Output Class Initialized
DEBUG - 2014-04-28 23:58:02 --> Security Class Initialized
DEBUG - 2014-04-28 23:58:02 --> Input Class Initialized
DEBUG - 2014-04-28 23:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:58:02 --> Language Class Initialized
DEBUG - 2014-04-28 23:58:02 --> Loader Class Initialized
DEBUG - 2014-04-28 23:58:02 --> Controller Class Initialized
DEBUG - 2014-04-28 23:58:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:58:02 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:58:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:58:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:58:02 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:58:02 --> Model Class Initialized
DEBUG - 2014-04-28 23:58:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:58:03 --> Final output sent to browser
DEBUG - 2014-04-28 23:58:03 --> Total execution time: 0.9401
DEBUG - 2014-04-28 23:58:59 --> Config Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:58:59 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:58:59 --> URI Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Router Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Output Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Security Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Input Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:58:59 --> Language Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Loader Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Controller Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:58:59 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:58:59 --> Model Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Model Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Model Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:58:59 --> Session Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:58:59 --> Session routines successfully run
DEBUG - 2014-04-28 23:58:59 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:58:59 --> Model Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:58:59 --> Final output sent to browser
DEBUG - 2014-04-28 23:58:59 --> Total execution time: 0.0190
DEBUG - 2014-04-28 23:58:59 --> Config Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:58:59 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:58:59 --> URI Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Router Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Output Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Security Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Input Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:58:59 --> Language Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Loader Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Controller Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:58:59 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:58:59 --> Model Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Model Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Model Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:58:59 --> Session Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:58:59 --> Session routines successfully run
DEBUG - 2014-04-28 23:58:59 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:58:59 --> Model Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:58:59 --> Final output sent to browser
DEBUG - 2014-04-28 23:58:59 --> Total execution time: 0.0110
DEBUG - 2014-04-28 23:58:59 --> Config Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:58:59 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:58:59 --> URI Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Router Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Output Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Security Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Input Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:58:59 --> Language Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Loader Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Controller Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:58:59 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:58:59 --> Model Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Model Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Model Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:58:59 --> Session Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Helper loaded: string_helper
DEBUG - 2014-04-28 23:58:59 --> Session routines successfully run
DEBUG - 2014-04-28 23:58:59 --> Helper loaded: url_helper
DEBUG - 2014-04-28 23:58:59 --> Model Class Initialized
DEBUG - 2014-04-28 23:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:58:59 --> Final output sent to browser
DEBUG - 2014-04-28 23:58:59 --> Total execution time: 0.0110
DEBUG - 2014-04-28 23:59:44 --> Config Class Initialized
DEBUG - 2014-04-28 23:59:44 --> Hooks Class Initialized
DEBUG - 2014-04-28 23:59:44 --> Utf8 Class Initialized
DEBUG - 2014-04-28 23:59:44 --> UTF-8 Support Enabled
DEBUG - 2014-04-28 23:59:44 --> URI Class Initialized
DEBUG - 2014-04-28 23:59:44 --> Router Class Initialized
DEBUG - 2014-04-28 23:59:44 --> Output Class Initialized
DEBUG - 2014-04-28 23:59:44 --> Security Class Initialized
DEBUG - 2014-04-28 23:59:44 --> Input Class Initialized
DEBUG - 2014-04-28 23:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-28 23:59:44 --> Language Class Initialized
DEBUG - 2014-04-28 23:59:44 --> Loader Class Initialized
DEBUG - 2014-04-28 23:59:44 --> Controller Class Initialized
DEBUG - 2014-04-28 23:59:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-28 23:59:44 --> Helper loaded: utilities_helper
DEBUG - 2014-04-28 23:59:44 --> Model Class Initialized
DEBUG - 2014-04-28 23:59:44 --> Model Class Initialized
DEBUG - 2014-04-28 23:59:44 --> Database Driver Class Initialized
DEBUG - 2014-04-28 23:59:44 --> Model Class Initialized
DEBUG - 2014-04-28 23:59:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-28 23:59:45 --> Final output sent to browser
DEBUG - 2014-04-28 23:59:45 --> Total execution time: 0.9771
