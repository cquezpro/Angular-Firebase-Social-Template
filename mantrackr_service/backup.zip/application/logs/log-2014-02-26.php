<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-26 18:11:02 --> Config Class Initialized
DEBUG - 2014-02-26 18:11:02 --> Hooks Class Initialized
DEBUG - 2014-02-26 18:11:02 --> Utf8 Class Initialized
DEBUG - 2014-02-26 18:11:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-26 18:11:02 --> URI Class Initialized
DEBUG - 2014-02-26 18:11:02 --> Router Class Initialized
DEBUG - 2014-02-26 18:11:02 --> Output Class Initialized
DEBUG - 2014-02-26 18:11:02 --> Security Class Initialized
DEBUG - 2014-02-26 18:11:02 --> Input Class Initialized
DEBUG - 2014-02-26 18:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-26 18:11:02 --> Language Class Initialized
DEBUG - 2014-02-26 18:11:02 --> Loader Class Initialized
DEBUG - 2014-02-26 18:11:02 --> Controller Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-26 18:11:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-26 18:11:03 --> Model Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Model Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Database Driver Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Model Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-26 18:11:03 --> Session Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Helper loaded: string_helper
DEBUG - 2014-02-26 18:11:03 --> A session cookie was not found.
DEBUG - 2014-02-26 18:11:03 --> Session routines successfully run
DEBUG - 2014-02-26 18:11:03 --> Helper loaded: url_helper
DEBUG - 2014-02-26 18:11:03 --> Config Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Hooks Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Utf8 Class Initialized
DEBUG - 2014-02-26 18:11:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-26 18:11:03 --> URI Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Router Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Output Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Security Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Input Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-26 18:11:03 --> Language Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Loader Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Controller Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-26 18:11:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-26 18:11:03 --> Model Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Model Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Database Driver Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Model Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-26 18:11:03 --> Session Class Initialized
DEBUG - 2014-02-26 18:11:03 --> Helper loaded: string_helper
DEBUG - 2014-02-26 18:11:03 --> Session routines successfully run
DEBUG - 2014-02-26 18:11:03 --> Helper loaded: url_helper
DEBUG - 2014-02-26 18:11:03 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-26 18:11:03 --> Final output sent to browser
DEBUG - 2014-02-26 18:11:03 --> Total execution time: 0.0520
