<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-03 19:35:52 --> Config Class Initialized
DEBUG - 2014-02-03 19:35:52 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:35:52 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:35:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:35:52 --> URI Class Initialized
DEBUG - 2014-02-03 19:35:52 --> Router Class Initialized
DEBUG - 2014-02-03 19:35:52 --> No URI present. Default controller set.
DEBUG - 2014-02-03 19:35:52 --> Output Class Initialized
DEBUG - 2014-02-03 19:35:52 --> Security Class Initialized
DEBUG - 2014-02-03 19:35:52 --> Input Class Initialized
DEBUG - 2014-02-03 19:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:35:52 --> Language Class Initialized
DEBUG - 2014-02-03 19:35:52 --> Loader Class Initialized
DEBUG - 2014-02-03 19:35:52 --> Controller Class Initialized
DEBUG - 2014-02-03 19:35:52 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-02-03 19:35:52 --> Final output sent to browser
DEBUG - 2014-02-03 19:35:52 --> Total execution time: 0.0110
DEBUG - 2014-02-03 19:35:59 --> Config Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:35:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:35:59 --> URI Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Router Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Output Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Security Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Input Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:35:59 --> Language Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Loader Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Controller Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:35:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:35:59 --> Model Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Model Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Database Driver Class Initialized
ERROR - 2014-02-03 19:35:59 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-03 19:35:59 --> Model Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:35:59 --> Session Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:35:59 --> A session cookie was not found.
DEBUG - 2014-02-03 19:35:59 --> Session routines successfully run
DEBUG - 2014-02-03 19:35:59 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:35:59 --> Config Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:35:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:35:59 --> URI Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Router Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Output Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Security Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Input Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:35:59 --> Language Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Loader Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Controller Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:35:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:35:59 --> Model Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Model Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Database Driver Class Initialized
ERROR - 2014-02-03 19:35:59 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-03 19:35:59 --> Model Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:35:59 --> Session Class Initialized
DEBUG - 2014-02-03 19:35:59 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:35:59 --> Session routines successfully run
DEBUG - 2014-02-03 19:35:59 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:35:59 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-03 19:35:59 --> Final output sent to browser
DEBUG - 2014-02-03 19:35:59 --> Total execution time: 0.0210
DEBUG - 2014-02-03 19:36:03 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:03 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:03 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Database Driver Class Initialized
ERROR - 2014-02-03 19:36:03 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:03 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:03 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:03 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:03 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:03 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:03 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:03 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:03 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:03 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:03 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:03 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:03 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:03 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 19:36:03 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:03 --> Total execution time: 0.0120
DEBUG - 2014-02-03 19:36:03 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:03 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:03 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:03 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:03 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:03 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:03 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:03 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:03 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:03 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:03 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:03 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:03 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:03 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:03 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:03 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:03 --> Total execution time: 0.0140
DEBUG - 2014-02-03 19:36:03 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:03 --> Total execution time: 0.0210
DEBUG - 2014-02-03 19:36:03 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:03 --> Total execution time: 0.0270
DEBUG - 2014-02-03 19:36:07 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:07 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:07 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:07 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:07 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:07 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:07 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:07 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:07 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:07 --> Total execution time: 0.0220
DEBUG - 2014-02-03 19:36:07 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:07 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:07 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:07 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:07 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:07 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:07 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:07 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:07 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-03 19:36:07 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:07 --> Total execution time: 0.0150
DEBUG - 2014-02-03 19:36:08 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:08 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:08 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:08 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:08 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:08 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:08 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:08 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:08 --> Total execution time: 0.0120
DEBUG - 2014-02-03 19:36:08 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:08 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:08 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:08 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:08 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:08 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:08 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:08 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 19:36:08 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:08 --> Total execution time: 0.0200
DEBUG - 2014-02-03 19:36:08 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:08 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:08 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:08 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:08 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:08 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:08 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:08 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:08 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:08 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:08 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:09 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:09 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:09 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:09 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:09 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:09 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:09 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:09 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:09 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:09 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:09 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:09 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:09 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:09 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:09 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:09 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:09 --> Total execution time: 0.0140
DEBUG - 2014-02-03 19:36:09 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:09 --> Total execution time: 0.0180
DEBUG - 2014-02-03 19:36:09 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:09 --> Total execution time: 0.0300
DEBUG - 2014-02-03 19:36:10 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:10 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:10 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:10 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:10 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:10 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:10 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:10 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-03 19:36:10 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:10 --> Total execution time: 0.0190
DEBUG - 2014-02-03 19:36:10 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:10 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:10 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:10 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:10 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:10 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:10 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:10 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:10 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:10 --> Total execution time: 0.0100
DEBUG - 2014-02-03 19:36:15 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:15 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:15 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:15 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:15 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:15 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:15 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 19:36:15 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:15 --> Total execution time: 0.0190
DEBUG - 2014-02-03 19:36:15 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:15 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:15 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:15 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:15 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:15 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:15 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:15 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:15 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:15 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:15 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:15 --> Total execution time: 0.0110
DEBUG - 2014-02-03 19:36:15 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:15 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:15 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:15 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:15 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:15 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:15 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:15 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:15 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:15 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:15 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:15 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:15 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:15 --> Total execution time: 0.0240
DEBUG - 2014-02-03 19:36:15 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:15 --> Total execution time: 0.0180
DEBUG - 2014-02-03 19:36:18 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:18 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:18 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:18 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:18 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:18 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:18 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:18 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:18 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:18 --> Total execution time: 0.0420
DEBUG - 2014-02-03 19:36:18 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:18 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:18 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:18 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:18 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:18 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:18 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:18 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:18 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:18 --> Total execution time: 0.0400
DEBUG - 2014-02-03 19:36:19 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:19 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:19 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:19 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:19 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:19 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:19 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:19 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:19 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:19 --> Total execution time: 0.0290
DEBUG - 2014-02-03 19:36:20 --> Config Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:36:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:36:20 --> URI Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Router Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Output Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Security Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Input Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:36:20 --> Language Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Loader Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Controller Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:36:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:36:20 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:20 --> Session Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:36:20 --> Session routines successfully run
DEBUG - 2014-02-03 19:36:20 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:36:20 --> Model Class Initialized
DEBUG - 2014-02-03 19:36:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:36:20 --> Final output sent to browser
DEBUG - 2014-02-03 19:36:20 --> Total execution time: 0.0310
DEBUG - 2014-02-03 19:59:04 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:04 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:04 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:04 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:04 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:04 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:04 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 19:59:04 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:04 --> Total execution time: 0.0220
DEBUG - 2014-02-03 19:59:04 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:04 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:04 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:04 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:04 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:04 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:04 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:04 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:04 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:04 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:04 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:04 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:04 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:04 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:04 --> Total execution time: 0.0130
DEBUG - 2014-02-03 19:59:04 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:04 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:04 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:04 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:04 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:04 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:04 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:04 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:04 --> Total execution time: 0.0290
DEBUG - 2014-02-03 19:59:04 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:04 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:04 --> Total execution time: 0.0180
DEBUG - 2014-02-03 19:59:05 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:05 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:05 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:05 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:05 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:05 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:05 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 19:59:05 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:05 --> Total execution time: 0.0150
DEBUG - 2014-02-03 19:59:05 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:05 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:05 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:05 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:05 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:05 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:05 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:05 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:05 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:05 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:05 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:05 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:05 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:05 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:05 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:05 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:05 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:05 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:05 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:05 --> Total execution time: 0.0130
DEBUG - 2014-02-03 19:59:05 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:05 --> Total execution time: 0.0190
DEBUG - 2014-02-03 19:59:05 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:05 --> Total execution time: 0.0250
DEBUG - 2014-02-03 19:59:11 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:11 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:11 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:11 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:11 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:11 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:11 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:11 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:11 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:11 --> Total execution time: 0.0200
DEBUG - 2014-02-03 19:59:13 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:13 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:13 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:13 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:13 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:13 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:13 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:13 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:13 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:13 --> Total execution time: 0.0180
DEBUG - 2014-02-03 19:59:17 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:17 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:17 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:17 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:17 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:17 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:17 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:17 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:17 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:17 --> Total execution time: 0.0230
DEBUG - 2014-02-03 19:59:19 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:19 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:19 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:19 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:19 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:19 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:19 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:19 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:19 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:19 --> Total execution time: 0.0190
DEBUG - 2014-02-03 19:59:27 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:27 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:27 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:27 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:27 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:27 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:27 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:27 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:27 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:27 --> Total execution time: 0.0160
DEBUG - 2014-02-03 19:59:30 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:30 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:30 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:30 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:30 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:30 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:30 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:30 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:30 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:30 --> Total execution time: 0.0220
DEBUG - 2014-02-03 19:59:32 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:32 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:32 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:32 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:32 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:32 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:32 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:32 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:32 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:32 --> Total execution time: 0.0190
DEBUG - 2014-02-03 19:59:35 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:35 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:35 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:35 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:35 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:35 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:35 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:35 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:35 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:35 --> Total execution time: 0.0430
DEBUG - 2014-02-03 19:59:36 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:36 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:36 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:36 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:36 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:36 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:36 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:36 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:36 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:36 --> Total execution time: 0.0260
DEBUG - 2014-02-03 19:59:45 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:45 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:45 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:45 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:45 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:45 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:45 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:45 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:45 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:45 --> Total execution time: 0.0430
DEBUG - 2014-02-03 19:59:48 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:48 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:48 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:48 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:48 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:48 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:48 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:48 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:48 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:48 --> Total execution time: 0.0410
DEBUG - 2014-02-03 19:59:49 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:49 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:49 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:49 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:49 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:49 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:49 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:49 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:49 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:49 --> Total execution time: 0.0170
DEBUG - 2014-02-03 19:59:51 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:51 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:51 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:51 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:51 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:51 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:51 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:51 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:51 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:51 --> Total execution time: 0.0290
DEBUG - 2014-02-03 19:59:52 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:52 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:52 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:52 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:52 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:52 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:52 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:52 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:52 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:52 --> Total execution time: 0.0300
DEBUG - 2014-02-03 19:59:52 --> Config Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Hooks Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Utf8 Class Initialized
DEBUG - 2014-02-03 19:59:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 19:59:52 --> URI Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Router Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Output Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Security Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Input Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 19:59:52 --> Language Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Loader Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Controller Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 19:59:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 19:59:52 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Database Driver Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:52 --> Session Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Helper loaded: string_helper
DEBUG - 2014-02-03 19:59:52 --> Session routines successfully run
DEBUG - 2014-02-03 19:59:52 --> Helper loaded: url_helper
DEBUG - 2014-02-03 19:59:52 --> Model Class Initialized
DEBUG - 2014-02-03 19:59:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 19:59:52 --> Final output sent to browser
DEBUG - 2014-02-03 19:59:52 --> Total execution time: 0.0290
DEBUG - 2014-02-03 20:02:59 --> Config Class Initialized
DEBUG - 2014-02-03 20:02:59 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:02:59 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:02:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:02:59 --> URI Class Initialized
DEBUG - 2014-02-03 20:02:59 --> Router Class Initialized
DEBUG - 2014-02-03 20:02:59 --> Output Class Initialized
DEBUG - 2014-02-03 20:02:59 --> Security Class Initialized
DEBUG - 2014-02-03 20:02:59 --> Input Class Initialized
DEBUG - 2014-02-03 20:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:02:59 --> Language Class Initialized
DEBUG - 2014-02-03 20:02:59 --> Loader Class Initialized
DEBUG - 2014-02-03 20:02:59 --> Controller Class Initialized
DEBUG - 2014-02-03 20:02:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:02:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:02:59 --> Model Class Initialized
DEBUG - 2014-02-03 20:02:59 --> Model Class Initialized
DEBUG - 2014-02-03 20:02:59 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:02:59 --> Model Class Initialized
DEBUG - 2014-02-03 20:02:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:02:59 --> Session Class Initialized
DEBUG - 2014-02-03 20:02:59 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:02:59 --> Session routines successfully run
DEBUG - 2014-02-03 20:02:59 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:02:59 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 20:02:59 --> Final output sent to browser
DEBUG - 2014-02-03 20:02:59 --> Total execution time: 0.0230
DEBUG - 2014-02-03 20:03:00 --> Config Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:03:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:03:00 --> URI Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Router Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Output Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Security Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Input Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Config Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:03:00 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Language Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:03:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:03:00 --> Loader Class Initialized
DEBUG - 2014-02-03 20:03:00 --> URI Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Controller Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Config Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Router Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:03:00 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:03:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:03:00 --> Output Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:00 --> URI Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Security Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Router Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Input Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:03:00 --> Output Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Language Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Security Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Input Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Loader Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Controller Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:03:00 --> Language Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:03:00 --> Loader Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:03:00 --> Session Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:03:00 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:03:00 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Controller Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Session routines successfully run
DEBUG - 2014-02-03 20:03:00 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:03:00 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:03:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:03:00 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:03:00 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:03:00 --> Session Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:03:00 --> Session routines successfully run
DEBUG - 2014-02-03 20:03:00 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:03:00 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:03:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:03:00 --> Final output sent to browser
DEBUG - 2014-02-03 20:03:00 --> Session Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Total execution time: 0.0130
DEBUG - 2014-02-03 20:03:00 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:03:00 --> Session routines successfully run
DEBUG - 2014-02-03 20:03:00 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:03:00 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:03:00 --> Final output sent to browser
DEBUG - 2014-02-03 20:03:00 --> Total execution time: 0.0205
DEBUG - 2014-02-03 20:03:00 --> Final output sent to browser
DEBUG - 2014-02-03 20:03:00 --> Total execution time: 0.0260
DEBUG - 2014-02-03 20:03:07 --> Config Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:03:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:03:07 --> URI Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Router Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Output Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Security Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Input Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:03:07 --> Language Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Loader Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Controller Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:03:07 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:03:07 --> Session Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:03:07 --> Session routines successfully run
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:03:07 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 20:03:07 --> Final output sent to browser
DEBUG - 2014-02-03 20:03:07 --> Total execution time: 0.0130
DEBUG - 2014-02-03 20:03:07 --> Config Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:03:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:03:07 --> URI Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Router Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Output Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Security Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Input Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Config Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:03:07 --> Config Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Language Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:03:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:03:07 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Loader Class Initialized
DEBUG - 2014-02-03 20:03:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:03:07 --> Controller Class Initialized
DEBUG - 2014-02-03 20:03:07 --> URI Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:03:07 --> URI Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Router Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:03:07 --> Router Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Output Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Output Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Security Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Security Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Input Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Input Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:03:07 --> Language Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Language Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Loader Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:03:07 --> Loader Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Controller Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Controller Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Session Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:03:07 --> Session routines successfully run
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:03:07 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:03:07 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:03:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:03:07 --> Session Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Session Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:03:07 --> Session routines successfully run
DEBUG - 2014-02-03 20:03:07 --> Session routines successfully run
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:03:07 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:03:07 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:03:07 --> Model Class Initialized
DEBUG - 2014-02-03 20:03:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:03:07 --> Final output sent to browser
DEBUG - 2014-02-03 20:03:07 --> Total execution time: 0.0150
DEBUG - 2014-02-03 20:03:07 --> Final output sent to browser
DEBUG - 2014-02-03 20:03:07 --> Total execution time: 0.0190
DEBUG - 2014-02-03 20:03:07 --> Final output sent to browser
DEBUG - 2014-02-03 20:03:07 --> Total execution time: 0.0240
DEBUG - 2014-02-03 20:08:29 --> Config Class Initialized
DEBUG - 2014-02-03 20:08:29 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:08:29 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:08:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:08:29 --> URI Class Initialized
DEBUG - 2014-02-03 20:08:29 --> Router Class Initialized
DEBUG - 2014-02-03 20:08:29 --> Output Class Initialized
DEBUG - 2014-02-03 20:08:29 --> Security Class Initialized
DEBUG - 2014-02-03 20:08:29 --> Input Class Initialized
DEBUG - 2014-02-03 20:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:08:29 --> Language Class Initialized
DEBUG - 2014-02-03 20:08:29 --> Loader Class Initialized
DEBUG - 2014-02-03 20:08:29 --> Controller Class Initialized
DEBUG - 2014-02-03 20:08:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:08:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:08:29 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:29 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:29 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:08:29 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:08:29 --> Session Class Initialized
DEBUG - 2014-02-03 20:08:29 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:08:29 --> Session routines successfully run
DEBUG - 2014-02-03 20:08:29 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:08:29 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 20:08:29 --> Final output sent to browser
DEBUG - 2014-02-03 20:08:29 --> Total execution time: 0.0130
DEBUG - 2014-02-03 20:08:30 --> Config Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:08:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:08:30 --> URI Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Router Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Output Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Security Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Input Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:08:30 --> Config Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Language Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Loader Class Initialized
DEBUG - 2014-02-03 20:08:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:08:30 --> Controller Class Initialized
DEBUG - 2014-02-03 20:08:30 --> URI Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Config Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:08:30 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Router Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:08:30 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:08:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:08:30 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Output Class Initialized
DEBUG - 2014-02-03 20:08:30 --> URI Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Security Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Router Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Input Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:08:30 --> Output Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Language Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Security Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Loader Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Input Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:08:30 --> Controller Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:08:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:08:30 --> Session Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:08:30 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:08:30 --> Language Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Session routines successfully run
DEBUG - 2014-02-03 20:08:30 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:08:30 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Loader Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Controller Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:08:30 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:08:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:08:30 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Session Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:08:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:08:30 --> Session routines successfully run
DEBUG - 2014-02-03 20:08:30 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:08:30 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:08:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:08:30 --> Session Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Final output sent to browser
DEBUG - 2014-02-03 20:08:30 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:08:30 --> Total execution time: 0.0120
DEBUG - 2014-02-03 20:08:30 --> Session routines successfully run
DEBUG - 2014-02-03 20:08:30 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:08:30 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:08:30 --> Final output sent to browser
DEBUG - 2014-02-03 20:08:30 --> Total execution time: 0.0200
DEBUG - 2014-02-03 20:08:30 --> Final output sent to browser
DEBUG - 2014-02-03 20:08:30 --> Total execution time: 0.0260
DEBUG - 2014-02-03 20:08:33 --> Config Class Initialized
DEBUG - 2014-02-03 20:08:33 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:08:33 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:08:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:08:33 --> URI Class Initialized
DEBUG - 2014-02-03 20:08:33 --> Router Class Initialized
DEBUG - 2014-02-03 20:08:33 --> Output Class Initialized
DEBUG - 2014-02-03 20:08:33 --> Security Class Initialized
DEBUG - 2014-02-03 20:08:33 --> Input Class Initialized
DEBUG - 2014-02-03 20:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:08:33 --> Language Class Initialized
DEBUG - 2014-02-03 20:08:33 --> Loader Class Initialized
DEBUG - 2014-02-03 20:08:33 --> Controller Class Initialized
DEBUG - 2014-02-03 20:08:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:08:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:08:33 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:33 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:33 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:08:33 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:08:33 --> Session Class Initialized
DEBUG - 2014-02-03 20:08:33 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:08:33 --> Session routines successfully run
DEBUG - 2014-02-03 20:08:33 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:08:33 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 20:08:33 --> Final output sent to browser
DEBUG - 2014-02-03 20:08:33 --> Total execution time: 0.0210
DEBUG - 2014-02-03 20:08:34 --> Config Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Config Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Config Class Initialized
DEBUG - 2014-02-03 20:08:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:08:34 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:08:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:08:34 --> URI Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:08:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:08:34 --> Router Class Initialized
DEBUG - 2014-02-03 20:08:34 --> URI Class Initialized
DEBUG - 2014-02-03 20:08:34 --> URI Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Router Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Router Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Output Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Security Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Output Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Output Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Input Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Security Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Security Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Input Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:08:34 --> Input Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:08:34 --> Language Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Language Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Language Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Loader Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Loader Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Loader Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Controller Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Controller Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Controller Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:08:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:08:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:08:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:08:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:08:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:08:34 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:08:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:08:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:08:34 --> Session Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Session Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Session Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:08:34 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:08:34 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:08:34 --> Session routines successfully run
DEBUG - 2014-02-03 20:08:34 --> Session routines successfully run
DEBUG - 2014-02-03 20:08:34 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:08:34 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:08:34 --> Session routines successfully run
DEBUG - 2014-02-03 20:08:34 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:08:34 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:08:34 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:08:34 --> Model Class Initialized
DEBUG - 2014-02-03 20:08:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:08:34 --> Final output sent to browser
DEBUG - 2014-02-03 20:08:34 --> Total execution time: 0.0140
DEBUG - 2014-02-03 20:08:34 --> Final output sent to browser
DEBUG - 2014-02-03 20:08:34 --> Total execution time: 0.0210
DEBUG - 2014-02-03 20:08:34 --> Final output sent to browser
DEBUG - 2014-02-03 20:08:34 --> Total execution time: 0.0260
DEBUG - 2014-02-03 20:09:18 --> Config Class Initialized
DEBUG - 2014-02-03 20:09:18 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:09:18 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:09:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:09:18 --> URI Class Initialized
DEBUG - 2014-02-03 20:09:18 --> Router Class Initialized
DEBUG - 2014-02-03 20:09:18 --> Output Class Initialized
DEBUG - 2014-02-03 20:09:18 --> Security Class Initialized
DEBUG - 2014-02-03 20:09:18 --> Input Class Initialized
DEBUG - 2014-02-03 20:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:09:18 --> Language Class Initialized
DEBUG - 2014-02-03 20:09:18 --> Loader Class Initialized
DEBUG - 2014-02-03 20:09:18 --> Controller Class Initialized
DEBUG - 2014-02-03 20:09:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:09:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:09:18 --> Model Class Initialized
DEBUG - 2014-02-03 20:09:18 --> Model Class Initialized
DEBUG - 2014-02-03 20:09:18 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:09:18 --> Model Class Initialized
DEBUG - 2014-02-03 20:09:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:09:18 --> Session Class Initialized
DEBUG - 2014-02-03 20:09:18 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:09:18 --> Session routines successfully run
DEBUG - 2014-02-03 20:09:18 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:09:18 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 20:09:18 --> Final output sent to browser
DEBUG - 2014-02-03 20:09:18 --> Total execution time: 0.0160
DEBUG - 2014-02-03 20:09:19 --> Config Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Config Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Config Class Initialized
DEBUG - 2014-02-03 20:09:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:09:19 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Hooks Class Initialized
DEBUG - 2014-02-03 20:09:19 --> URI Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Utf8 Class Initialized
DEBUG - 2014-02-03 20:09:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:09:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 20:09:19 --> Router Class Initialized
DEBUG - 2014-02-03 20:09:19 --> URI Class Initialized
DEBUG - 2014-02-03 20:09:19 --> URI Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Router Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Router Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Output Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Security Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Output Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Output Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Security Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Security Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Input Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Input Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Input Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 20:09:19 --> Language Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Language Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Language Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Loader Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Controller Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Loader Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Loader Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:09:19 --> Controller Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Controller Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:09:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:09:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 20:09:19 --> Model Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:09:19 --> Model Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 20:09:19 --> Model Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Model Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Model Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Model Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Database Driver Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Model Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:09:19 --> Model Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Model Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Session Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:09:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:09:19 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:09:19 --> Session routines successfully run
DEBUG - 2014-02-03 20:09:19 --> Session Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Session Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:09:19 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:09:19 --> Helper loaded: string_helper
DEBUG - 2014-02-03 20:09:19 --> Session routines successfully run
DEBUG - 2014-02-03 20:09:19 --> Session routines successfully run
DEBUG - 2014-02-03 20:09:19 --> Model Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:09:19 --> Helper loaded: url_helper
DEBUG - 2014-02-03 20:09:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:09:19 --> Model Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Model Class Initialized
DEBUG - 2014-02-03 20:09:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:09:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 20:09:19 --> Final output sent to browser
DEBUG - 2014-02-03 20:09:19 --> Total execution time: 0.0140
DEBUG - 2014-02-03 20:09:19 --> Final output sent to browser
DEBUG - 2014-02-03 20:09:19 --> Total execution time: 0.0180
DEBUG - 2014-02-03 20:09:19 --> Final output sent to browser
DEBUG - 2014-02-03 20:09:19 --> Total execution time: 0.0240
DEBUG - 2014-02-03 21:08:49 --> Config Class Initialized
DEBUG - 2014-02-03 21:08:49 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:08:49 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:08:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:08:49 --> URI Class Initialized
DEBUG - 2014-02-03 21:08:49 --> Router Class Initialized
DEBUG - 2014-02-03 21:08:49 --> Output Class Initialized
DEBUG - 2014-02-03 21:08:49 --> Security Class Initialized
DEBUG - 2014-02-03 21:08:49 --> Input Class Initialized
DEBUG - 2014-02-03 21:08:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:08:49 --> Language Class Initialized
DEBUG - 2014-02-03 21:08:49 --> Loader Class Initialized
DEBUG - 2014-02-03 21:08:49 --> Controller Class Initialized
DEBUG - 2014-02-03 21:08:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:08:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:08:49 --> Model Class Initialized
DEBUG - 2014-02-03 21:08:49 --> Model Class Initialized
DEBUG - 2014-02-03 21:08:49 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:08:49 --> Model Class Initialized
DEBUG - 2014-02-03 21:08:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:08:49 --> Session Class Initialized
DEBUG - 2014-02-03 21:08:49 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:08:49 --> Session routines successfully run
DEBUG - 2014-02-03 21:08:49 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:08:49 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 21:08:49 --> Final output sent to browser
DEBUG - 2014-02-03 21:08:49 --> Total execution time: 0.0140
DEBUG - 2014-02-03 21:08:51 --> Config Class Initialized
DEBUG - 2014-02-03 21:08:51 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:08:51 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:08:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:08:51 --> URI Class Initialized
DEBUG - 2014-02-03 21:08:51 --> Router Class Initialized
DEBUG - 2014-02-03 21:08:51 --> Output Class Initialized
DEBUG - 2014-02-03 21:08:51 --> Security Class Initialized
DEBUG - 2014-02-03 21:08:51 --> Input Class Initialized
DEBUG - 2014-02-03 21:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:08:51 --> Language Class Initialized
DEBUG - 2014-02-03 21:08:51 --> Loader Class Initialized
DEBUG - 2014-02-03 21:08:51 --> Controller Class Initialized
DEBUG - 2014-02-03 21:08:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:08:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:08:52 --> Model Class Initialized
DEBUG - 2014-02-03 21:08:52 --> Model Class Initialized
DEBUG - 2014-02-03 21:08:52 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:08:52 --> Model Class Initialized
DEBUG - 2014-02-03 21:08:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:08:52 --> Session Class Initialized
DEBUG - 2014-02-03 21:08:52 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:08:52 --> Session routines successfully run
DEBUG - 2014-02-03 21:08:52 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:08:52 --> Model Class Initialized
DEBUG - 2014-02-03 21:08:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:08:52 --> Final output sent to browser
DEBUG - 2014-02-03 21:08:52 --> Total execution time: 0.4260
DEBUG - 2014-02-03 21:08:53 --> Config Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:08:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:08:53 --> URI Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Router Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Output Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Security Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Input Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:08:53 --> Language Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Loader Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Controller Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:08:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:08:53 --> Model Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Model Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Model Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:08:53 --> Session Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:08:53 --> Session routines successfully run
DEBUG - 2014-02-03 21:08:53 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:08:53 --> Model Class Initialized
DEBUG - 2014-02-03 21:08:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:12:24 --> Config Class Initialized
DEBUG - 2014-02-03 21:12:24 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:12:24 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:12:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:12:24 --> URI Class Initialized
DEBUG - 2014-02-03 21:12:24 --> Router Class Initialized
DEBUG - 2014-02-03 21:12:24 --> Output Class Initialized
DEBUG - 2014-02-03 21:12:24 --> Security Class Initialized
DEBUG - 2014-02-03 21:12:24 --> Input Class Initialized
DEBUG - 2014-02-03 21:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:12:24 --> Language Class Initialized
DEBUG - 2014-02-03 21:12:24 --> Loader Class Initialized
DEBUG - 2014-02-03 21:12:24 --> Controller Class Initialized
DEBUG - 2014-02-03 21:12:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:12:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:12:24 --> Model Class Initialized
DEBUG - 2014-02-03 21:12:24 --> Model Class Initialized
DEBUG - 2014-02-03 21:12:24 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:12:24 --> Model Class Initialized
DEBUG - 2014-02-03 21:12:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:12:24 --> Session Class Initialized
DEBUG - 2014-02-03 21:12:24 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:12:24 --> Session routines successfully run
DEBUG - 2014-02-03 21:12:24 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:12:24 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 21:12:24 --> Final output sent to browser
DEBUG - 2014-02-03 21:12:24 --> Total execution time: 0.0290
DEBUG - 2014-02-03 21:12:26 --> Config Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:12:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:12:26 --> URI Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Router Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Output Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Security Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Input Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:12:26 --> Language Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Loader Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Controller Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:12:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:12:26 --> Model Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Model Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Model Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:12:26 --> Session Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:12:26 --> Session routines successfully run
DEBUG - 2014-02-03 21:12:26 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:12:26 --> Model Class Initialized
DEBUG - 2014-02-03 21:12:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:12:58 --> Final output sent to browser
DEBUG - 2014-02-03 21:12:58 --> Total execution time: 31.5278
DEBUG - 2014-02-03 21:13:16 --> Config Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:13:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:13:16 --> URI Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Router Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Output Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Security Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Input Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:13:16 --> Language Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Loader Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Controller Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:13:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:13:16 --> Session Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:13:16 --> Session routines successfully run
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:13:16 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 21:13:16 --> Final output sent to browser
DEBUG - 2014-02-03 21:13:16 --> Total execution time: 0.0210
DEBUG - 2014-02-03 21:13:16 --> Config Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:13:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:13:16 --> URI Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Config Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Router Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Output Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Security Class Initialized
DEBUG - 2014-02-03 21:13:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:13:16 --> Input Class Initialized
DEBUG - 2014-02-03 21:13:16 --> URI Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:13:16 --> Router Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Language Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Loader Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Output Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Controller Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Security Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:13:16 --> Input Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:13:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Language Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Loader Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Controller Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:13:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:13:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Session Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:13:16 --> Session routines successfully run
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:13:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:13:16 --> Session Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:13:16 --> Session routines successfully run
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:13:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:13:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:13:16 --> Final output sent to browser
DEBUG - 2014-02-03 21:13:16 --> Total execution time: 0.0150
DEBUG - 2014-02-03 21:13:16 --> Final output sent to browser
DEBUG - 2014-02-03 21:13:16 --> Total execution time: 0.0180
DEBUG - 2014-02-03 21:13:16 --> Config Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:13:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:13:16 --> URI Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Router Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Output Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Security Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Input Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:13:16 --> Language Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Loader Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Controller Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:13:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:13:16 --> Session Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:13:16 --> Session routines successfully run
DEBUG - 2014-02-03 21:13:16 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:13:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:13:16 --> Final output sent to browser
DEBUG - 2014-02-03 21:13:16 --> Total execution time: 0.0220
DEBUG - 2014-02-03 21:13:21 --> Config Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:13:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:13:21 --> URI Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Router Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Output Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Security Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Input Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:13:21 --> Language Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Loader Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Controller Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:13:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:13:21 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:13:21 --> Session Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:13:21 --> Session routines successfully run
DEBUG - 2014-02-03 21:13:21 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:13:21 --> Model Class Initialized
DEBUG - 2014-02-03 21:13:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:13:21 --> Final output sent to browser
DEBUG - 2014-02-03 21:13:21 --> Total execution time: 0.0230
DEBUG - 2014-02-03 21:20:29 --> Config Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:20:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:20:29 --> URI Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Router Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Output Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Security Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Input Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:20:29 --> Language Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Loader Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Controller Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:20:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:20:29 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:20:29 --> Session Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:20:29 --> Session routines successfully run
DEBUG - 2014-02-03 21:20:29 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:20:29 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 21:20:29 --> Final output sent to browser
DEBUG - 2014-02-03 21:20:29 --> Total execution time: 0.0420
DEBUG - 2014-02-03 21:20:29 --> Config Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:20:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:20:29 --> URI Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Router Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Output Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Config Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Security Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Input Class Initialized
DEBUG - 2014-02-03 21:20:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:20:29 --> URI Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Language Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Router Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Loader Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Output Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Controller Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Security Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:20:29 --> Input Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:20:29 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Language Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Loader Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Controller Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:20:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:20:29 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:20:29 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Session Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:20:29 --> Session routines successfully run
DEBUG - 2014-02-03 21:20:29 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:20:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:20:29 --> Session Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:20:29 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Session routines successfully run
DEBUG - 2014-02-03 21:20:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:20:29 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:20:29 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:20:29 --> Final output sent to browser
DEBUG - 2014-02-03 21:20:29 --> Total execution time: 0.0130
DEBUG - 2014-02-03 21:20:29 --> Final output sent to browser
DEBUG - 2014-02-03 21:20:29 --> Total execution time: 0.0160
DEBUG - 2014-02-03 21:20:34 --> Config Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Config Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:20:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:20:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:20:34 --> URI Class Initialized
DEBUG - 2014-02-03 21:20:34 --> URI Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Router Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Router Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Output Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Output Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Security Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Security Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Input Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Input Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:20:34 --> Language Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Language Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Loader Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Loader Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Controller Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Controller Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:20:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:20:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:20:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:20:34 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:20:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:20:34 --> Session Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Session Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:20:34 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:20:34 --> Session routines successfully run
DEBUG - 2014-02-03 21:20:34 --> Session routines successfully run
DEBUG - 2014-02-03 21:20:34 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:20:34 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:20:34 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Model Class Initialized
DEBUG - 2014-02-03 21:20:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:20:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:20:34 --> Final output sent to browser
DEBUG - 2014-02-03 21:20:34 --> Total execution time: 0.0270
DEBUG - 2014-02-03 21:20:34 --> Final output sent to browser
DEBUG - 2014-02-03 21:20:34 --> Total execution time: 0.0330
DEBUG - 2014-02-03 21:21:08 --> Config Class Initialized
DEBUG - 2014-02-03 21:21:08 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:21:08 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:21:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:21:08 --> URI Class Initialized
DEBUG - 2014-02-03 21:21:08 --> Router Class Initialized
DEBUG - 2014-02-03 21:21:08 --> Output Class Initialized
DEBUG - 2014-02-03 21:21:08 --> Security Class Initialized
DEBUG - 2014-02-03 21:21:08 --> Input Class Initialized
DEBUG - 2014-02-03 21:21:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:21:08 --> Language Class Initialized
DEBUG - 2014-02-03 21:21:08 --> Loader Class Initialized
DEBUG - 2014-02-03 21:21:08 --> Controller Class Initialized
DEBUG - 2014-02-03 21:21:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:21:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:21:08 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:08 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:08 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:21:08 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:08 --> Session Class Initialized
DEBUG - 2014-02-03 21:21:08 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:21:08 --> Session routines successfully run
DEBUG - 2014-02-03 21:21:08 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:21:08 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 21:21:08 --> Final output sent to browser
DEBUG - 2014-02-03 21:21:08 --> Total execution time: 0.0210
DEBUG - 2014-02-03 21:21:09 --> Config Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:21:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:21:09 --> Config Class Initialized
DEBUG - 2014-02-03 21:21:09 --> URI Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Router Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:21:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:21:09 --> URI Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Output Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Router Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Security Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Input Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Output Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:21:09 --> Security Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Input Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Language Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:21:09 --> Language Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Loader Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Controller Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Loader Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:21:09 --> Controller Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:21:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:21:09 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:21:09 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:09 --> Session Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Session Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:21:09 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:21:09 --> Session routines successfully run
DEBUG - 2014-02-03 21:21:09 --> Session routines successfully run
DEBUG - 2014-02-03 21:21:09 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:21:09 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:21:09 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:09 --> Final output sent to browser
DEBUG - 2014-02-03 21:21:09 --> Total execution time: 0.0140
DEBUG - 2014-02-03 21:21:09 --> Final output sent to browser
DEBUG - 2014-02-03 21:21:09 --> Total execution time: 0.0160
DEBUG - 2014-02-03 21:21:14 --> Config Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:21:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:21:14 --> URI Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Router Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Output Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Security Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Input Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Config Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:21:14 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Language Class Initialized
DEBUG - 2014-02-03 21:21:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:21:14 --> URI Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Loader Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Router Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Controller Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:21:14 --> Output Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:21:14 --> Security Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Input Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:21:14 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Language Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Loader Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Controller Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:21:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:21:14 --> Session Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:21:14 --> Session routines successfully run
DEBUG - 2014-02-03 21:21:14 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:21:14 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:14 --> Session Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:21:14 --> Session routines successfully run
DEBUG - 2014-02-03 21:21:14 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:21:14 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:14 --> Final output sent to browser
DEBUG - 2014-02-03 21:21:14 --> Total execution time: 0.0320
DEBUG - 2014-02-03 21:21:14 --> Final output sent to browser
DEBUG - 2014-02-03 21:21:14 --> Total execution time: 0.0350
DEBUG - 2014-02-03 21:21:14 --> Config Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:21:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:21:14 --> URI Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Router Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Output Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Security Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Input Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:21:14 --> Language Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Loader Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Controller Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:21:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:21:14 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:14 --> Session Class Initialized
DEBUG - 2014-02-03 21:21:14 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:21:14 --> Session routines successfully run
DEBUG - 2014-02-03 21:21:14 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:21:14 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 21:21:14 --> Final output sent to browser
DEBUG - 2014-02-03 21:21:14 --> Total execution time: 0.0210
DEBUG - 2014-02-03 21:21:15 --> Config Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:21:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:21:15 --> URI Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Router Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Output Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Security Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Input Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Config Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:21:15 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Language Class Initialized
DEBUG - 2014-02-03 21:21:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:21:15 --> URI Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Loader Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Router Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Controller Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:21:15 --> Output Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:21:15 --> Security Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Input Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:21:15 --> Language Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Loader Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Controller Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:21:15 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:21:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:15 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Session Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:21:15 --> Session routines successfully run
DEBUG - 2014-02-03 21:21:15 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:21:15 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:15 --> Session Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:21:15 --> Session routines successfully run
DEBUG - 2014-02-03 21:21:15 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:21:15 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:15 --> Final output sent to browser
DEBUG - 2014-02-03 21:21:15 --> Total execution time: 0.0150
DEBUG - 2014-02-03 21:21:15 --> Final output sent to browser
DEBUG - 2014-02-03 21:21:15 --> Total execution time: 0.0200
DEBUG - 2014-02-03 21:21:20 --> Config Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Config Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:21:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:21:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:21:20 --> URI Class Initialized
DEBUG - 2014-02-03 21:21:20 --> URI Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Router Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Router Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Output Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Output Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Security Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Security Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Input Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Input Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:21:20 --> Language Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Language Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Loader Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Loader Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Controller Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Controller Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:21:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:21:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:21:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:21:20 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:20 --> Session Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Session Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:21:20 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:21:20 --> Session routines successfully run
DEBUG - 2014-02-03 21:21:20 --> Session routines successfully run
DEBUG - 2014-02-03 21:21:20 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:21:20 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:21:20 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Model Class Initialized
DEBUG - 2014-02-03 21:21:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:21:20 --> Final output sent to browser
DEBUG - 2014-02-03 21:21:20 --> Total execution time: 0.0250
DEBUG - 2014-02-03 21:21:20 --> Final output sent to browser
DEBUG - 2014-02-03 21:21:20 --> Total execution time: 0.0370
DEBUG - 2014-02-03 21:22:35 --> Config Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:22:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:22:35 --> URI Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Router Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Output Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Security Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Input Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:22:35 --> Language Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Loader Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Controller Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:22:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:22:35 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:22:35 --> Session Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:22:35 --> Session routines successfully run
DEBUG - 2014-02-03 21:22:35 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:22:35 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:22:35 --> Final output sent to browser
DEBUG - 2014-02-03 21:22:35 --> Total execution time: 0.0210
DEBUG - 2014-02-03 21:22:38 --> Config Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:22:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:22:38 --> URI Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Router Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Output Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Security Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Input Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:22:38 --> Language Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Loader Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Controller Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:22:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:22:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:22:38 --> Session Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:22:38 --> Session routines successfully run
DEBUG - 2014-02-03 21:22:38 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:22:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:22:38 --> Final output sent to browser
DEBUG - 2014-02-03 21:22:38 --> Total execution time: 0.0230
DEBUG - 2014-02-03 21:22:40 --> Config Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:22:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:22:40 --> URI Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Router Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Output Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Security Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Input Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:22:40 --> Language Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Loader Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Controller Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:22:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:22:40 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:22:40 --> Session Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:22:40 --> Session routines successfully run
DEBUG - 2014-02-03 21:22:40 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:22:40 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:22:40 --> Final output sent to browser
DEBUG - 2014-02-03 21:22:40 --> Total execution time: 0.0220
DEBUG - 2014-02-03 21:22:53 --> Config Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:22:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:22:53 --> URI Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Router Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Output Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Security Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Input Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:22:53 --> Language Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Loader Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Controller Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:22:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:22:53 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:22:53 --> Session Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:22:53 --> Session routines successfully run
DEBUG - 2014-02-03 21:22:53 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:22:53 --> Model Class Initialized
DEBUG - 2014-02-03 21:22:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:22:53 --> Final output sent to browser
DEBUG - 2014-02-03 21:22:53 --> Total execution time: 0.0160
DEBUG - 2014-02-03 21:23:07 --> Config Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:23:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:23:07 --> URI Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Router Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Output Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Security Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Input Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:23:07 --> Language Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Loader Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Controller Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:23:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:23:07 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:23:07 --> Session Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:23:07 --> Session routines successfully run
DEBUG - 2014-02-03 21:23:07 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:23:07 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:23:07 --> Final output sent to browser
DEBUG - 2014-02-03 21:23:07 --> Total execution time: 0.0250
DEBUG - 2014-02-03 21:23:42 --> Config Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:23:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:23:42 --> URI Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Router Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Output Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Security Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Input Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:23:42 --> Language Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Loader Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Controller Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:23:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:23:42 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:23:42 --> Session Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:23:42 --> Session routines successfully run
DEBUG - 2014-02-03 21:23:42 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:23:42 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:23:42 --> Final output sent to browser
DEBUG - 2014-02-03 21:23:42 --> Total execution time: 0.0240
DEBUG - 2014-02-03 21:23:52 --> Config Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:23:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:23:52 --> URI Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Router Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Output Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Security Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Input Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:23:52 --> Language Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Loader Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Controller Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:23:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:23:52 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:23:52 --> Session Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:23:52 --> Session routines successfully run
DEBUG - 2014-02-03 21:23:52 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:23:52 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:23:52 --> Final output sent to browser
DEBUG - 2014-02-03 21:23:52 --> Total execution time: 0.0250
DEBUG - 2014-02-03 21:23:59 --> Config Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:23:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:23:59 --> URI Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Router Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Output Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Security Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Input Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:23:59 --> Language Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Loader Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Controller Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:23:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:23:59 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:23:59 --> Session Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:23:59 --> Session routines successfully run
DEBUG - 2014-02-03 21:23:59 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:23:59 --> Model Class Initialized
DEBUG - 2014-02-03 21:23:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:23:59 --> Final output sent to browser
DEBUG - 2014-02-03 21:23:59 --> Total execution time: 0.0210
DEBUG - 2014-02-03 21:24:11 --> Config Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:24:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:24:11 --> URI Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Router Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Output Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Security Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Input Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:24:11 --> Language Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Loader Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Controller Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:24:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:24:11 --> Model Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Model Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Model Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:24:11 --> Session Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:24:11 --> Session routines successfully run
DEBUG - 2014-02-03 21:24:11 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:24:11 --> Model Class Initialized
DEBUG - 2014-02-03 21:24:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:24:11 --> Final output sent to browser
DEBUG - 2014-02-03 21:24:11 --> Total execution time: 0.0250
DEBUG - 2014-02-03 21:24:19 --> Config Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:24:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:24:19 --> URI Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Router Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Output Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Security Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Input Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:24:19 --> Language Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Loader Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Controller Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:24:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:24:19 --> Model Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Model Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Model Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:24:19 --> Session Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:24:19 --> Session routines successfully run
DEBUG - 2014-02-03 21:24:19 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:24:19 --> Model Class Initialized
DEBUG - 2014-02-03 21:24:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:24:19 --> Final output sent to browser
DEBUG - 2014-02-03 21:24:19 --> Total execution time: 0.0140
DEBUG - 2014-02-03 21:24:24 --> Config Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:24:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:24:24 --> URI Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Router Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Output Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Security Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Input Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:24:24 --> Language Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Loader Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Controller Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:24:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:24:24 --> Model Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Model Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Model Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:24:24 --> Session Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:24:24 --> Session routines successfully run
DEBUG - 2014-02-03 21:24:24 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:24:24 --> Model Class Initialized
DEBUG - 2014-02-03 21:24:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:24:24 --> Final output sent to browser
DEBUG - 2014-02-03 21:24:24 --> Total execution time: 0.0260
DEBUG - 2014-02-03 21:25:34 --> Config Class Initialized
DEBUG - 2014-02-03 21:25:34 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:25:34 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:25:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:25:34 --> URI Class Initialized
DEBUG - 2014-02-03 21:25:34 --> Router Class Initialized
DEBUG - 2014-02-03 21:25:34 --> Output Class Initialized
DEBUG - 2014-02-03 21:25:34 --> Security Class Initialized
DEBUG - 2014-02-03 21:25:34 --> Input Class Initialized
DEBUG - 2014-02-03 21:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:25:34 --> Language Class Initialized
DEBUG - 2014-02-03 21:25:34 --> Loader Class Initialized
DEBUG - 2014-02-03 21:25:34 --> Controller Class Initialized
DEBUG - 2014-02-03 21:25:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:25:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:25:34 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:34 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:34 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:25:34 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:34 --> Session Class Initialized
DEBUG - 2014-02-03 21:25:34 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:25:34 --> Session routines successfully run
DEBUG - 2014-02-03 21:25:34 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:25:34 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 21:25:34 --> Final output sent to browser
DEBUG - 2014-02-03 21:25:34 --> Total execution time: 0.0220
DEBUG - 2014-02-03 21:25:36 --> Config Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:25:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:25:36 --> URI Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Router Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Config Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Output Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Security Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:25:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:25:36 --> Input Class Initialized
DEBUG - 2014-02-03 21:25:36 --> URI Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:25:36 --> Router Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Language Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Output Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Loader Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Controller Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Security Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Input Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:25:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:25:36 --> Language Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Loader Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Controller Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:25:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:25:36 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:36 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Session Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:25:36 --> Session routines successfully run
DEBUG - 2014-02-03 21:25:36 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:25:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:36 --> Session Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:25:36 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Session routines successfully run
DEBUG - 2014-02-03 21:25:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:36 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:25:36 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:36 --> Final output sent to browser
DEBUG - 2014-02-03 21:25:36 --> Total execution time: 0.0130
DEBUG - 2014-02-03 21:25:36 --> Final output sent to browser
DEBUG - 2014-02-03 21:25:36 --> Total execution time: 0.0150
DEBUG - 2014-02-03 21:25:41 --> Config Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:25:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:25:41 --> URI Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Router Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Output Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Config Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Security Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Input Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:25:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:25:41 --> URI Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Language Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Router Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Loader Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Output Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Controller Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Security Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:25:41 --> Input Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:25:41 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Language Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Loader Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Controller Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:25:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:25:41 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:41 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Session Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:25:41 --> Session routines successfully run
DEBUG - 2014-02-03 21:25:41 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:25:41 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:41 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Session Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:41 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:25:41 --> Session routines successfully run
DEBUG - 2014-02-03 21:25:41 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:25:41 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:41 --> Final output sent to browser
DEBUG - 2014-02-03 21:25:41 --> Total execution time: 0.0330
DEBUG - 2014-02-03 21:25:41 --> Final output sent to browser
DEBUG - 2014-02-03 21:25:41 --> Total execution time: 0.0390
DEBUG - 2014-02-03 21:25:45 --> Config Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:25:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:25:45 --> URI Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Router Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Output Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Security Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Input Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:25:45 --> Language Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Loader Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Controller Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:25:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:25:45 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:45 --> Session Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:25:45 --> Session routines successfully run
DEBUG - 2014-02-03 21:25:45 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:25:45 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:45 --> Final output sent to browser
DEBUG - 2014-02-03 21:25:45 --> Total execution time: 0.0230
DEBUG - 2014-02-03 21:25:49 --> Config Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:25:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:25:49 --> URI Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Router Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Output Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Security Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Input Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:25:49 --> Language Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Loader Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Controller Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:25:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:25:49 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:49 --> Session Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:25:49 --> Session routines successfully run
DEBUG - 2014-02-03 21:25:49 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:25:49 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:49 --> Final output sent to browser
DEBUG - 2014-02-03 21:25:49 --> Total execution time: 0.0150
DEBUG - 2014-02-03 21:25:51 --> Config Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:25:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:25:51 --> URI Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Router Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Output Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Security Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Input Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:25:51 --> Language Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Loader Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Controller Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:25:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:25:51 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:51 --> Session Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:25:51 --> Session routines successfully run
DEBUG - 2014-02-03 21:25:51 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:25:51 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:51 --> Final output sent to browser
DEBUG - 2014-02-03 21:25:51 --> Total execution time: 0.0220
DEBUG - 2014-02-03 21:25:56 --> Config Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:25:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:25:56 --> URI Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Router Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Output Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Security Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Input Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:25:56 --> Language Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Loader Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Controller Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:25:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:25:56 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:56 --> Session Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:25:56 --> Session routines successfully run
DEBUG - 2014-02-03 21:25:56 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:25:56 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:56 --> Final output sent to browser
DEBUG - 2014-02-03 21:25:56 --> Total execution time: 0.0260
DEBUG - 2014-02-03 21:25:57 --> Config Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:25:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:25:57 --> URI Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Router Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Output Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Security Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Input Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:25:57 --> Language Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Loader Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Controller Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:25:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:25:57 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:57 --> Session Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:25:57 --> Session routines successfully run
DEBUG - 2014-02-03 21:25:57 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:25:57 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:57 --> Final output sent to browser
DEBUG - 2014-02-03 21:25:57 --> Total execution time: 0.0240
DEBUG - 2014-02-03 21:25:58 --> Config Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:25:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:25:58 --> URI Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Router Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Output Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Security Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Input Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:25:58 --> Language Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Loader Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Controller Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:25:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:25:58 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:58 --> Session Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:25:58 --> Session routines successfully run
DEBUG - 2014-02-03 21:25:58 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:25:58 --> Model Class Initialized
DEBUG - 2014-02-03 21:25:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:25:58 --> Final output sent to browser
DEBUG - 2014-02-03 21:25:58 --> Total execution time: 0.0140
DEBUG - 2014-02-03 21:26:02 --> Config Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:26:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:26:02 --> URI Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Router Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Output Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Security Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Input Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:26:02 --> Language Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Loader Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Controller Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:26:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:26:02 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:26:02 --> Session Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:26:02 --> Session routines successfully run
DEBUG - 2014-02-03 21:26:02 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:26:02 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:26:02 --> Final output sent to browser
DEBUG - 2014-02-03 21:26:02 --> Total execution time: 0.0240
DEBUG - 2014-02-03 21:26:43 --> Config Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:26:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:26:43 --> URI Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Router Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Output Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Security Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Input Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:26:43 --> Language Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Loader Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Controller Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:26:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:26:43 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:26:43 --> Session Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:26:43 --> Session routines successfully run
DEBUG - 2014-02-03 21:26:43 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:26:43 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:26:43 --> Final output sent to browser
DEBUG - 2014-02-03 21:26:43 --> Total execution time: 0.0210
DEBUG - 2014-02-03 21:26:44 --> Config Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:26:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:26:44 --> URI Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Router Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Output Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Security Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Input Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:26:44 --> Language Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Loader Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Controller Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:26:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:26:44 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:26:44 --> Session Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:26:44 --> Session routines successfully run
DEBUG - 2014-02-03 21:26:44 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:26:44 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:26:44 --> Final output sent to browser
DEBUG - 2014-02-03 21:26:44 --> Total execution time: 0.0260
DEBUG - 2014-02-03 21:26:47 --> Config Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:26:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:26:47 --> URI Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Router Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Output Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Security Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Input Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:26:47 --> Language Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Loader Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Controller Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:26:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:26:47 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:26:47 --> Session Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:26:47 --> Session routines successfully run
DEBUG - 2014-02-03 21:26:47 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:26:47 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:26:47 --> Final output sent to browser
DEBUG - 2014-02-03 21:26:47 --> Total execution time: 0.0260
DEBUG - 2014-02-03 21:26:49 --> Config Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:26:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:26:49 --> URI Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Router Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Output Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Security Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Input Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:26:49 --> Language Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Loader Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Controller Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:26:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:26:49 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:26:49 --> Session Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:26:49 --> Session routines successfully run
DEBUG - 2014-02-03 21:26:49 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:26:49 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:26:49 --> Final output sent to browser
DEBUG - 2014-02-03 21:26:49 --> Total execution time: 0.0240
DEBUG - 2014-02-03 21:26:51 --> Config Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:26:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:26:51 --> URI Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Router Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Output Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Security Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Input Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:26:51 --> Language Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Loader Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Controller Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:26:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:26:51 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:26:51 --> Session Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:26:51 --> Session routines successfully run
DEBUG - 2014-02-03 21:26:51 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:26:51 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:26:51 --> Final output sent to browser
DEBUG - 2014-02-03 21:26:51 --> Total execution time: 0.0230
DEBUG - 2014-02-03 21:26:55 --> Config Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:26:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:26:55 --> URI Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Router Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Output Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Security Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Input Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:26:55 --> Language Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Loader Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Controller Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:26:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:26:55 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:26:55 --> Session Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:26:55 --> Session routines successfully run
DEBUG - 2014-02-03 21:26:55 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:26:55 --> Model Class Initialized
DEBUG - 2014-02-03 21:26:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:26:55 --> Final output sent to browser
DEBUG - 2014-02-03 21:26:55 --> Total execution time: 0.0270
DEBUG - 2014-02-03 21:27:03 --> Config Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:27:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:27:03 --> URI Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Router Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Output Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Security Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Input Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:27:03 --> Language Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Loader Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Controller Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:27:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:27:03 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:27:03 --> Session Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:27:03 --> Session routines successfully run
DEBUG - 2014-02-03 21:27:03 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:27:03 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:27:03 --> Final output sent to browser
DEBUG - 2014-02-03 21:27:03 --> Total execution time: 0.0180
DEBUG - 2014-02-03 21:27:12 --> Config Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:27:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:27:12 --> URI Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Router Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Output Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Security Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Input Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:27:12 --> Language Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Loader Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Controller Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:27:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:27:12 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:27:12 --> Session Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:27:12 --> Session routines successfully run
DEBUG - 2014-02-03 21:27:12 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:27:12 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:27:12 --> Final output sent to browser
DEBUG - 2014-02-03 21:27:12 --> Total execution time: 0.0150
DEBUG - 2014-02-03 21:27:16 --> Config Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:27:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:27:16 --> URI Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Router Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Output Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Security Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Input Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:27:16 --> Language Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Loader Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Controller Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:27:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:27:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:27:16 --> Session Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:27:16 --> Session routines successfully run
DEBUG - 2014-02-03 21:27:16 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:27:16 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:27:16 --> Final output sent to browser
DEBUG - 2014-02-03 21:27:16 --> Total execution time: 0.0270
DEBUG - 2014-02-03 21:27:24 --> Config Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:27:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:27:24 --> URI Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Router Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Output Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Security Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Input Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:27:24 --> Language Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Loader Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Controller Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:27:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:27:24 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:27:24 --> Session Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:27:24 --> Session routines successfully run
DEBUG - 2014-02-03 21:27:24 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:27:24 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:27:24 --> Final output sent to browser
DEBUG - 2014-02-03 21:27:24 --> Total execution time: 0.0260
DEBUG - 2014-02-03 21:27:35 --> Config Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:27:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:27:35 --> URI Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Router Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Output Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Security Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Input Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:27:35 --> Language Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Loader Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Controller Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:27:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:27:35 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:27:35 --> Session Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:27:35 --> Session routines successfully run
DEBUG - 2014-02-03 21:27:35 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:27:35 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:27:35 --> Final output sent to browser
DEBUG - 2014-02-03 21:27:35 --> Total execution time: 0.0260
DEBUG - 2014-02-03 21:27:52 --> Config Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:27:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:27:52 --> URI Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Router Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Output Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Security Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Input Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:27:52 --> Language Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Loader Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Controller Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:27:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:27:52 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:27:52 --> Session Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:27:52 --> Session routines successfully run
DEBUG - 2014-02-03 21:27:52 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:27:52 --> Model Class Initialized
DEBUG - 2014-02-03 21:27:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:27:52 --> Final output sent to browser
DEBUG - 2014-02-03 21:27:52 --> Total execution time: 0.0250
DEBUG - 2014-02-03 21:28:00 --> Config Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:28:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:28:00 --> URI Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Router Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Output Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Security Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Input Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:28:00 --> Language Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Loader Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Controller Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:28:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:28:00 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:00 --> Session Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:28:00 --> Session routines successfully run
DEBUG - 2014-02-03 21:28:00 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:28:00 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:00 --> Final output sent to browser
DEBUG - 2014-02-03 21:28:00 --> Total execution time: 0.0220
DEBUG - 2014-02-03 21:28:01 --> Config Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:28:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:28:01 --> URI Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Router Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Output Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Security Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Input Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:28:01 --> Language Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Loader Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Controller Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:28:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:28:01 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:01 --> Session Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:28:01 --> Session routines successfully run
DEBUG - 2014-02-03 21:28:01 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:28:01 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:01 --> Final output sent to browser
DEBUG - 2014-02-03 21:28:01 --> Total execution time: 0.0200
DEBUG - 2014-02-03 21:28:08 --> Config Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:28:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:28:08 --> URI Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Router Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Output Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Security Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Input Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:28:08 --> Language Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Loader Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Controller Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:28:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:28:08 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:08 --> Session Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:28:08 --> Session routines successfully run
DEBUG - 2014-02-03 21:28:08 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:28:08 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:08 --> Final output sent to browser
DEBUG - 2014-02-03 21:28:08 --> Total execution time: 0.0150
DEBUG - 2014-02-03 21:28:14 --> Config Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:28:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:28:14 --> URI Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Router Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Output Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Security Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Input Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:28:14 --> Language Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Loader Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Controller Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:28:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:28:14 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:14 --> Session Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:28:14 --> Session routines successfully run
DEBUG - 2014-02-03 21:28:14 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:28:14 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:14 --> Final output sent to browser
DEBUG - 2014-02-03 21:28:14 --> Total execution time: 0.0330
DEBUG - 2014-02-03 21:28:17 --> Config Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:28:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:28:17 --> URI Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Router Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Output Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Security Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Input Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:28:17 --> Language Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Loader Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Controller Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:28:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:28:17 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:17 --> Session Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:28:17 --> Session routines successfully run
DEBUG - 2014-02-03 21:28:17 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:28:17 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:17 --> Final output sent to browser
DEBUG - 2014-02-03 21:28:17 --> Total execution time: 0.0390
DEBUG - 2014-02-03 21:28:25 --> Config Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:28:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:28:25 --> URI Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Router Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Output Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Security Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Input Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:28:25 --> Language Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Loader Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Controller Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:28:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:28:25 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:25 --> Session Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:28:25 --> Session routines successfully run
DEBUG - 2014-02-03 21:28:25 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:28:25 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:25 --> Final output sent to browser
DEBUG - 2014-02-03 21:28:25 --> Total execution time: 0.0400
DEBUG - 2014-02-03 21:28:27 --> Config Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:28:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:28:27 --> URI Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Router Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Output Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Security Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Input Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:28:27 --> Language Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Loader Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Controller Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:28:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:28:27 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:27 --> Session Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:28:27 --> Session routines successfully run
DEBUG - 2014-02-03 21:28:27 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:28:27 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:27 --> Final output sent to browser
DEBUG - 2014-02-03 21:28:27 --> Total execution time: 0.0290
DEBUG - 2014-02-03 21:28:29 --> Config Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:28:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:28:29 --> URI Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Router Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Output Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Security Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Input Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:28:29 --> Language Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Loader Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Controller Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:28:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:28:29 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:29 --> Session Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:28:29 --> Session routines successfully run
DEBUG - 2014-02-03 21:28:29 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:28:29 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:29 --> Final output sent to browser
DEBUG - 2014-02-03 21:28:29 --> Total execution time: 0.0310
DEBUG - 2014-02-03 21:28:37 --> Config Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:28:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:28:37 --> URI Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Router Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Output Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Security Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Input Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:28:37 --> Language Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Loader Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Controller Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:28:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:28:37 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:37 --> Session Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:28:37 --> Session routines successfully run
DEBUG - 2014-02-03 21:28:37 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:28:37 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:37 --> Final output sent to browser
DEBUG - 2014-02-03 21:28:37 --> Total execution time: 0.0220
DEBUG - 2014-02-03 21:28:39 --> Config Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:28:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:28:39 --> URI Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Router Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Output Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Security Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Input Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:28:39 --> Language Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Loader Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Controller Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:28:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:28:39 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:39 --> Session Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:28:39 --> Session routines successfully run
DEBUG - 2014-02-03 21:28:39 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:28:39 --> Model Class Initialized
DEBUG - 2014-02-03 21:28:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:28:39 --> Final output sent to browser
DEBUG - 2014-02-03 21:28:39 --> Total execution time: 0.0250
DEBUG - 2014-02-03 21:57:37 --> Config Class Initialized
DEBUG - 2014-02-03 21:57:37 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:57:37 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:57:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:57:37 --> URI Class Initialized
DEBUG - 2014-02-03 21:57:37 --> Router Class Initialized
DEBUG - 2014-02-03 21:57:37 --> Output Class Initialized
DEBUG - 2014-02-03 21:57:37 --> Security Class Initialized
DEBUG - 2014-02-03 21:57:37 --> Input Class Initialized
DEBUG - 2014-02-03 21:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:57:37 --> Language Class Initialized
DEBUG - 2014-02-03 21:57:37 --> Loader Class Initialized
DEBUG - 2014-02-03 21:57:37 --> Controller Class Initialized
DEBUG - 2014-02-03 21:57:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:57:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:57:37 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:37 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:37 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:57:37 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:57:37 --> Session Class Initialized
DEBUG - 2014-02-03 21:57:37 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:57:37 --> Session routines successfully run
DEBUG - 2014-02-03 21:57:37 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:57:37 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-03 21:57:37 --> Final output sent to browser
DEBUG - 2014-02-03 21:57:37 --> Total execution time: 0.0220
DEBUG - 2014-02-03 21:57:38 --> Config Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Config Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:57:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:57:38 --> Config Class Initialized
DEBUG - 2014-02-03 21:57:38 --> URI Class Initialized
DEBUG - 2014-02-03 21:57:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:57:38 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:57:38 --> URI Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Router Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Router Class Initialized
DEBUG - 2014-02-03 21:57:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:57:38 --> Output Class Initialized
DEBUG - 2014-02-03 21:57:38 --> URI Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Output Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Security Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Router Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Security Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Input Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Input Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Output Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:57:38 --> Language Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Security Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Language Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Input Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Loader Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Loader Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Controller Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:57:38 --> Controller Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:57:38 --> Language Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:57:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:57:38 --> Loader Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:57:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Controller Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:57:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:57:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:57:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:57:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Session Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:57:38 --> Session Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:57:38 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:57:38 --> Session Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Session routines successfully run
DEBUG - 2014-02-03 21:57:38 --> Session routines successfully run
DEBUG - 2014-02-03 21:57:38 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:57:38 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:57:38 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:57:38 --> Session routines successfully run
DEBUG - 2014-02-03 21:57:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:57:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:57:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:57:38 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:57:38 --> Final output sent to browser
DEBUG - 2014-02-03 21:57:38 --> Total execution time: 0.0150
DEBUG - 2014-02-03 21:57:38 --> Final output sent to browser
DEBUG - 2014-02-03 21:57:38 --> Total execution time: 0.0200
DEBUG - 2014-02-03 21:57:38 --> Final output sent to browser
DEBUG - 2014-02-03 21:57:38 --> Total execution time: 0.0330
DEBUG - 2014-02-03 21:57:43 --> Config Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:57:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:57:43 --> URI Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Router Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Output Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Security Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Input Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:57:43 --> Language Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Loader Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Controller Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:57:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:57:43 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:57:43 --> Session Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:57:43 --> Session routines successfully run
DEBUG - 2014-02-03 21:57:43 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:57:43 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:57:43 --> Final output sent to browser
DEBUG - 2014-02-03 21:57:43 --> Total execution time: 0.0160
DEBUG - 2014-02-03 21:57:56 --> Config Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:57:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:57:56 --> URI Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Router Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Output Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Security Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Input Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:57:56 --> Language Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Loader Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Controller Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:57:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:57:56 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:57:56 --> Session Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:57:56 --> Session routines successfully run
DEBUG - 2014-02-03 21:57:56 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:57:56 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-03 21:57:56 --> Final output sent to browser
DEBUG - 2014-02-03 21:57:56 --> Total execution time: 0.0200
DEBUG - 2014-02-03 21:57:56 --> Config Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Hooks Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Utf8 Class Initialized
DEBUG - 2014-02-03 21:57:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 21:57:56 --> URI Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Router Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Output Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Security Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Input Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 21:57:56 --> Language Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Loader Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Controller Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 21:57:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 21:57:56 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Database Driver Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Model Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 21:57:56 --> Session Class Initialized
DEBUG - 2014-02-03 21:57:56 --> Helper loaded: string_helper
DEBUG - 2014-02-03 21:57:56 --> Session routines successfully run
DEBUG - 2014-02-03 21:57:56 --> Helper loaded: url_helper
DEBUG - 2014-02-03 21:57:56 --> Final output sent to browser
DEBUG - 2014-02-03 21:57:56 --> Total execution time: 0.0100
DEBUG - 2014-02-03 22:39:12 --> Config Class Initialized
DEBUG - 2014-02-03 22:39:12 --> Hooks Class Initialized
DEBUG - 2014-02-03 22:39:12 --> Utf8 Class Initialized
DEBUG - 2014-02-03 22:39:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 22:39:12 --> URI Class Initialized
DEBUG - 2014-02-03 22:39:12 --> Router Class Initialized
DEBUG - 2014-02-03 22:39:12 --> Output Class Initialized
DEBUG - 2014-02-03 22:39:12 --> Security Class Initialized
DEBUG - 2014-02-03 22:39:12 --> Input Class Initialized
DEBUG - 2014-02-03 22:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 22:39:12 --> Language Class Initialized
DEBUG - 2014-02-03 22:39:12 --> Loader Class Initialized
DEBUG - 2014-02-03 22:39:12 --> Controller Class Initialized
DEBUG - 2014-02-03 22:39:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 22:39:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 22:39:12 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:12 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:12 --> Database Driver Class Initialized
DEBUG - 2014-02-03 22:39:12 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 22:39:12 --> Session Class Initialized
DEBUG - 2014-02-03 22:39:12 --> Helper loaded: string_helper
DEBUG - 2014-02-03 22:39:12 --> Session routines successfully run
DEBUG - 2014-02-03 22:39:12 --> Helper loaded: url_helper
DEBUG - 2014-02-03 22:39:15 --> Config Class Initialized
DEBUG - 2014-02-03 22:39:15 --> Hooks Class Initialized
DEBUG - 2014-02-03 22:39:15 --> Utf8 Class Initialized
DEBUG - 2014-02-03 22:39:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 22:39:15 --> URI Class Initialized
DEBUG - 2014-02-03 22:39:15 --> Router Class Initialized
DEBUG - 2014-02-03 22:39:15 --> Output Class Initialized
DEBUG - 2014-02-03 22:39:15 --> Security Class Initialized
DEBUG - 2014-02-03 22:39:15 --> Input Class Initialized
DEBUG - 2014-02-03 22:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 22:39:15 --> Language Class Initialized
DEBUG - 2014-02-03 22:39:15 --> Loader Class Initialized
DEBUG - 2014-02-03 22:39:15 --> Controller Class Initialized
DEBUG - 2014-02-03 22:39:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 22:39:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 22:39:15 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:15 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:15 --> Database Driver Class Initialized
DEBUG - 2014-02-03 22:39:15 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 22:39:15 --> Session Class Initialized
DEBUG - 2014-02-03 22:39:15 --> Helper loaded: string_helper
DEBUG - 2014-02-03 22:39:15 --> Session routines successfully run
DEBUG - 2014-02-03 22:39:15 --> Helper loaded: url_helper
DEBUG - 2014-02-03 22:39:32 --> Config Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Hooks Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Utf8 Class Initialized
DEBUG - 2014-02-03 22:39:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 22:39:32 --> URI Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Router Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Output Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Security Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Input Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 22:39:32 --> Language Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Loader Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Controller Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 22:39:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 22:39:32 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Database Driver Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 22:39:32 --> Session Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Helper loaded: string_helper
DEBUG - 2014-02-03 22:39:32 --> Session routines successfully run
DEBUG - 2014-02-03 22:39:32 --> Helper loaded: url_helper
DEBUG - 2014-02-03 22:39:32 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 22:39:32 --> Final output sent to browser
DEBUG - 2014-02-03 22:39:32 --> Total execution time: 0.0190
DEBUG - 2014-02-03 22:39:32 --> Config Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Hooks Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Utf8 Class Initialized
DEBUG - 2014-02-03 22:39:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 22:39:32 --> URI Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Router Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Output Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Security Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Input Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 22:39:32 --> Language Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Loader Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Controller Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 22:39:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 22:39:32 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Database Driver Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 22:39:32 --> Session Class Initialized
DEBUG - 2014-02-03 22:39:32 --> Helper loaded: string_helper
DEBUG - 2014-02-03 22:39:32 --> Session routines successfully run
DEBUG - 2014-02-03 22:39:32 --> Helper loaded: url_helper
ERROR - 2014-02-03 22:39:32 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 22:39:37 --> Config Class Initialized
DEBUG - 2014-02-03 22:39:37 --> Hooks Class Initialized
DEBUG - 2014-02-03 22:39:37 --> Utf8 Class Initialized
DEBUG - 2014-02-03 22:39:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 22:39:37 --> URI Class Initialized
DEBUG - 2014-02-03 22:39:37 --> Router Class Initialized
DEBUG - 2014-02-03 22:39:37 --> Output Class Initialized
DEBUG - 2014-02-03 22:39:37 --> Security Class Initialized
DEBUG - 2014-02-03 22:39:37 --> Input Class Initialized
DEBUG - 2014-02-03 22:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 22:39:37 --> Language Class Initialized
DEBUG - 2014-02-03 22:39:37 --> Loader Class Initialized
DEBUG - 2014-02-03 22:39:37 --> Controller Class Initialized
DEBUG - 2014-02-03 22:39:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 22:39:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 22:39:37 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:37 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:37 --> Database Driver Class Initialized
DEBUG - 2014-02-03 22:39:37 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 22:39:37 --> Session Class Initialized
DEBUG - 2014-02-03 22:39:37 --> Helper loaded: string_helper
DEBUG - 2014-02-03 22:39:37 --> Session routines successfully run
DEBUG - 2014-02-03 22:39:37 --> Helper loaded: url_helper
ERROR - 2014-02-03 22:39:37 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 22:39:57 --> Config Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Hooks Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Utf8 Class Initialized
DEBUG - 2014-02-03 22:39:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 22:39:57 --> URI Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Router Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Output Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Security Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Input Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 22:39:57 --> Language Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Loader Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Controller Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 22:39:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 22:39:57 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Database Driver Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 22:39:57 --> Session Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Helper loaded: string_helper
DEBUG - 2014-02-03 22:39:57 --> Session routines successfully run
DEBUG - 2014-02-03 22:39:57 --> Helper loaded: url_helper
DEBUG - 2014-02-03 22:39:57 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 22:39:57 --> Final output sent to browser
DEBUG - 2014-02-03 22:39:57 --> Total execution time: 0.0180
DEBUG - 2014-02-03 22:39:57 --> Config Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Hooks Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Utf8 Class Initialized
DEBUG - 2014-02-03 22:39:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 22:39:57 --> URI Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Router Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Output Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Security Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Input Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 22:39:57 --> Language Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Loader Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Controller Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 22:39:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 22:39:57 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Database Driver Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Model Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 22:39:57 --> Session Class Initialized
DEBUG - 2014-02-03 22:39:57 --> Helper loaded: string_helper
DEBUG - 2014-02-03 22:39:57 --> Session routines successfully run
DEBUG - 2014-02-03 22:39:57 --> Helper loaded: url_helper
ERROR - 2014-02-03 22:39:57 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 22:40:02 --> Config Class Initialized
DEBUG - 2014-02-03 22:40:02 --> Hooks Class Initialized
DEBUG - 2014-02-03 22:40:02 --> Utf8 Class Initialized
DEBUG - 2014-02-03 22:40:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 22:40:02 --> URI Class Initialized
DEBUG - 2014-02-03 22:40:02 --> Router Class Initialized
DEBUG - 2014-02-03 22:40:02 --> Output Class Initialized
DEBUG - 2014-02-03 22:40:02 --> Security Class Initialized
DEBUG - 2014-02-03 22:40:02 --> Input Class Initialized
DEBUG - 2014-02-03 22:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 22:40:02 --> Language Class Initialized
DEBUG - 2014-02-03 22:40:02 --> Loader Class Initialized
DEBUG - 2014-02-03 22:40:02 --> Controller Class Initialized
DEBUG - 2014-02-03 22:40:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 22:40:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 22:40:02 --> Model Class Initialized
DEBUG - 2014-02-03 22:40:02 --> Model Class Initialized
DEBUG - 2014-02-03 22:40:02 --> Database Driver Class Initialized
DEBUG - 2014-02-03 22:40:02 --> Model Class Initialized
DEBUG - 2014-02-03 22:40:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 22:40:02 --> Session Class Initialized
DEBUG - 2014-02-03 22:40:02 --> Helper loaded: string_helper
DEBUG - 2014-02-03 22:40:02 --> Session routines successfully run
DEBUG - 2014-02-03 22:40:02 --> Helper loaded: url_helper
ERROR - 2014-02-03 22:40:02 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 22:40:16 --> Config Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Hooks Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Utf8 Class Initialized
DEBUG - 2014-02-03 22:40:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 22:40:16 --> URI Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Router Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Output Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Security Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Input Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 22:40:16 --> Language Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Loader Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Controller Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 22:40:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 22:40:16 --> Model Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Model Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Database Driver Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Model Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 22:40:16 --> Session Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Helper loaded: string_helper
DEBUG - 2014-02-03 22:40:16 --> Session routines successfully run
DEBUG - 2014-02-03 22:40:16 --> Helper loaded: url_helper
DEBUG - 2014-02-03 22:40:16 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 22:40:16 --> Final output sent to browser
DEBUG - 2014-02-03 22:40:16 --> Total execution time: 0.0140
DEBUG - 2014-02-03 22:40:16 --> Config Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Hooks Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Utf8 Class Initialized
DEBUG - 2014-02-03 22:40:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 22:40:16 --> URI Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Router Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Output Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Security Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Input Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 22:40:16 --> Language Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Loader Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Controller Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 22:40:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 22:40:16 --> Model Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Model Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Database Driver Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Model Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 22:40:16 --> Session Class Initialized
DEBUG - 2014-02-03 22:40:16 --> Helper loaded: string_helper
DEBUG - 2014-02-03 22:40:16 --> Session routines successfully run
DEBUG - 2014-02-03 22:40:16 --> Helper loaded: url_helper
ERROR - 2014-02-03 22:40:16 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 22:40:26 --> Config Class Initialized
DEBUG - 2014-02-03 22:40:26 --> Hooks Class Initialized
DEBUG - 2014-02-03 22:40:26 --> Utf8 Class Initialized
DEBUG - 2014-02-03 22:40:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 22:40:26 --> URI Class Initialized
DEBUG - 2014-02-03 22:40:26 --> Router Class Initialized
DEBUG - 2014-02-03 22:40:26 --> Output Class Initialized
DEBUG - 2014-02-03 22:40:26 --> Security Class Initialized
DEBUG - 2014-02-03 22:40:26 --> Input Class Initialized
DEBUG - 2014-02-03 22:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 22:40:26 --> Language Class Initialized
DEBUG - 2014-02-03 22:40:26 --> Loader Class Initialized
DEBUG - 2014-02-03 22:40:26 --> Controller Class Initialized
DEBUG - 2014-02-03 22:40:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 22:40:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 22:40:26 --> Model Class Initialized
DEBUG - 2014-02-03 22:40:26 --> Model Class Initialized
DEBUG - 2014-02-03 22:40:26 --> Database Driver Class Initialized
DEBUG - 2014-02-03 22:40:26 --> Model Class Initialized
DEBUG - 2014-02-03 22:40:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 22:40:26 --> Session Class Initialized
DEBUG - 2014-02-03 22:40:26 --> Helper loaded: string_helper
DEBUG - 2014-02-03 22:40:26 --> Session routines successfully run
DEBUG - 2014-02-03 22:40:26 --> Helper loaded: url_helper
ERROR - 2014-02-03 22:40:26 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:15:53 --> Config Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:15:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:15:53 --> URI Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Router Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Output Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Security Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Input Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:15:53 --> Language Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Loader Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Controller Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:15:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:15:53 --> Model Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Model Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Model Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:15:53 --> Session Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:15:53 --> Session routines successfully run
DEBUG - 2014-02-03 23:15:53 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:15:53 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-03 23:15:53 --> Final output sent to browser
DEBUG - 2014-02-03 23:15:53 --> Total execution time: 0.0250
DEBUG - 2014-02-03 23:15:53 --> Config Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:15:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:15:53 --> URI Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Router Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Output Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Security Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Input Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:15:53 --> Language Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Loader Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Controller Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:15:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:15:53 --> Model Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Model Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Model Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:15:53 --> Session Class Initialized
DEBUG - 2014-02-03 23:15:53 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:15:53 --> Session routines successfully run
DEBUG - 2014-02-03 23:15:53 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:15:53 --> Final output sent to browser
DEBUG - 2014-02-03 23:15:53 --> Total execution time: 0.0100
DEBUG - 2014-02-03 23:25:21 --> Config Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:25:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:25:21 --> URI Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Router Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Output Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Security Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Input Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:25:21 --> Language Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Loader Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Controller Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:25:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:25:21 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:25:21 --> Session Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:25:21 --> Session routines successfully run
DEBUG - 2014-02-03 23:25:21 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:25:21 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:25:21 --> Final output sent to browser
DEBUG - 2014-02-03 23:25:21 --> Total execution time: 0.0210
DEBUG - 2014-02-03 23:25:21 --> Config Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:25:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:25:21 --> URI Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Router Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Output Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Security Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Input Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:25:21 --> Language Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Loader Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Controller Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:25:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:25:21 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:25:21 --> Session Class Initialized
DEBUG - 2014-02-03 23:25:21 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:25:21 --> Session routines successfully run
DEBUG - 2014-02-03 23:25:21 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:25:21 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:25:30 --> Config Class Initialized
DEBUG - 2014-02-03 23:25:30 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:25:30 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:25:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:25:30 --> URI Class Initialized
DEBUG - 2014-02-03 23:25:30 --> Router Class Initialized
DEBUG - 2014-02-03 23:25:30 --> Output Class Initialized
DEBUG - 2014-02-03 23:25:30 --> Security Class Initialized
DEBUG - 2014-02-03 23:25:30 --> Input Class Initialized
DEBUG - 2014-02-03 23:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:25:30 --> Language Class Initialized
DEBUG - 2014-02-03 23:25:30 --> Loader Class Initialized
DEBUG - 2014-02-03 23:25:30 --> Controller Class Initialized
DEBUG - 2014-02-03 23:25:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:25:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:25:30 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:30 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:30 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:25:30 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:25:30 --> Session Class Initialized
DEBUG - 2014-02-03 23:25:30 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:25:30 --> Session routines successfully run
DEBUG - 2014-02-03 23:25:30 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:25:30 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:25:30 --> Final output sent to browser
DEBUG - 2014-02-03 23:25:30 --> Total execution time: 0.0220
DEBUG - 2014-02-03 23:25:35 --> Config Class Initialized
DEBUG - 2014-02-03 23:25:35 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:25:35 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:25:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:25:35 --> URI Class Initialized
DEBUG - 2014-02-03 23:25:35 --> Router Class Initialized
DEBUG - 2014-02-03 23:25:35 --> Output Class Initialized
DEBUG - 2014-02-03 23:25:35 --> Security Class Initialized
DEBUG - 2014-02-03 23:25:35 --> Input Class Initialized
DEBUG - 2014-02-03 23:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:25:35 --> Language Class Initialized
DEBUG - 2014-02-03 23:25:35 --> Loader Class Initialized
DEBUG - 2014-02-03 23:25:35 --> Controller Class Initialized
DEBUG - 2014-02-03 23:25:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:25:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:25:35 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:35 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:35 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:25:35 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:25:35 --> Session Class Initialized
DEBUG - 2014-02-03 23:25:35 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:25:35 --> Session routines successfully run
DEBUG - 2014-02-03 23:25:35 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:25:35 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:25:38 --> Config Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:25:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:25:38 --> URI Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Router Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Output Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Security Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Input Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:25:38 --> Language Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Loader Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Controller Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:25:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:25:38 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:25:38 --> Session Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:25:38 --> Session routines successfully run
DEBUG - 2014-02-03 23:25:38 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:25:38 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:25:38 --> Final output sent to browser
DEBUG - 2014-02-03 23:25:38 --> Total execution time: 0.0220
DEBUG - 2014-02-03 23:25:38 --> Config Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:25:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:25:38 --> URI Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Router Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Output Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Security Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Input Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:25:38 --> Language Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Loader Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Controller Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:25:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:25:38 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:25:38 --> Session Class Initialized
DEBUG - 2014-02-03 23:25:38 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:25:38 --> Session routines successfully run
DEBUG - 2014-02-03 23:25:38 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:25:38 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:25:45 --> Config Class Initialized
DEBUG - 2014-02-03 23:25:45 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:25:45 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:25:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:25:45 --> URI Class Initialized
DEBUG - 2014-02-03 23:25:45 --> Router Class Initialized
DEBUG - 2014-02-03 23:25:45 --> Output Class Initialized
DEBUG - 2014-02-03 23:25:45 --> Security Class Initialized
DEBUG - 2014-02-03 23:25:45 --> Input Class Initialized
DEBUG - 2014-02-03 23:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:25:45 --> Language Class Initialized
DEBUG - 2014-02-03 23:25:45 --> Loader Class Initialized
DEBUG - 2014-02-03 23:25:45 --> Controller Class Initialized
DEBUG - 2014-02-03 23:25:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:25:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:25:45 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:45 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:45 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:25:45 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:25:45 --> Session Class Initialized
DEBUG - 2014-02-03 23:25:45 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:25:45 --> Session routines successfully run
DEBUG - 2014-02-03 23:25:45 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:25:45 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:25:45 --> Final output sent to browser
DEBUG - 2014-02-03 23:25:45 --> Total execution time: 0.0220
DEBUG - 2014-02-03 23:25:50 --> Config Class Initialized
DEBUG - 2014-02-03 23:25:50 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:25:50 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:25:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:25:50 --> URI Class Initialized
DEBUG - 2014-02-03 23:25:50 --> Router Class Initialized
DEBUG - 2014-02-03 23:25:50 --> Output Class Initialized
DEBUG - 2014-02-03 23:25:50 --> Security Class Initialized
DEBUG - 2014-02-03 23:25:50 --> Input Class Initialized
DEBUG - 2014-02-03 23:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:25:50 --> Language Class Initialized
DEBUG - 2014-02-03 23:25:50 --> Loader Class Initialized
DEBUG - 2014-02-03 23:25:50 --> Controller Class Initialized
DEBUG - 2014-02-03 23:25:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:25:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:25:50 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:50 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:50 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:25:50 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:25:50 --> Session Class Initialized
DEBUG - 2014-02-03 23:25:50 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:25:50 --> Session routines successfully run
DEBUG - 2014-02-03 23:25:50 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:25:50 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:25:58 --> Config Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:25:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:25:58 --> URI Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Router Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Output Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Security Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Input Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:25:58 --> Language Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Loader Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Controller Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:25:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:25:58 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:25:58 --> Session Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:25:58 --> Session routines successfully run
DEBUG - 2014-02-03 23:25:58 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:25:58 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:25:58 --> Final output sent to browser
DEBUG - 2014-02-03 23:25:58 --> Total execution time: 0.0220
DEBUG - 2014-02-03 23:25:58 --> Config Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:25:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:25:58 --> URI Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Router Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Output Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Security Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Input Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:25:58 --> Language Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Loader Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Controller Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:25:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:25:58 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Model Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:25:58 --> Session Class Initialized
DEBUG - 2014-02-03 23:25:58 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:25:58 --> Session routines successfully run
DEBUG - 2014-02-03 23:25:58 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:25:58 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:34:58 --> Config Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:34:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:34:58 --> URI Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Router Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Output Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Security Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Input Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:34:58 --> Language Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Loader Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Controller Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:34:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:34:58 --> Model Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Model Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Model Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:34:58 --> Session Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:34:58 --> Session routines successfully run
DEBUG - 2014-02-03 23:34:58 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:34:58 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:34:58 --> Final output sent to browser
DEBUG - 2014-02-03 23:34:58 --> Total execution time: 0.0220
DEBUG - 2014-02-03 23:34:58 --> Config Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:34:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:34:58 --> URI Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Router Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Output Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Security Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Input Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:34:58 --> Language Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Loader Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Controller Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:34:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:34:58 --> Model Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Model Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Model Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:34:58 --> Session Class Initialized
DEBUG - 2014-02-03 23:34:58 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:34:58 --> Session routines successfully run
DEBUG - 2014-02-03 23:34:58 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:34:58 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:37:34 --> Config Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:37:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:37:34 --> URI Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Router Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Output Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Security Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Input Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:37:34 --> Language Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Loader Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Controller Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:37:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:37:34 --> Model Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Model Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Model Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:37:34 --> Session Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:37:34 --> Session routines successfully run
DEBUG - 2014-02-03 23:37:34 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:37:34 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:37:34 --> Final output sent to browser
DEBUG - 2014-02-03 23:37:34 --> Total execution time: 0.0190
DEBUG - 2014-02-03 23:37:34 --> Config Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:37:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:37:34 --> URI Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Router Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Output Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Security Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Input Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:37:34 --> Language Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Loader Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Controller Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:37:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:37:34 --> Model Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Model Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Model Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:37:34 --> Session Class Initialized
DEBUG - 2014-02-03 23:37:34 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:37:34 --> Session routines successfully run
DEBUG - 2014-02-03 23:37:34 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:37:34 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:40:44 --> Config Class Initialized
DEBUG - 2014-02-03 23:40:44 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:40:44 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:40:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:40:44 --> URI Class Initialized
DEBUG - 2014-02-03 23:40:44 --> Router Class Initialized
DEBUG - 2014-02-03 23:40:44 --> Output Class Initialized
DEBUG - 2014-02-03 23:40:44 --> Security Class Initialized
DEBUG - 2014-02-03 23:40:44 --> Input Class Initialized
DEBUG - 2014-02-03 23:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:40:44 --> Language Class Initialized
DEBUG - 2014-02-03 23:40:44 --> Loader Class Initialized
DEBUG - 2014-02-03 23:40:44 --> Controller Class Initialized
DEBUG - 2014-02-03 23:40:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:40:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:40:44 --> Model Class Initialized
DEBUG - 2014-02-03 23:40:44 --> Model Class Initialized
DEBUG - 2014-02-03 23:40:44 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:40:44 --> Model Class Initialized
DEBUG - 2014-02-03 23:40:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:40:44 --> Session Class Initialized
DEBUG - 2014-02-03 23:40:44 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:40:44 --> Session routines successfully run
DEBUG - 2014-02-03 23:40:44 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:40:44 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:40:44 --> Final output sent to browser
DEBUG - 2014-02-03 23:40:44 --> Total execution time: 0.0220
DEBUG - 2014-02-03 23:40:49 --> Config Class Initialized
DEBUG - 2014-02-03 23:40:49 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:40:49 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:40:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:40:49 --> URI Class Initialized
DEBUG - 2014-02-03 23:40:49 --> Router Class Initialized
DEBUG - 2014-02-03 23:40:49 --> Output Class Initialized
DEBUG - 2014-02-03 23:40:49 --> Security Class Initialized
DEBUG - 2014-02-03 23:40:49 --> Input Class Initialized
DEBUG - 2014-02-03 23:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:40:49 --> Language Class Initialized
DEBUG - 2014-02-03 23:40:49 --> Loader Class Initialized
DEBUG - 2014-02-03 23:40:49 --> Controller Class Initialized
DEBUG - 2014-02-03 23:40:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:40:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:40:49 --> Model Class Initialized
DEBUG - 2014-02-03 23:40:49 --> Model Class Initialized
DEBUG - 2014-02-03 23:40:49 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:40:49 --> Model Class Initialized
DEBUG - 2014-02-03 23:40:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:40:49 --> Session Class Initialized
DEBUG - 2014-02-03 23:40:49 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:40:49 --> Session routines successfully run
DEBUG - 2014-02-03 23:40:49 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:40:49 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:41:17 --> Config Class Initialized
DEBUG - 2014-02-03 23:41:17 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:41:17 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:41:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:41:17 --> URI Class Initialized
DEBUG - 2014-02-03 23:41:17 --> Router Class Initialized
DEBUG - 2014-02-03 23:41:17 --> Output Class Initialized
DEBUG - 2014-02-03 23:41:17 --> Security Class Initialized
DEBUG - 2014-02-03 23:41:17 --> Input Class Initialized
DEBUG - 2014-02-03 23:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:41:17 --> Language Class Initialized
DEBUG - 2014-02-03 23:41:17 --> Loader Class Initialized
DEBUG - 2014-02-03 23:41:17 --> Controller Class Initialized
DEBUG - 2014-02-03 23:41:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:41:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:41:17 --> Model Class Initialized
DEBUG - 2014-02-03 23:41:17 --> Model Class Initialized
DEBUG - 2014-02-03 23:41:17 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:41:17 --> Model Class Initialized
DEBUG - 2014-02-03 23:41:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:41:17 --> Session Class Initialized
DEBUG - 2014-02-03 23:41:17 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:41:17 --> Session routines successfully run
DEBUG - 2014-02-03 23:41:17 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:41:17 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:41:17 --> Final output sent to browser
DEBUG - 2014-02-03 23:41:17 --> Total execution time: 0.0240
DEBUG - 2014-02-03 23:41:22 --> Config Class Initialized
DEBUG - 2014-02-03 23:41:22 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:41:22 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:41:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:41:22 --> URI Class Initialized
DEBUG - 2014-02-03 23:41:22 --> Router Class Initialized
DEBUG - 2014-02-03 23:41:22 --> Output Class Initialized
DEBUG - 2014-02-03 23:41:22 --> Security Class Initialized
DEBUG - 2014-02-03 23:41:22 --> Input Class Initialized
DEBUG - 2014-02-03 23:41:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:41:22 --> Language Class Initialized
DEBUG - 2014-02-03 23:41:22 --> Loader Class Initialized
DEBUG - 2014-02-03 23:41:22 --> Controller Class Initialized
DEBUG - 2014-02-03 23:41:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:41:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:41:22 --> Model Class Initialized
DEBUG - 2014-02-03 23:41:22 --> Model Class Initialized
DEBUG - 2014-02-03 23:41:22 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:41:22 --> Model Class Initialized
DEBUG - 2014-02-03 23:41:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:41:22 --> Session Class Initialized
DEBUG - 2014-02-03 23:41:22 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:41:22 --> Session routines successfully run
DEBUG - 2014-02-03 23:41:22 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:41:22 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:43:10 --> Config Class Initialized
DEBUG - 2014-02-03 23:43:10 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:43:10 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:43:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:43:10 --> URI Class Initialized
DEBUG - 2014-02-03 23:43:10 --> Router Class Initialized
DEBUG - 2014-02-03 23:43:10 --> Output Class Initialized
DEBUG - 2014-02-03 23:43:10 --> Security Class Initialized
DEBUG - 2014-02-03 23:43:10 --> Input Class Initialized
DEBUG - 2014-02-03 23:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:43:10 --> Language Class Initialized
DEBUG - 2014-02-03 23:43:10 --> Loader Class Initialized
DEBUG - 2014-02-03 23:43:10 --> Controller Class Initialized
DEBUG - 2014-02-03 23:43:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:43:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:43:10 --> Model Class Initialized
DEBUG - 2014-02-03 23:43:10 --> Model Class Initialized
DEBUG - 2014-02-03 23:43:10 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:43:10 --> Model Class Initialized
DEBUG - 2014-02-03 23:43:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:43:10 --> Session Class Initialized
DEBUG - 2014-02-03 23:43:10 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:43:10 --> Session routines successfully run
DEBUG - 2014-02-03 23:43:10 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:43:10 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:43:10 --> Final output sent to browser
DEBUG - 2014-02-03 23:43:10 --> Total execution time: 0.0220
DEBUG - 2014-02-03 23:43:15 --> Config Class Initialized
DEBUG - 2014-02-03 23:43:15 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:43:15 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:43:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:43:15 --> URI Class Initialized
DEBUG - 2014-02-03 23:43:15 --> Router Class Initialized
DEBUG - 2014-02-03 23:43:15 --> Output Class Initialized
DEBUG - 2014-02-03 23:43:15 --> Security Class Initialized
DEBUG - 2014-02-03 23:43:15 --> Input Class Initialized
DEBUG - 2014-02-03 23:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:43:15 --> Language Class Initialized
DEBUG - 2014-02-03 23:43:15 --> Loader Class Initialized
DEBUG - 2014-02-03 23:43:15 --> Controller Class Initialized
DEBUG - 2014-02-03 23:43:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:43:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:43:15 --> Model Class Initialized
DEBUG - 2014-02-03 23:43:15 --> Model Class Initialized
DEBUG - 2014-02-03 23:43:15 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:43:15 --> Model Class Initialized
DEBUG - 2014-02-03 23:43:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:43:15 --> Session Class Initialized
DEBUG - 2014-02-03 23:43:15 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:43:15 --> Session routines successfully run
DEBUG - 2014-02-03 23:43:15 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:43:15 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:45:09 --> Config Class Initialized
DEBUG - 2014-02-03 23:45:09 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:45:09 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:45:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:45:09 --> URI Class Initialized
DEBUG - 2014-02-03 23:45:09 --> Router Class Initialized
DEBUG - 2014-02-03 23:45:09 --> Output Class Initialized
DEBUG - 2014-02-03 23:45:09 --> Security Class Initialized
DEBUG - 2014-02-03 23:45:09 --> Input Class Initialized
DEBUG - 2014-02-03 23:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:45:09 --> Language Class Initialized
DEBUG - 2014-02-03 23:45:09 --> Loader Class Initialized
DEBUG - 2014-02-03 23:45:09 --> Controller Class Initialized
DEBUG - 2014-02-03 23:45:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:45:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:45:09 --> Model Class Initialized
DEBUG - 2014-02-03 23:45:09 --> Model Class Initialized
DEBUG - 2014-02-03 23:45:09 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:45:09 --> Model Class Initialized
DEBUG - 2014-02-03 23:45:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:45:09 --> Session Class Initialized
DEBUG - 2014-02-03 23:45:09 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:45:09 --> Session routines successfully run
DEBUG - 2014-02-03 23:45:09 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:45:09 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:45:09 --> Final output sent to browser
DEBUG - 2014-02-03 23:45:09 --> Total execution time: 0.0240
DEBUG - 2014-02-03 23:45:14 --> Config Class Initialized
DEBUG - 2014-02-03 23:45:14 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:45:14 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:45:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:45:14 --> URI Class Initialized
DEBUG - 2014-02-03 23:45:14 --> Router Class Initialized
DEBUG - 2014-02-03 23:45:14 --> Output Class Initialized
DEBUG - 2014-02-03 23:45:14 --> Security Class Initialized
DEBUG - 2014-02-03 23:45:14 --> Input Class Initialized
DEBUG - 2014-02-03 23:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:45:14 --> Language Class Initialized
DEBUG - 2014-02-03 23:45:14 --> Loader Class Initialized
DEBUG - 2014-02-03 23:45:14 --> Controller Class Initialized
DEBUG - 2014-02-03 23:45:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:45:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:45:14 --> Model Class Initialized
DEBUG - 2014-02-03 23:45:14 --> Model Class Initialized
DEBUG - 2014-02-03 23:45:14 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:45:14 --> Model Class Initialized
DEBUG - 2014-02-03 23:45:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:45:14 --> Session Class Initialized
DEBUG - 2014-02-03 23:45:14 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:45:14 --> Session routines successfully run
DEBUG - 2014-02-03 23:45:14 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:45:14 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:45:54 --> Config Class Initialized
DEBUG - 2014-02-03 23:45:54 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:45:54 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:45:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:45:54 --> URI Class Initialized
DEBUG - 2014-02-03 23:45:54 --> Router Class Initialized
DEBUG - 2014-02-03 23:45:54 --> Output Class Initialized
DEBUG - 2014-02-03 23:45:54 --> Security Class Initialized
DEBUG - 2014-02-03 23:45:54 --> Input Class Initialized
DEBUG - 2014-02-03 23:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:45:54 --> Language Class Initialized
DEBUG - 2014-02-03 23:45:54 --> Loader Class Initialized
DEBUG - 2014-02-03 23:45:54 --> Controller Class Initialized
DEBUG - 2014-02-03 23:45:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:45:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:45:54 --> Model Class Initialized
DEBUG - 2014-02-03 23:45:54 --> Model Class Initialized
DEBUG - 2014-02-03 23:45:54 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:45:54 --> Model Class Initialized
DEBUG - 2014-02-03 23:45:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:45:54 --> Session Class Initialized
DEBUG - 2014-02-03 23:45:54 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:45:54 --> Session routines successfully run
DEBUG - 2014-02-03 23:45:54 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:45:54 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:45:54 --> Final output sent to browser
DEBUG - 2014-02-03 23:45:54 --> Total execution time: 0.0240
DEBUG - 2014-02-03 23:45:59 --> Config Class Initialized
DEBUG - 2014-02-03 23:45:59 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:45:59 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:45:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:45:59 --> URI Class Initialized
DEBUG - 2014-02-03 23:45:59 --> Router Class Initialized
DEBUG - 2014-02-03 23:45:59 --> Output Class Initialized
DEBUG - 2014-02-03 23:45:59 --> Security Class Initialized
DEBUG - 2014-02-03 23:45:59 --> Input Class Initialized
DEBUG - 2014-02-03 23:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:45:59 --> Language Class Initialized
DEBUG - 2014-02-03 23:45:59 --> Loader Class Initialized
DEBUG - 2014-02-03 23:45:59 --> Controller Class Initialized
DEBUG - 2014-02-03 23:45:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:45:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:45:59 --> Model Class Initialized
DEBUG - 2014-02-03 23:45:59 --> Model Class Initialized
DEBUG - 2014-02-03 23:45:59 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:45:59 --> Model Class Initialized
DEBUG - 2014-02-03 23:45:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:45:59 --> Session Class Initialized
DEBUG - 2014-02-03 23:45:59 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:45:59 --> Session routines successfully run
DEBUG - 2014-02-03 23:45:59 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:45:59 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:46:18 --> Config Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:46:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:46:18 --> URI Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Router Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Output Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Security Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Input Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:46:18 --> Language Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Loader Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Controller Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:46:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:46:18 --> Model Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Model Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Model Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:46:18 --> Session Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:46:18 --> Session routines successfully run
DEBUG - 2014-02-03 23:46:18 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:46:18 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:46:18 --> Final output sent to browser
DEBUG - 2014-02-03 23:46:18 --> Total execution time: 0.0140
DEBUG - 2014-02-03 23:46:18 --> Config Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:46:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:46:18 --> URI Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Router Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Output Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Security Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Input Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:46:18 --> Language Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Loader Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Controller Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:46:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:46:18 --> Model Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Model Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Model Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:46:18 --> Session Class Initialized
DEBUG - 2014-02-03 23:46:18 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:46:18 --> Session routines successfully run
DEBUG - 2014-02-03 23:46:18 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:46:18 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:47:37 --> Config Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:47:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:47:37 --> URI Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Router Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Output Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Security Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Input Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:47:37 --> Language Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Loader Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Controller Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:47:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:47:37 --> Model Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Model Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Model Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:47:37 --> Session Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:47:37 --> Session routines successfully run
DEBUG - 2014-02-03 23:47:37 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:47:37 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:47:37 --> Final output sent to browser
DEBUG - 2014-02-03 23:47:37 --> Total execution time: 0.0130
DEBUG - 2014-02-03 23:47:37 --> Config Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:47:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:47:37 --> URI Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Router Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Output Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Security Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Input Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:47:37 --> Language Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Loader Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Controller Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:47:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:47:37 --> Model Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Model Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Model Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:47:37 --> Session Class Initialized
DEBUG - 2014-02-03 23:47:37 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:47:37 --> Session routines successfully run
DEBUG - 2014-02-03 23:47:37 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:47:37 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:47:53 --> Config Class Initialized
DEBUG - 2014-02-03 23:47:53 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:47:53 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:47:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:47:53 --> URI Class Initialized
DEBUG - 2014-02-03 23:47:53 --> Router Class Initialized
DEBUG - 2014-02-03 23:47:53 --> Output Class Initialized
DEBUG - 2014-02-03 23:47:53 --> Security Class Initialized
DEBUG - 2014-02-03 23:47:53 --> Input Class Initialized
DEBUG - 2014-02-03 23:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:47:53 --> Language Class Initialized
DEBUG - 2014-02-03 23:47:53 --> Loader Class Initialized
DEBUG - 2014-02-03 23:47:53 --> Controller Class Initialized
DEBUG - 2014-02-03 23:47:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:47:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:47:53 --> Model Class Initialized
DEBUG - 2014-02-03 23:47:53 --> Model Class Initialized
DEBUG - 2014-02-03 23:47:53 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:47:53 --> Model Class Initialized
DEBUG - 2014-02-03 23:47:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:47:53 --> Session Class Initialized
DEBUG - 2014-02-03 23:47:53 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:47:53 --> Session routines successfully run
DEBUG - 2014-02-03 23:47:53 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:47:53 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:47:53 --> Final output sent to browser
DEBUG - 2014-02-03 23:47:53 --> Total execution time: 0.0400
DEBUG - 2014-02-03 23:47:58 --> Config Class Initialized
DEBUG - 2014-02-03 23:47:58 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:47:58 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:47:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:47:58 --> URI Class Initialized
DEBUG - 2014-02-03 23:47:58 --> Router Class Initialized
DEBUG - 2014-02-03 23:47:58 --> Output Class Initialized
DEBUG - 2014-02-03 23:47:58 --> Security Class Initialized
DEBUG - 2014-02-03 23:47:58 --> Input Class Initialized
DEBUG - 2014-02-03 23:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:47:58 --> Language Class Initialized
DEBUG - 2014-02-03 23:47:58 --> Loader Class Initialized
DEBUG - 2014-02-03 23:47:58 --> Controller Class Initialized
DEBUG - 2014-02-03 23:47:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:47:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:47:58 --> Model Class Initialized
DEBUG - 2014-02-03 23:47:58 --> Model Class Initialized
DEBUG - 2014-02-03 23:47:58 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:47:58 --> Model Class Initialized
DEBUG - 2014-02-03 23:47:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:47:58 --> Session Class Initialized
DEBUG - 2014-02-03 23:47:58 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:47:58 --> Session routines successfully run
DEBUG - 2014-02-03 23:47:58 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:47:58 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:56:11 --> Config Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:56:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:56:11 --> URI Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Router Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Output Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Security Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Input Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:56:11 --> Language Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Loader Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Controller Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:56:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:56:11 --> Model Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Model Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Model Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:56:11 --> Session Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:56:11 --> Session routines successfully run
DEBUG - 2014-02-03 23:56:11 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:56:11 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:56:11 --> Final output sent to browser
DEBUG - 2014-02-03 23:56:11 --> Total execution time: 0.0290
DEBUG - 2014-02-03 23:56:11 --> Config Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:56:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:56:11 --> URI Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Router Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Output Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Security Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Input Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:56:11 --> Language Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Loader Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Controller Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:56:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:56:11 --> Model Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Model Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Model Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:56:11 --> Session Class Initialized
DEBUG - 2014-02-03 23:56:11 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:56:11 --> Session routines successfully run
DEBUG - 2014-02-03 23:56:11 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:56:11 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-03 23:56:37 --> Config Class Initialized
DEBUG - 2014-02-03 23:56:37 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:56:37 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:56:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:56:37 --> URI Class Initialized
DEBUG - 2014-02-03 23:56:37 --> Router Class Initialized
DEBUG - 2014-02-03 23:56:37 --> Output Class Initialized
DEBUG - 2014-02-03 23:56:37 --> Security Class Initialized
DEBUG - 2014-02-03 23:56:37 --> Input Class Initialized
DEBUG - 2014-02-03 23:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:56:37 --> Language Class Initialized
DEBUG - 2014-02-03 23:56:37 --> Loader Class Initialized
DEBUG - 2014-02-03 23:56:37 --> Controller Class Initialized
DEBUG - 2014-02-03 23:56:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:56:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:56:37 --> Model Class Initialized
DEBUG - 2014-02-03 23:56:37 --> Model Class Initialized
DEBUG - 2014-02-03 23:56:37 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:56:37 --> Model Class Initialized
DEBUG - 2014-02-03 23:56:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:56:37 --> Session Class Initialized
DEBUG - 2014-02-03 23:56:37 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:56:37 --> Session routines successfully run
DEBUG - 2014-02-03 23:56:37 --> Helper loaded: url_helper
DEBUG - 2014-02-03 23:56:37 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-03 23:56:37 --> Final output sent to browser
DEBUG - 2014-02-03 23:56:37 --> Total execution time: 0.0230
DEBUG - 2014-02-03 23:56:42 --> Config Class Initialized
DEBUG - 2014-02-03 23:56:42 --> Hooks Class Initialized
DEBUG - 2014-02-03 23:56:42 --> Utf8 Class Initialized
DEBUG - 2014-02-03 23:56:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-03 23:56:42 --> URI Class Initialized
DEBUG - 2014-02-03 23:56:42 --> Router Class Initialized
DEBUG - 2014-02-03 23:56:42 --> Output Class Initialized
DEBUG - 2014-02-03 23:56:42 --> Security Class Initialized
DEBUG - 2014-02-03 23:56:42 --> Input Class Initialized
DEBUG - 2014-02-03 23:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-03 23:56:42 --> Language Class Initialized
DEBUG - 2014-02-03 23:56:42 --> Loader Class Initialized
DEBUG - 2014-02-03 23:56:42 --> Controller Class Initialized
DEBUG - 2014-02-03 23:56:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-03 23:56:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-03 23:56:42 --> Model Class Initialized
DEBUG - 2014-02-03 23:56:42 --> Model Class Initialized
DEBUG - 2014-02-03 23:56:42 --> Database Driver Class Initialized
DEBUG - 2014-02-03 23:56:42 --> Model Class Initialized
DEBUG - 2014-02-03 23:56:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-03 23:56:42 --> Session Class Initialized
DEBUG - 2014-02-03 23:56:42 --> Helper loaded: string_helper
DEBUG - 2014-02-03 23:56:42 --> Session routines successfully run
DEBUG - 2014-02-03 23:56:42 --> Helper loaded: url_helper
ERROR - 2014-02-03 23:56:42 --> 404 Page Not Found --> admin/img
