<?php include('common/header.php')?>

<div id="content" data-ng-controller="DashboardCtrl">		
		
		<div id="content-header">
			<h1>Visitor Stats</h1>
		</div> <!-- #content-header -->	
		
		<div id="content-container">
		
			
		
		</div>
		
</div>


<?php include('common/footer.php')?>