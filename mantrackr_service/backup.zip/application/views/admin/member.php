<?php include('common/header.php')?>

	<div id="content" data-ng-controller="MemberCtrl">		
		
		<div id="content-header">
			<h1>Member</h1>
		</div> <!-- #content-header -->	


		<?php  include('common/member_profile.php')?>	
			
		
	</div> <!-- #content -->


<?php include('common/footer.php')?>
