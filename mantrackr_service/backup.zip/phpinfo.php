<?php

	echo phpinfo();


