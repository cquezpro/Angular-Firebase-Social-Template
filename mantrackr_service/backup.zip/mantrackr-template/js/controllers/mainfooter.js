'use strict';

angular.module('mantrackrApp')
    .controller('MainFooterCtrl', ['$scope', '$rootScope', function ($scope, $rootScope) {

  
    	    	
    	
    	
    	
}]);